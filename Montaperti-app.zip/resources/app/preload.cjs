'use strict';
const {contextBridge,ipcRenderer}=require('electron');
contextBridge.exposeInMainWorld('MontapertiClient',Object.freeze({
 onExitRequest(callback){ipcRenderer.on('client:exit-request',(_event,request)=>{if(request&&Number.isSafeInteger(request.id)&&['quit','menu'].includes(request.action))callback({id:request.id,action:request.action});});},
 ready(){ipcRenderer.send('client:ready');},
 requestMenu(){ipcRenderer.send('client:menu');},
 cancel(id){if(Number.isSafeInteger(id))ipcRenderer.send('client:cancel',id);},
 finish(id){if(Number.isSafeInteger(id))ipcRenderer.send('client:finish',id);}
}));
