'use strict';
// Loaded only by the Windows package, after the unchanged game scripts.
(()=>{
 const bridge=window.MontapertiClient;if(!bridge)return;
 const dialog=document.getElementById('clientExit'),title=document.getElementById('clientExitTitle'),message=document.getElementById('clientExitMessage'),note=document.getElementById('clientExitNote'),stay=document.getElementById('clientStay'),exit=document.getElementById('clientExitConfirm');
 let pending=null,finishing=false,previousFocus=null;
 const active=()=>!!G&&!G.over&&!G.netAborted;
 function clearInput(){for(const k in keys)keys[k]=false;mouse.ld=false;mouse.md=false;selBox=null;}
 function closeDialog(){if(dialog.open)dialog.close();clearInput();if(previousFocus?.isConnected)previousFocus.focus();}
 function cancel(){if(!pending||finishing)return;bridge.cancel(pending.id);pending=null;closeDialog();}
 function finish(){if(!pending||finishing)return;finishing=true;exit.disabled=stay.disabled=true;leaving=true;
  // Use the normal, flushed departure message before closing or returning to menu.
  netLeave(()=>bridge.finish(pending.id));}
 function request(value){if(finishing)return;if(pending){stay.focus();return;}pending=value;
  if(!active()&&!NET){finish();return;}
  const running=active(),host=running&&G.mp&&isHost(),online=running&&G.mp;
  title.textContent=value.action==='quit'?'Vuoi chiudere Montaperti?':'Vuoi tornare al menu?';
  message.textContent=host?'Sei l’host: uscendo interrompi la partita di tutti gli altri giocatori.':online?'Uscendo abbandoni questa partita. Non potrai rientrare e l’IA prenderà il tuo posto.':running?'La partita in corso andrà persa.':NET?'Uscendo lasci la stanza online.':'Vuoi uscire?';
  note.textContent=online?'La partita continua mentre decidi. Premi Esc per restare.':running?'Premi Esc o «Resta in partita» per annullare.':'Premi Esc per annullare.';
  stay.textContent=running?'Resta in partita':'Resta qui';exit.textContent=value.action==='quit'?'Esci dal gioco':'Torna al menu';
  previousFocus=document.activeElement;clearInput();dialog.showModal();stay.focus();
 }
 stay.onclick=cancel;exit.onclick=finish;dialog.addEventListener('cancel',e=>{e.preventDefault();cancel();});
 // Native <dialog> traps focus and makes the board inert; block gameplay shortcuts too.
 document.addEventListener('keydown',e=>{if(!dialog.open)return;e.stopImmediatePropagation();if(e.key==='Escape'){e.preventDefault();cancel();}},true);
 for(const event of ['keyup','mousedown','mouseup','mousemove','wheel','contextmenu'])dialog.addEventListener(event,e=>e.stopPropagation());
 function installButtons(){for(const el of document.querySelectorAll('.again'))el.onclick=()=>bridge.requestMenu();
  document.getElementById('leaveOnline').onclick=()=>bridge.requestMenu();
  document.getElementById('bootReload').onclick=()=>bridge.requestMenu();}
 installButtons();document.addEventListener('DOMContentLoaded',installButtons);
 bridge.onExitRequest(request);bridge.ready();
})();
