'use strict';
// ===================== IA =====================
function aiDifficulty(t){return DIFF[isTeamMatch()&&sideOf(t)===0?1:G.diff];}
function mkAI(t){const D=aiDifficulty(t);const pers=[{inf:5,xb:4,cav:2,n:'equilibrata'},{inf:3,xb:6,cav:2,n:'balestre'},{inf:3,xb:2,cav:6,n:'cavalleria'},{inf:7,xb:3,cav:1,n:'fanteria'}][(Math.random()*4)|0];
 teams[t].aiPref={FANTI:pers.inf/3,BALESTRE:pers.xb/3,CAVALLI:pers.cav/3,ECONOMIA:1.3,ESERCITO:1.2,ASSEDIO:.8};
 const first=aiDefensive(t)?(D.gather>=1.3?390:480):D.first;
 return{t,tick:Math.random()*.5,pers,waveT:first*MR(aiDefensive(t)?.95:.9,aiDefensive(t)?1.05:1.1),harassT:first,scoutAt:150,relicT:240,rallyT:0,lastWave:0,waveSize:0};}
function aiDefensive(t){return G.mode==='coop'||!!aiDifficulty(t).advanced;}
function aiGuardNeeds(t){const D=aiDifficulty(t),level=D.advanced||0;return D.gather>=1.3?{inf:6+level*2,xb:3+level}:{inf:4,xb:2};}
function aiGuardPoint(t,u){const home=teams[t].home,foe=aiEnemyStart(t),dir=foe?Math.sign(foe.x-home.x)||1:1;
 const tower=blds.filter(b=>!b.dead&&b.built&&b.team===t&&b.kind==='torre'&&hyp(b.x-home.x,b.y-home.y)<600).sort((a,b)=>hyp(a.x-home.x,a.y-home.y)-hyp(b.x-home.x,b.y-home.y))[0];
 return {x:clamp((tower?tower.x:home.x+dir*200)+dir*(u?.d.cls==='xb'?-45:45),1,WW-1),y:tower?tower.y:home.y};}
function aiHoldGarrison(ai,army){const need=aiGuardNeeds(ai.t),home=teams[ai.t].home;for(const u of army)u.aiGuard=false;
 const free=army.filter(u=>!u.wave&&!u.temporaryUntil&&!(u.aiRetreatUntil>G.t)&&!u.aiScoutUntil).sort((a,b)=>hyp(a.x-home.x,a.y-home.y)-hyp(b.x-home.x,b.y-home.y)||a.id-b.id);
 for(const cls of ['inf','xb'])for(const u of free.filter(u=>u.d.cls===cls&&!u.d.hero).slice(0,need[cls]))u.aiGuard=true;
 // A mixed garrison is preferred; missing archers do not leave an empty city.
 let left=need.inf+need.xb-free.filter(u=>u.aiGuard).length;for(const u of free)if(left>0&&!u.aiGuard&&!u.d.hero&&u.d.cls!=='treb'){u.aiGuard=true;left--;}}
function aiFieldArmy(ai,list){return aiDefensive(ai.t)?list.filter(u=>!u.aiGuard&&!u.temporaryUntil&&!u.aiScoutUntil&&!(u.aiRetreatUntil>G.t)):list;}
function aiObserve(ai){if(ai.intel&&G.t<(ai.observeAt||0))return ai.intel;ai.observeAt=G.t+(aiDifficulty(ai.t).advanced?2:3);
 const intel=aiCoopIntel(ai.t),seen={inf:0,xb:0,cav:0,treb:0,forts:0},enemy=aiCoopEnemy(ai.t);
 for(const u of intel.units)if(!u.d.hero&&u.team===enemy&&seen[u.d.cls]!=null)seen[u.d.cls]++;
 for(const b of blds)if(!b.dead&&b.team===enemy&&intel.buildings.has(b.id)&&(b.kind==='torre'||b.def.wall))seen.forts++;
 ai.intel=seen;return seen;}
function aiCombatChoice(ai,b,my){const t=ai.t,seen=aiObserve(ai),need=aiGuardNeeds(t),counts={inf:0,xb:0,cav:0,treb:0};
 for(const u of my)if(!u.d.hero&&!u.temporaryUntil&&counts[u.d.cls]!=null)counts[u.d.cls]++;
 for(const p of blds)if(!p.dead&&p.team===t)for(const q of p.queue)if(!UT[q.type].hero&&counts[UT[q.type].cls]!=null)counts[UT[q.type].cls]++;
 if(b.kind==='caserma'){
  // Keep a field screen as well as the home garrison: otherwise every new
  // expedition loses its infantry to the fixed reserve and marches as archers.
  const infantry=Math.max(need.inf+Math.ceil(Math.max(0,counts.xb-need.xb)*.7),seen.cav*2),archers=Math.max(need.xb,Math.ceil(counts.inf/2));
  if(counts.inf<infantry)return facOk(UT.pike.fac,teams[t].fac)&&seen.cav>=3&&!trainBlock(t,b,'pike')?'pike':'inf';
  if(counts.xb<archers)return 'xb';
 }
 if(b.kind==='scuderia'&&seen.inf>=6&&seen.inf>seen.xb*2&&counts.cav>=4)return false;
 return null;}
function aiScout(ai,army,threat){const home=teams[ai.t].home;
 for(const u of army)if(u.aiScoutUntil){if(threat||u.lastHit>=G.t-4||G.t>=u.aiScoutUntil){u.aiScoutUntil=0;u.aiRetreatUntil=G.t+90;orderGroup([u],home.x,home.y,true);}}
 if(threat||G.t<ai.scoutAt||army.some(u=>u.aiScoutUntil))return;ai.scoutAt=G.t+150;
 const scout=aiFieldArmy(ai,army.filter(u=>!u.wave&&!u.d.hero&&!u.tgt&&!(u.defendUntil>G.t))).find(u=>u.d.cls==='cav');if(!scout)return;
 const foe=aiEnemyStart(ai.t);if(!foe)return;const dx=foe.x-home.x,dy=foe.y-home.y,d=hyp(dx,dy)||1;
 scout.aiScoutUntil=G.t+70;orderGroup([scout],clamp(foe.x-dx/d*550,1,WW-1),clamp(foe.y-dy/d*550,1,WH-1),true);}
function aiEndOperation(ai,army,reason){const t=ai.t,home=teams[t].home;for(const u of army)if(u.aiExpedition||u.aiResume?.expedition){
 clearCombatResponse(u);u.wave=false;u.aiExpedition=false;u.aiResume=null;u.aiEnemy=null;u.tgt=null;u.palaceAttack=null;u.focus=false;u.aiProgress=null;u.aiRetreatUntil=G.t+hyp(u.x-home.x,u.y-home.y)/35+20;
 const p=aiGuardPoint(t,u);orderGroup([u],p.x,p.y,true);}
 ai.operation=null;ai.recoverUntil=G.t+(aiDifficulty(t).gather>=1.3?70:95);ai.waveT=Math.max(ai.waveT,ai.recoverUntil);ai.lastRetreat=reason;}
function aiOperationTick(ai,army){const t=ai.t,home=teams[t].home;
 for(const u of army)if(u.aiRetreatUntil){if(hyp(u.x-home.x,u.y-home.y)<360||G.t>=u.aiRetreatUntil){clearCombatResponse(u);u.aiRetreatUntil=0;u.order=null;u.tgt=null;u.palaceAttack=null;u.focus=false;}}
 const op=ai.operation;if(!op)return;const front=army.filter(u=>u.aiExpedition||u.aiResume?.expedition);
 if(!isActivePlayer(op.enemy)){const next=aiCoopEnemy(t),goal=aiEnemyStart(t);
  if(!isActivePlayer(next)||!goal){aiEndOperation(ai,army,'objective-fallen');return;}
  op.enemy=next;op.x=goal.x;op.y=goal.y;op.hp={};op.progress=G.t;
  for(const u of front)u.aiEnemy=next;if(front.length)aiAssault(front,goal);}
 let progress=teams[t].kills>op.kills;op.kills=teams[t].kills;
 const visible=aiVisibleBuildings(t);for(const b of blds)if(b.team===op.enemy&&visible.has(b.id)){if(op.hp[b.id]!=null&&b.hp<op.hp[b.id]-1)progress=true;op.hp[b.id]=b.hp;}
 if(progress)op.progress=G.t;
 if(G.t-op.started<25)return;
 const combat=front.some(u=>u.tgt||G.t-u.lastHit<5),line=front.filter(u=>!u.d.hero&&['inf','cav'].includes(u.d.cls)),siege=front.filter(u=>u.d.cls==='treb');
 const stalled=G.t-op.progress>90&&front.some(u=>hyp(u.x-op.x,u.y-op.y)<600)||G.t-op.progress>210;
 if(front.length<6||combat&&line.length<3||op.siege&&siege.length===0&&aiObserve(ai).forts>=2&&G.t-op.progress>25||stalled)aiEndOperation(ai,army,stalled?'stalled':'losses');}
function aiFindSpot(t,kind,x,y,rmin,rmax){const d=BT[kind];
 for(let r=rmin;r<=rmax;r+=1){const n=8+r*2,a0=Math.random()*TAU;for(let k=0;k<n;k++){const a=a0+k/n*TAU;const cx=Math.round(x/CELL+Math.cos(a)*r-d.w/2),cy=Math.round(y/CELL+Math.sin(a)*r-d.h/2);
  if(!canPlace(t,kind,cx,cy))continue;let ok=true;
  for(let yy=cy-1;yy<=cy+d.h&&ok;yy++)for(let xx=cx-1;xx<=cx+d.w;xx++){if(!inb(xx,yy)){ok=false;break;}const o=bAt[yy*GW+xx];if(o&&!o.def.wall&&!(o.def.flat&&kind==='campo')){ok=false;break;}if(water[yy*GW+xx]===2){ok=false;break;}}
  if(ok)return{cx,cy};}}return null;}
// Recupera spazio vicino alla base quando il quartiere iniziale è pieno.
// Scansione deterministica: lascia un anello percorribile e accessibile ai contadini.
function aiExpansionSpot(t,kind,x,y,maxR=20){const d=BT[kind],ws=units.filter(u=>!u.dead&&u.team===t&&u.type==='worker');if(!ws.length)return null;
 const zone=workerAccess(t).zone,zones=new Set(ws.map(w=>zone[cellI(w.x,w.y)]).filter(z=>z>=0));if(!zones.size)return null;
 const ox=x/CELL-d.w/2,oy=y/CELL-d.h/2;let best=null,bd=Infinity;
 for(let cy=Math.max(1,Math.ceil(oy-maxR));cy<=Math.min(GH-d.h-1,Math.floor(oy+maxR));cy++)for(let cx=Math.max(1,Math.ceil(ox-maxR));cx<=Math.min(GW-d.w-1,Math.floor(ox+maxR));cx++){
  const ds=(cx-ox)**2+(cy-oy)**2;if(ds<16||ds>maxR*maxR||ds>=bd||!canPlace(t,kind,cx,cy))continue;let ok=true,access=false;
  for(let yy=cy-1;yy<=cy+d.h&&ok;yy++)for(let xx=cx-1;xx<=cx+d.w;xx++){if(xx>=cx&&xx<cx+d.w&&yy>=cy&&yy<cy+d.h)continue;const i=yy*GW+xx,o=bAt[i];
   if(!passFor(t,i)||water[i]===2||o&&!(o.def.flat&&kind==='campo')){ok=false;break;}if(zones.has(zone[i]))access=true;}
  if(!ok||!access)continue;const rect={x0:cx*CELL,y0:cy*CELL,w:d.w,h:d.h};if(units.some(u=>!u.dead&&!u.sheltered&&rectDist(u.x,u.y,rect)<=u.d.r+2))continue;
  best={cx,cy};bd=ds;
 }return best;}
function aiBuild(ai,kind,x,y,rmin,rmax){const t=ai.t;if(!canAfford(t,costOf(t,kind,true)))return false;let s=aiFindSpot(t,kind,x,y,rmin,rmax);
 // L'Officina non può restare rimandata per tutta la partita se il quartiere vicino è pieno.
 if(!s&&kind==='officina'&&rmax<16)s=aiFindSpot(t,kind,x,y,rmax+1,16);
 if(!s&&['casa','campo','caserma','scuderia','officina'].includes(kind))s=aiExpansionSpot(t,kind,x,y);
 if(!s)return false;return !!placeBld(t,kind,s.cx,s.cy);}
// Un acquisto intenzionale e limitato nel tempo, con gli stessi costi dei giocatori.
function aiHeroRecruitPlan(ai,workers,home){const t=ai.t,T=teams[t],h=HEROES.find(h=>h.fac===T.fac);
 if(!h||G.t<180||workers.length<12||!home.built||heroTrainBlock(t,home,h.type)){ai.heroSaveUntil=0;return null;}
 const danger=units.some(e=>!e.dead&&areEnemies(t,e.team)&&e.type!=='worker'&&e.type!=='carr'&&hyp(e.x-home.x,e.y-home.y)<550&&heroVisible(t,e));
 if(danger){ai.heroSaveUntil=0;ai.heroRetryAt=G.t+15;return null;}
 if(ai.heroSaveUntil&&G.t>=ai.heroSaveUntil){ai.heroSaveUntil=0;ai.heroRetryAt=G.t+30;return null;}
 if(!ai.heroSaveUntil){if(G.t<(ai.heroRetryAt||0))return null;ai.heroSaveUntil=G.t+45;}
 return h;}
function aiUpdate(ai,dt){if(!isActivePlayer(ai.t))return;ai.tick-=dt;if(ai.tick>0)return;ai.tick=.5;const t=ai.t,T=teams[t],D=aiDifficulty(t),home=T.home;if(!home||home.dead)return;
 const foe=aiEnemyStart(t);const my=units.filter(u=>!u.dead&&u.team===t);const workers=my.filter(u=>u.type==='worker'),army=my.filter(u=>u.type!=='worker'&&u.type!=='carr');
 const mb=blds.filter(b=>!b.dead&&b.team===t);const has=k=>mb.filter(b=>b.kind===k);const found=mb.filter(b=>!b.built),defensive=aiDefensive(t),seen=defensive?aiObserve(ai):null;
 if(defensive){aiOperationTick(ai,army);aiHoldGarrison(ai,army);}
 // Solo il moltiplicatore dichiarato dalla difficoltà; nessun recupero economico nascosto.
 T.aiMul=(t!==0||G.auto||isAIControlled(t)?D.gather:1);
 // lavori dei contadini: base per fase, poi si sposta verso la risorsa che manca
 const n=workers.length;const sp=G.t<150?[.6,.4,0]:G.t<480?[.5,.45,.05]:[.45,.42,.13];const r=T.res;
 if(r.g>r.l*2+300){sp[0]-=.15;sp[1]+=.15;}else if(r.l>r.g*2+300){sp[1]-=.12;sp[0]+=.12;}
 if(defensive&&G.t>120&&r.p<240){sp[2]=Math.max(sp[2],2/Math.max(1,n));sp[0]-=.04;}
 if(r.p>700){sp[1]+=sp[2]*.7;sp[2]*=.3;}else if(r.p<100&&G.t>480){sp[2]+=.06;sp[0]-=.06;}
 T.jobs.g=Math.round(n*sp[0]);T.jobs.p=Math.round(n*sp[2]);T.jobs.l=Math.max(0,n-T.jobs.g-T.jobs.p);T.newJob=r.g<r.l?'g':'l';
 let heroPlan=aiHeroRecruitPlan(ai,workers,home);
 // costruzioni: la prima voce valida della lista; se manca il denaro si risparmia
 const cx=home.x,cy=home.y,dir=foe?Math.sign(foe.x-home.x)||1:1;
 if(found.length<2){const fcap=has('campo').length*farmCap(t),prod=has('caserma').length+has('scuderia').length,fk=k=>found.some(b=>b.kind===k);
  const plan=[
   [()=>T.popMax-T.popUsed<6+army.length*.05&&T.popMax<300&&!fk('casa'),'casa',cx-dir*80,cy,4,13],
   [()=>T.jobs.g>fcap-1&&!fk('campo'),'campo',cx,cy,4,10],
   [()=>G.t>45&&!has('caserma').length,'caserma',cx+dir*120,cy,4,9],
   [()=>defensive&&G.t>170&&!has('torre').some(b=>hyp(b.x-cx,b.y-cy)<600),'torre',cx+dir*240,cy,2,5],
   [()=>G.t>200&&!has('scuderia').length,'scuderia',cx+dir*90,cy,5,10],
   [()=>{if(G.t<180||has('magaz').length>=3||fk('magaz'))return false;const far=workers.filter(w=>w.rc>=0&&(w.job==='l'||w.job==='p'));if(far.length<3)return false;
     let sx=0,sy=0;for(const w of far){sx+=cX(w.rc);sy+=cY(w.rc);}sx/=far.length;sy/=far.length;const dp=mb.filter(b=>b.def.drop&&b.built).reduce((a,b)=>Math.min(a,hyp(b.x-sx,b.y-sy)),1e9);ai.mx=sx;ai.my=sy;return dp>320;},'magaz',()=>ai.mx,()=>ai.my,3,7],
   [()=>defensive&&(G.t>420||G.t>300&&seen.forts>=2)&&!has('officina').length,'officina',cx-dir*40,cy-100,4,11],
   [()=>G.t>400&&has('caserma').length<2,'caserma',cx+dir*60,cy+120,4,11],
   [()=>G.t>480&&!has('officina').length,'officina',cx-dir*40,cy-100,4,11],
   [()=>G.t>300&&r.g>350&&r.l>200&&prod<6,ai.pers.cav>=4&&Math.random()<.5?'scuderia':'caserma',cx+dir*MR(0,140),cy+MR(-170,170),4,12],
   [()=>G.t>260&&r.p>140&&has('torre').length<Math.min(defensive?4:6,Math.floor((G.t-260)/180)+1),'torre',cx+dir*260,cy+MR(-180,180),2,7],
  ];
  for(const [c,k,x,y,a,b] of plan){if(heroPlan&&k!=='casa'&&k!=='campo'&&!(defensive&&k==='torre'&&!has('torre').length))continue;if(!c())continue;if(!canAfford(t,costOf(t,k,true)))break;if(aiBuild(ai,k,typeof x==='function'?x():x,typeof y==='function'?y():y,a,b))break;}}
 // addestramento
 const desiredW=Math.min(D.maxW,T.mods.wCap,10+G.t/20);const rich=r.g>500&&r.l>250;
 for(const b of mb){if(!b.built)continue;const ql=b.kind==='palazzo'?2:rich?5:2;if(b.queue.length>=ql)continue;
  if(b.kind==='palazzo'){if(heroPlan){if(T.popMax-T.popUsed>=3&&train(t,b,heroPlan.type)){ai.heroSaveUntil=0;heroPlan=null;}continue;}
   if(workers.length+b.queue.filter(q=>q.type==='worker').length<desiredW)train(t,b,'worker');else if(G.t>500&&facOk(UT.carr.fac,T.fac))train(t,b,'carr');continue;}
  if(heroPlan)continue;
  if(G.t>60&&workers.length<desiredW*.7&&!(r.g>150&&r.l>100))continue;
if(!b.def.train)continue;const choice=defensive?aiCombatChoice(ai,b,my):null;if(choice===false)continue;if(choice){train(t,b,choice);continue;}const spec=b.def.train.filter(ty=>UT[ty].fac&&facOk(UT[ty].fac,T.fac)&&ty!=='carr');  if(spec.length&&G.t>360&&Math.random()<.4&&!trainBlock(t,b,spec[0])){train(t,b,spec[0]);continue;}  if(b.kind==='caserma'){const w=ai.pers.inf/(ai.pers.inf+ai.pers.xb);train(t,b,Math.random()<w?'inf':'xb');}  else if(b.kind==='scuderia')train(t,b,'cav');  else if(b.kind==='officina'&&G.t>(defensive?480:540))train(t,b,Math.random()<.5?'treb':(spec[0]||'treb'));}
 for(const b of mb)if(b.def.train&&b.kind!=='palazzo'&&!b.rally){const p=aiLocalRally(b,home,dir);b.rally={x:p.x,y:clamp(p.y+MR(-40,40),1,WH-1)};}
 // Il campo è una missione finita appena convertito, anche se resta un bersaglio agganciato.
 for(const u of army)if(u.aiCamp&&!u.aiCamp.relic)u.aiCamp=null;
 // Difendere la base dai combattenti avversari, senza richiamare l'assalto per un brigante lontano.
 const threats=(isTeamMatch()?aiCoopIntel(t).units:units).filter(e=>!e.dead&&areEnemies(e.team,t)&&isActivePlayer(e.team)&&e.type!=='worker'&&e.type!=='carr'&&(hyp(e.x-cx,e.y-cy)<550||defensive&&mb.some(b=>b.built&&(b.def.drop||b.kind==='campo'||b.camp)&&rectDist(e.x,e.y,b)<220)));
 const threat=threats.sort((a,b)=>hyp(a.x-cx,a.y-cy)-hyp(b.x-cx,b.y-cy))[0];
 if(threat){const def=army.filter(u=>!u.wave||hyp(u.x-cx,u.y-cy)<850).sort((a,b)=>hyp(a.x-threat.x,a.y-threat.y)-hyp(b.x-threat.x,b.y-threat.y)).slice(0,Math.ceil(threats.length*1.4)+3);
  for(const u of def){if(u.wave)u.aiResume={camp:u.aiCamp||null,expedition:!!u.aiExpedition};u.wave=false;u.defendUntil=G.t+8;if(isTeamMatch())u.aiAidTeam=null;}
  const idle=def.filter(u=>!u.tgt&&(!u.order||hyp(u.order.x-threat.x,u.order.y-threat.y)>180));if(idle.length)orderGroup(idle,threat.x,threat.y,false);}
 // Finita la difesa, riprendono soltanto le unità che avevano già una missione.
 for(const u of army)if(u.aiResume&&!(u.defendUntil>G.t)){
  const mission=u.aiResume;u.aiResume=null;
  if(mission.camp&&!mission.camp.relic){u.aiCamp=null;continue;}
  u.wave=true;u.aiExpedition=mission.expedition;u.aiCamp=mission.camp;
  if(!u.tgt||u.tgt.dead){const tg=u.aiCamp||aiAttackGoal(t,u.x,u.y,foe,u);if(tg)aiAssault([u],tg);else{u.wave=false;u.aiExpedition=false;}}
 }
 if(isTeamMatch()&&!threat)aiCoopAid(ai,army);
 const available=()=>army.filter(u=>!u.wave&&!(u.defendUntil>G.t)&&(!defensive||!u.temporaryUntil&&!u.aiScoutUntil&&!(u.aiRetreatUntil>G.t)));
 if(defensive)aiScout(ai,army,threat);
 // incursione
 if(!defensive&&G.t>=ai.harassT&&foe){ai.harassT=1e9;const cav=available().filter(u=>u.d.cls==='cav').slice(0,4);if(cav.length>=2){const ws=(isTeamMatch()?aiCoopIntel(t).units:units).filter(u=>!u.dead&&areEnemies(u.team,t)&&isActivePlayer(u.team)&&u.type==='worker');const w=ws[(Math.random()*ws.length)|0];if(w){for(const u of cav)u.wave=true;orderGroup(cav,w.x,w.y,false);}}}
 // reliquie
 ai.relicT-=.5;if(ai.relicT<=0&&!threat&&aiFieldArmy(ai,available()).length>=14){ai.relicT=150;const c=camps.filter(c=>c.relic).sort((a,b)=>hyp(a.x-cx,a.y-cy)-hyp(b.x-cx,b.y-cy))[0];
  if(c&&hyp(c.x-cx,c.y-cy)<WW*.55){const free=aiFieldArmy(ai,available()),sq=free.slice(0,Math.min(defensive?16:Infinity,Math.ceil(free.length*.5)));for(const u of sq){u.wave=true;u.aiCamp=c;u.aiExpedition=false;u.aiEnemy=null;}orderGroup(sq,c.x,c.y,false);}}
 // ondate d'attacco
 const free=available(),field=aiFieldArmy(ai,free),minA=aiArmyThreshold(ai);
 const siegeNeeded=defensive&&seen.forts>=2&&!field.some(u=>u.d.cls==='treb');
 if(siegeNeeded)ai.siegeWaitAt=ai.siegeWaitAt||G.t;else ai.siegeWaitAt=0;
 if(G.t>=ai.waveT&&foe&&(!defensive||!threat&&!ai.operation&&G.t>=(ai.recoverUntil||0)&&(!siegeNeeded||G.t-ai.siegeWaitAt>120))){if(field.length>=minA){if(!isTeamMatch()||aiCoopWaveReady(ai)){const send=defensive?field:free.slice(0,Math.ceil(free.length*.85));const tg=aiAttackGoal(t,cx,cy,foe);for(const u of send){u.wave=true;u.aiExpedition=true;if(aiHardCoop(t))u.aiEnemy=aiCoopEnemy(t);}
   if(defensive)ai.operation={started:G.t,progress:G.t,enemy:aiCoopEnemy(t),x:tg.x,y:tg.y,hp:{},kills:T.kills,siege:send.some(u=>u.d.cls==='treb'),reinforcements:0,reinforceAt:G.t+35};
   aiAssault(send,tg);ai.waveSize=send.length;ai.lastWave=G.t;ai.waveT=G.t+D.int*MR(.85,1.15);for(const enemy of playerIds())if(areEnemies(enemy,t)&&isActivePlayer(enemy)){notify(enemy,'toast','Un esercito nemico è in marcia!','#ff9a8a',2400);notify(enemy,'sfx','alarm');}}}
  else ai.waveT=G.t+20;}
 // Piccoli gruppi raggiungono una spedizione ancora presente al fronte; una sola incursione non basta.
 if(!threat&&G.t>=(ai.reinforceAt||0)){ai.reinforceAt=G.t+(defensive?35:15);
  const front=army.filter(u=>u.wave&&u.aiExpedition&&!u.aiCamp&&hyp(u.x-cx,u.y-cy)>600).sort((a,b)=>hyp(a.x-cx,a.y-cy)-hyp(b.x-cx,b.y-cy));
  const reserve=aiFieldArmy(ai,available().filter(u=>!u.tgt)),op=ai.operation,level=D.advanced||0,canReinforce=!defensive||op&&op.reinforcements<2+level&&G.t>=op.reinforceAt&&G.t-op.started<=120+level*30;
  if(canReinforce&&front.length>=6&&reserve.length>=9){const lead=front[Math.floor(front.length/2)],send=defensive?reserve.slice(0,12):reserve.slice(0,reserve.length-3);
   if(defensive){op.reinforcements++;op.reinforceAt=G.t+35;}
   for(const u of send){u.wave=true;u.aiExpedition=true;if(aiHardCoop(t))u.aiEnemy=lead.aiEnemy;}aiAssault(send,{x:lead.x,y:lead.y});}
 }
 // le truppe in attacco ferme ripartono verso il prossimo bersaglio
 ai.rallyT-=.5;if(ai.rallyT<=0){ai.rallyT=3;const wv=army.filter(u=>u.wave);
  for(const u of wv){const p=u.aiProgress,inRange=u.tgt&&!u.tgt.dead&&distTo(u,u.tgt)<=T.S[u.type].rng+35;
   if(!p||hyp(u.x-p.x,u.y-p.y)>20||inRange)u.aiProgress={x:u.x,y:u.y,t:G.t};
   else if(G.t-p.t>=12){clearCombatResponse(u);u.order=null;u.tgt=null;u.palaceAttack=null;u.focus=false;u.path=null;u.aiProgress=null;}}
  const idle=wv.filter(u=>!u.order&&!u.tgt);for(const u of idle){if(u.aiCamp&&u.aiCamp.relic){orderGroup([u],u.aiCamp.x,u.aiCamp.y,false);continue;}u.aiCamp=null;
   const tg=aiAttackGoal(t,u.x,u.y,foe,u);if(tg)aiAssault([u],tg);else u.wave=false;}
  // L'assedio mantiene il bersaglio edilizio e non insegue i rinforzi nemici.
  for(const u of wv)if(u.d.cls==='treb'&&!u.aiCamp&&!u.focus){const tg=nearestEnemyBld(t,u.x,u.y);if(tg&&distTo(u,tg)<T.S[u.type].rng+160)orderAttack([u],tg);}
  // Il Carroccio segue il nucleo dell'ondata: aura e soccorsi possono accompagnare l'assalto.
  const support=my.filter(u=>u.d.cls==='carr');if(support.length){const group=wv.filter(u=>!u.aiCamp).sort((a,b)=>hyp(a.x-cx,a.y-cy)-hyp(b.x-cx,b.y-cy));
   const lead=group[Math.floor(group.length/2)];const sx=lead?lead.x-dir*90:cx+dir*200,sy=lead?lead.y:cy;
   for(const u of support)if(!u.order||hyp(u.order.x-sx,u.order.y-sy)>120)orderGroup([u],sx,sy,false);}
  if(!threat)for(const u of free)if(!u.wave&&!u.order&&!u.tgt){const near=mb.filter(b=>b.built&&b.def.train&&b.kind!=='palazzo').sort((a,b)=>hyp(a.x-u.x,a.y-u.y)-hyp(b.x-u.x,b.y-u.y))[0];
   const p=defensive&&u.aiGuard?aiGuardPoint(t,u):aiLocalRally(near||home,home,dir);if(hyp(u.x-p.x,u.y-p.y)>(defensive&&u.aiGuard?90:260))orderGroup([u],p.x,p.y,false);}
  if(T.mods.mart&&T.martCd<=0&&wv.some(u=>u.tgt))ringMart(t);}heroAIUpdate(ai);}
function heroAIUpdate(ai){for(const u of units){if(u.dead||u.team!==ai.t||!u.d.hero||u.heroCast||u.heroReadyAt>G.t)continue;const h=heroMeta(u);let target=null;
 if(h.target==='siege'){target=units.filter(e=>!e.dead&&e.team===u.team&&e.d.cls==='treb'&&e.tgt&&!e.tgt.dead&&heroVisible(u.team,e.tgt)&&hyp(e.x-u.x,e.y-u.y)<=h.range).sort((a,b)=>a.cd-b.cd||a.id-b.id).find(e=>!heroAbilityBlock(ai.t,u,e));if(!target)continue;}
 else if(h.target==='enemy'){target=heroEnemies(u,h.range).find(e=>!heroAbilityBlock(ai.t,u,e));if(!target)continue;}
 else{const enemies=heroEnemies(u,h.fac===0?160:h.range);if(!enemies.length)continue;if(h.fac===3&&!enemies.some(e=>['inf','cav'].includes(e.d.cls)))continue;}
 useHeroAbility(ai.t,u.id,target?.id);}}
function aiArmyThreshold(ai){const D=aiDifficulty(ai.t),grown=Math.min(D.minArmy+12,D.minArmy+Math.floor(G.t/180));
 return G.t-Math.max(D.first,ai.lastWave)>D.int*1.5?Math.max(6,Math.ceil(D.minArmy*.7)):grown;}
function aiLocalRally(b,home,dir){const p=b.camp||(b.x-home.x)*dir>400?{x:b.x+dir*90,y:b.y}:{x:home.x+dir*240,y:home.y};return{x:clamp(p.x,1,WW-1),y:clamp(p.y,1,WH-1)};}
function aiAssault(list,target){orderGroup(list,target.x,target.y,false);for(const u of list)if(u.d.cls==='treb'&&target.isB&&aiVisibleBuildings(u.team).has(target.id)&&distTo(u,target)<teams[u.team].S[u.type].rng+160)orderAttack([u],target);}
// La posizione iniziale è nota, gli edifici successivi devono essere avvistati.
function aiEnemyStart(t){const origin=bases[t];let best=null,bd=Infinity;
 if(isTeamMatch()){const b=bases[aiCoopEnemy(t)];return b?{x:b.cx*CELL,y:(b.cy+.5)*CELL}:null;}
 for(const enemy of playerIds()){if(!areEnemies(enemy,t)||!isActivePlayer(enemy))continue;const b=bases[enemy];if(!b)continue;
  const d=origin?hyp(b.cx-origin.cx,b.cy-origin.cy):enemy;if(d<bd){bd=d;best=b;}}
 return best?{x:best.cx*CELL,y:(best.cy+.5)*CELL}:null;}
const aiSightCache=[];
function aiVisibleBuildings(t){if(isTeamMatch())return aiCoopIntel(t).buildings;const cached=aiSightCache[t];if(cached&&cached.game===G&&cached.time===G.t&&cached.ver===gridVer)return cached.ids;
 const T=teams[t],sensors=[];for(const u of units)if(!u.dead&&!u.sheltered&&u.team===t)sensors.push({x:u.x,y:u.y,r:T.S[u.type].sight});
 for(const b of blds)if(!b.dead&&b.team===t)sensors.push({x:b.x,y:b.y,r:(b.def.sight||150)*(1+T.mods.sight)*(b.built?1:.6)});
 const ids=new Set();for(const b of blds){if(b.dead||!areEnemies(b.team,t)||!isActivePlayer(b.team))continue;const cells=[b.cy*GW+b.cx,cellI(b.x,b.y)];
  if(sensors.some(s=>cells.some(i=>(cX(i)-s.x)**2+(cY(i)-s.y)**2<=s.r*s.r)))ids.add(b.id);}
 aiSightCache[t]={game:G,time:G.t,ver:gridVer,ids};return ids;}
function nearestEnemyBld(t,x,y,enemy=null){let best=null,bd=Infinity;const visible=aiVisibleBuildings(t);for(const b of blds){if(b.dead||!areEnemies(b.team,t)||!isActivePlayer(b.team)||enemy!==null&&b.team!==enemy||b.def.wall||!visible.has(b.id))continue;const d=hyp(b.x-x,b.y-y);
 const priority=b.kind==='palazzo'?.58:b.kind==='torre'?.8:b.def.train?.9:b.def.flat?1.5:1.15;const score=d*priority;if(score<bd){bd=score;best=b;}}return best;}

// La cooperazione usa soltanto i sensori degli alleati e le partenze note.
const aiCoopSight=[],aiCoopPlans=[];
function aiCoopIntel(t){const side=sideOf(t),cached=aiCoopSight[side];if(cached&&cached.game===G&&cached.time===G.t&&cached.ver===gridVer)return cached;
 const sensors=[];for(const u of units)if(!u.dead&&!u.sheltered&&areAllies(t,u.team)&&isActivePlayer(u.team))sensors.push({x:u.x,y:u.y,r:teams[u.team].S[u.type].sight});
 for(const b of blds)if(!b.dead&&areAllies(t,b.team)&&isActivePlayer(b.team))sensors.push({x:b.x,y:b.y,r:(b.def.sight||150)*(1+teams[b.team].mods.sight)*(b.built?1:.6)});
 const seen=(x,y)=>sensors.some(s=>(s.x-x)**2+(s.y-y)**2<=s.r*s.r),buildings=new Set(),enemies=[];
 for(const b of blds)if(!b.dead&&areEnemies(t,b.team)&&isActivePlayer(b.team)&&(seen(cX(b.cy*GW+b.cx),cY(b.cy*GW+b.cx))||seen(cX(cellI(b.x,b.y)),cY(cellI(b.x,b.y)))))buildings.add(b.id);
 for(const u of units)if(!u.dead&&!u.sheltered&&areEnemies(t,u.team)&&isActivePlayer(u.team)&&seen(u.x,u.y))enemies.push(u);
 return aiCoopSight[side]={game:G,time:G.t,ver:gridVer,buildings,units:enemies};}
function aiHardCoop(t){return G.mode==='coop'&&G.diff>=2&&sideOf(t)===1;}
function aiCoopEnemy(t){const plan=aiCoopPlan(t);return plan?.targets?.[t]??plan?.enemy??null;}
// Difficile: assegna fronti per città, senza leggere eserciti o PV nella nebbia.
// Al massimo 5^5 combinazioni ogni 90 secondi; il costo di sovrapposizione evita
// che la sola distanza media mandi tutti al centro, ma consente attacchi congiunti.
function aiHardCoopTargets(allies,enemies,intel){
 const pressure={},costs={},army=units.filter(u=>!u.dead&&u.wave&&u.aiExpedition&&!u.aiCamp);
 for(const e of enemies){const b=bases[e],x=b.cx*CELL,y=(b.cy+.5)*CELL;let cost=0;
  for(const u of intel.units)if(hyp(u.x-x,u.y-y)<850)cost+=u.type==='worker'?-12:u.type==='carr'?30:24*(u.d.pop||1);
  for(const b of blds)if(intel.buildings.has(b.id)&&hyp(b.x-x,b.y-y)<850){if(b.kind==='torre')cost+=b.built?110:30;else if(b.def.wall)cost+=8;}
  const palace=teams[e].home;if(palace&&intel.buildings.has(palace.id)&&palace.hp<palace.max*.4)cost-=500;
  pressure[e]=cost;
 }
 for(const a of allies){costs[a]={};for(const e of enemies){const from=bases[a],to=bases[e];
  const committed=army.filter(u=>u.team===a&&u.aiEnemy===e&&hyp(u.x-to.cx*CELL,u.y-(to.cy+.5)*CELL)<950).length;
  costs[a][e]=hyp(from.cx-to.cx,from.cy-to.cy)*CELL*.35+pressure[e]-(committed>=6?240:0);
 }}
 let best=Infinity,targets={};const choice={},used={};
 function assign(i,total){if(i===allies.length){if(total<best){best=total;targets={...choice};}return;}
  const a=allies[i];for(const e of enemies){const n=used[e]||0;choice[a]=e;used[e]=n+1;assign(i+1,total+costs[a][e]+n*650);used[e]=n;}}
 assign(0,0);return targets;
}
function aiCoopPlan(t){const side=sideOf(t),old=aiCoopPlans[side];if(old&&old.game===G&&G.t<old.until&&isActivePlayer(old.enemy)&&areEnemies(t,old.enemy)&&(!old.targets||playerIds().filter(a=>isActivePlayer(a)&&areAllies(t,a)).every(a=>isActivePlayer(old.targets[a])&&areEnemies(a,old.targets[a]))))return old;
 const allies=playerIds().filter(a=>isActivePlayer(a)&&areAllies(t,a)),enemies=playerIds().filter(e=>isActivePlayer(e)&&areEnemies(t,e));if(!enemies.length)return null;
 if(aiHardCoop(t)){const targets=aiHardCoopTargets(allies,enemies,aiCoopIntel(t));return aiCoopPlans[side]={game:G,enemy:targets[allies[0]],targets,until:G.t+(aiDifficulty(t).advanced===2?45:aiDifficulty(t).advanced?60:90),launchAt:old?.game===G?old.launchAt:0};}
 const visible=aiCoopIntel(t).buildings;let enemy=enemies[0],best=Infinity;
 for(const e of enemies){const base=bases[e];if(!base)continue;let distance=0;for(const a of allies){const b=bases[a];distance+=hyp(base.cx-b.cx,base.cy-b.cy);}
  // Un Palazzo già avvistato sotto assedio mantiene la priorità; nessuna lettura di HP nascosti.
  const palace=teams[e].home,exposed=palace&&visible.has(palace.id);const score=distance/Math.max(1,allies.length)*(exposed?.75:1);
  if(score<best){best=score;enemy=e;}}
 return aiCoopPlans[side]={game:G,enemy,until:G.t+180,launchAt:old?.game===G?old.launchAt:0};}
function aiAttackGoal(t,x,y,fallback,mission=null){if(!isTeamMatch())return nearestEnemyBld(t,x,y)||fallback;
 // Le nuove ondate possono cambiare fronte; quelle già in marcia conservano
 // la destinazione finché l'avversario è attivo, anche dopo una difesa locale.
 if(aiHardCoop(t)){let enemy=mission?.aiEnemy;if(!isActivePlayer(enemy)||!areEnemies(t,enemy))enemy=aiCoopEnemy(t);if(mission)mission.aiEnemy=enemy;
  const b=bases[enemy];return nearestEnemyBld(t,x,y,enemy)||(b?{x:b.cx*CELL,y:(b.cy+.5)*CELL}:fallback);}
 const plan=aiCoopPlan(t);return plan&&(nearestEnemyBld(t,x,y,plan.enemy)||fallback)||nearestEnemyBld(t,x,y)||fallback;}
function aiCoopWaveReady(ai){const plan=aiCoopPlan(ai.t);if(!plan)return false;
 if(!plan.launchAt||G.t>plan.launchAt+40)plan.launchAt=G.t+12;return G.t>=plan.launchAt;}
function aiCoopAid(ai,army){const t=ai.t,intel=aiCoopIntel(t);
 for(const u of army)if(u.aiAidTeam!=null){const h=teams[u.aiAidTeam]?.home;if(!h||h.dead||!intel.units.some(e=>e.type!=='worker'&&e.type!=='carr'&&hyp(e.x-h.x,e.y-h.y)<550)){u.aiAidTeam=null;u.defendUntil=Math.min(u.defendUntil||0,G.t+8);}}
 if(G.t<(ai.helpAt||0))return;ai.helpAt=G.t+(aiDifficulty(t).advanced?3:5);const home=teams[t].home;
 const reserves=aiFieldArmy(ai,army.filter(u=>!u.wave&&!u.tgt&&!(u.defendUntil>G.t)&&hyp(u.x-home.x,u.y-home.y)<850));if(reserves.length<(aiDefensive(t)?4:8))return;
 let request=null;for(const ally of playerIds()){if(ally===t||!isActivePlayer(ally)||!areAllies(ally,t))continue;const h=teams[ally].home;if(!h||h.dead)continue;
  const threats=intel.units.filter(e=>e.type!=='worker'&&e.type!=='carr'&&hyp(e.x-h.x,e.y-h.y)<550);if(!threats.length)continue;
  const cover=units.filter(u=>!u.dead&&areAllies(t,u.team)&&u.type!=='worker'&&u.type!=='carr'&&(hyp(u.x-h.x,u.y-h.y)<600||u.aiAidTeam===ally&&u.defendUntil>G.t)).length;
  const need=Math.ceil(threats.length*1.35)+3-cover;if(need<=0)continue;const distance=hyp(h.x-home.x,h.y-home.y);if(!request||distance<request.distance)request={ally,threat:threats[0],need,distance};}
 if(!request)return;reserves.sort((a,b)=>hyp(a.x-request.threat.x,a.y-request.threat.y)-hyp(b.x-request.threat.x,b.y-request.threat.y));
 const send=reserves.slice(0,Math.min(reserves.length-(aiDefensive(t)?0:3),request.need));for(const u of send){u.aiAidTeam=request.ally;u.defendUntil=G.t+45;}orderGroup(send,request.threat.x,request.threat.y,false);}
