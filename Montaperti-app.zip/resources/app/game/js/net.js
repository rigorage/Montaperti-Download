'use strict';
// Host autorevole; questo protocollo non modifica le regole della simulazione.
const TYPES=Object.keys(UT),KINDS=Object.keys(BT);
const PEER_URL='https://unpkg.com/peerjs@1.5.4/dist/peerjs.min.js';
const NET_VERSION=10,NET_BUILD='montaperti-1.9.1';
const NET_WARN_MS=4000,NET_DEAD_MS=12000,NET_STEP=1/30;
const LOCAL=new URLSearchParams(location.search).has('local');
const netObj=v=>v!==null&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).every(k=>!['__proto__','constructor','prototype'].includes(k));
const netNum=(v,min=0,max=1e12)=>typeof v==='number'&&Number.isFinite(v)&&v>=min&&v<=max;
const netInt=(v,min=0,max=1e9)=>Number.isInteger(v)&&v>=min&&v<=max;
const netOwn=(o,k)=>typeof k==='string'&&Object.prototype.hasOwnProperty.call(o,k);
const netFac=f=>PLAY_FACS.includes(f);
const netToken=s=>typeof s==='string'&&/^[a-zA-Z0-9_-]{1,64}$/.test(s);
function netId(){if(typeof crypto!=='undefined'&&crypto.getRandomValues){const a=new Uint32Array(3);crypto.getRandomValues(a);return Array.from(a,n=>n.toString(36)).join('-');}return Date.now().toString(36)+'-'+Math.random().toString(36).slice(2);}
function netStatus(text){const el=document.getElementById('netStatus');if(el){el.textContent=text;el.classList.toggle('hidden',!text);}}
function netInterrupted(text){closeCards();const el=document.getElementById('netLost');if(el)el.classList.remove('hidden');const msg=document.getElementById('netLostMsg');if(msg)msg.textContent=text;}
function netSimulationBlocked(){return !!(G&&G.mp&&(G.netWaiting||G.netAborted||(NET&&NET.leaving)));}

// Un solo orologio della simulazione, chiamato sia dal timer sia dai fotogrammi.
// Il browser può sospendere i fotogrammi delle schede nascoste: il timer recupera
// i passi trascorsi (al massimo 2 secondi) senza accelerare al ritorno in primo piano.
function netAdvance(now=performance.now()){const n=NET;if(!n||n.role!=='host'||!G||!G.mp)return;
 now=Math.max(n.simAt,now);const elapsed=(now-n.simAt)/1000;n.simAt=now;
 if(G.over||G.paused||netSimulationBlocked()){n.simDebt=0;return;}
 n.simDebt=Math.min(2,n.simDebt+elapsed);n.pumping=true;
 try{for(let k=0;k<60&&n.simDebt+1e-9>=NET_STEP&&!G.over;k++){n.simDebt=Math.max(0,n.simDebt-NET_STEP);tick(NET_STEP);}}
 finally{n.pumping=false;}
 // Durante un recupero non accodiamo dieci fotografie obsolete dello stesso secondo.
 if(n.snapDue&&!G.over)n.snapDue=!sendSnap(elapsed>=.2);
}
function netConnectionStatus(){const n=NET;if(!n||!G||!G.mp)return;
 if(G.over||G.netAborted){netStatus('');return;}
 const takeover=n.role==='host'&&G.aiTeams&&G.aiTeams.slice(1,n.humanCount).some(Boolean);
 if(takeover&&!n.open){netStatus(playerCount()===2?'AVVERSARIO DISCONNESSO — la partita continua contro l’IA.':'OSPITI DISCONNESSI — la partita continua contro l’IA.');return;}
 if(G.netWaiting)return;
 const slow=netLinks(n).find(e=>e.open&&performance.now()-e.lastSeen>=NET_WARN_MS);
 if(slow){netStatus('Nessuna risposta '+(n.role==='host'?'dal giocatore '+(slow.slot+1):'dall’host')+' da '+Math.floor((performance.now()-slow.lastSeen)/1000)+' s…');return;}
 if(takeover){netStatus('Giocatori disconnessi: l’IA occupa i loro posti. Gli altri continuano online.');return;}
 netStatus(n.open&&n.role==='client'&&n.remoteBackground?'Host in secondo piano: gli aggiornamenti possono arrivare a scatti.':'');
}

// Comandi validati anche quando provengono dall'interfaccia locale.
function validCmd(c){if(!netObj(c)||typeof c.type!=='string')return false;
 const ids=()=>Array.isArray(c.ids)&&c.ids.length<=4096&&c.ids.every(i=>netInt(i,1));
 const xy=()=>netNum(c.x,-WW,WW*2)&&netNum(c.y,-WH,WH*2);
 switch(c.type){
 case 'move':return ids()&&xy()&&(c.forced===undefined||typeof c.forced==='boolean');
 case 'wcmd':return ids()&&xy();
 case 'attack':return ids()&&netInt(c.tid,1);
 case 'hero':return netInt(c.id,1)&&(c.targetId===undefined||c.targetId===null||netInt(c.targetId,1));
 case 'wjob':return ids()&&RES.includes(c.r);
 case 'stop':return ids();
 case 'place':return BUILD_LIST.includes(c.kind)&&Array.isArray(c.cells)&&c.cells.length<=60&&c.cells.every(p=>Array.isArray(p)&&p.length===2&&netInt(p[0],0,GW-1)&&netInt(p[1],0,GH-1));
 case 'train':return netInt(c.bid,1)&&netOwn(UT,c.ty)&&(c.n===undefined||netInt(c.n,1,10));
 case 'cancelTrain':return netInt(c.bid,1)&&netInt(c.i,0,9);
 case 'cancelB':return netInt(c.bid,1);
 case 'rally':return netInt(c.bid,1)&&xy();
 case 'jobs':return netObj(c.jobs)&&RES.every(r=>netInt(c.jobs[r],0,10000))&&(c.newJob===undefined||RES.includes(c.newJob));
 case 'pick':return netOwn(UPI,c.id)&&netInt(c.offerSeq,1);
 case 'reroll':return netInt(c.offerSeq,1);
 case 'cancelWalls':case 'mart':return true;
 default:return false;
 }}
function cmd(c){if(!G||G.over||!isActivePlayer(ME)||netSimulationBlocked()||!netObj(c))return false;
 if((c.type==='pick'||c.type==='reroll')&&c.offerSeq===undefined)c={...c,offerSeq:teams[ME].offerSeq};
 if(!validCmd(c))return false;
 if(isClient()){if(!NET.open||NET.phase!=='playing')return false;return NET.send({t:'c',seq:++NET.commandSeq,c});}return applyCmd(ME,c);}
function byIds(ids,t){const s=new Set(ids);return units.filter(u=>!u.dead&&u.team===t&&s.has(u.id));}
function bById(id){for(const b of blds)if(b.id===id&&!b.dead)return b;return null;}
function anyById(id){for(const u of units)if(u.id===id&&!u.dead)return u;return bById(id);}
function applyCmd(t,c){if(!G||G.over||!isActivePlayer(t)||!validCmd(c))return false;const T=teams[t];
 switch(c.type){
 case 'move':{const l=byIds(c.ids,t).filter(u=>u.type!=='worker');for(const u of l)heroCancelControl(u);if(l.length)orderGroup(l,clamp(c.x,0,WW),clamp(c.y,0,WH),!!c.forced);break;}
 case 'attack':{const tg=anyById(c.tid),l=byIds(c.ids,t).filter(u=>u.type!=='worker');if(!tg||!areEnemies(t,tg.team))return false;for(const u of l)heroCancelControl(u);if(l.length)orderAttack(l,tg);break;}
 case 'hero':return useHeroAbility(t,c.id,c.targetId??null);
 case 'wcmd':{const l=byIds(c.ids,t).filter(u=>u.type==='worker');if(l.length)workerCommand(l,clamp(c.x,0,WW),clamp(c.y,0,WH));break;}
 case 'wjob':for(const u of byIds(c.ids,t))if(u.type==='worker'){changeJob(u,c.r);u.order=null;u.build=null;u.near={x:u.x,y:u.y};}break;
 case 'stop':for(const u of byIds(c.ids,t)){heroCancelControl(u);u.order=null;u.tgt=null;u.palaceAttack=null;u.focus=false;u.path=null;}break;
 case 'place':for(const [cx,cy] of c.cells){if(!canPlace(t,c.kind,cx,cy))continue;if(!canAfford(t,costOf(t,c.kind,true)))break;placeBld(t,c.kind,cx,cy);}break;
 case 'train':{const b=bById(c.bid);if(b&&b.team===t&&Array.isArray(b.def.train)&&b.def.train.includes(c.ty))for(let k=0;k<(c.n||1);k++)if(!train(t,b,c.ty))break;break;}
 case 'cancelTrain':{const b=bById(c.bid);if(b&&b.team===t)cancelTrain(b,c.i);break;}
 case 'cancelB':{const b=bById(c.bid);if(b&&b.team===t)cancelBld(b);break;}
 case 'cancelWalls':for(const b of blds.slice())if(b.team===t&&b.def.wall&&!b.built)cancelBld(b);break;
 case 'rally':{const b=bById(c.bid);if(b&&b.team===t&&b.def.train)b.rally={x:clamp(c.x,0,WW),y:clamp(c.y,0,WH)};break;}
 case 'jobs':{const j={g:c.jobs.g,l:c.jobs.l,p:c.jobs.p},n=workerCount(t);let excess=j.g+j.l+j.p-n;
  // Stessa priorità di balanceJobs, senza cicli proporzionali ai dati ricevuti.
  for(const r of ['p','l','g']){const k=Math.min(j[r],Math.max(0,excess));j[r]-=k;excess-=k;}
  if(c.newJob)T.newJob=c.newJob;if(excess<0)j[T.newJob]-=excess;T.jobs=j;balanceJobs(t);break;}
 case 'mart':ringMart(t);break;
 case 'pick':return takeOffer(t,c.id,c.offerSeq);
 case 'reroll':return c.offerSeq===T.offerSeq&&rerollOffer(t);
 }return true;}

// Trasporto e vita della sessione. Ogni callback è legata alla sessione che l'ha creata.
let peerLoad=null;
function loadPeer(){if(window.Peer)return Promise.resolve();if(peerLoad)return peerLoad;
 peerLoad=new Promise((ok,ko)=>{const s=document.createElement('script');let done=false;const finish=err=>{if(done)return;done=true;clearTimeout(timer);s.onload=s.onerror=null;if(err){s.remove();ko(err);}else ok();};
  const timer=setTimeout(()=>finish(new Error('Tempo scaduto durante il caricamento del collegamento online.')),12000);
  s.src=PEER_URL;s.crossOrigin='anonymous';s.onload=()=>finish(window.Peer?null:new Error('Libreria online non disponibile.'));s.onerror=()=>finish(new Error('Collegamento online non raggiungibile: controlla Internet e la rete di lavoro.'));document.head.appendChild(s);
 }).catch(e=>{peerLoad=null;throw e;});return peerLoad;}
function newCode(){const A='ABCDEFGHJKLMNPQRSTUVWXYZ';let s='';for(let k=0;k<5;k++)s+=A[(Math.random()*A.length)|0];return s;}
// Ogni ospite ha una sequenza, un budget e una coda indipendenti.
function netLink(slot){const now=performance.now();return {slot,remoteId:null,peerFac:null,peerName:null,transport:null,conn:null,open:false,ready:false,
 created:now,connectedAt:now,lastSeen:now,lastPing:0,lastHello:0,lastInit:0,lastFinal:0,lastSeq:0,lastCommand:0,commandSeq:0,snapN:0,bad:0,rtt:0,finalAck:false,transportLostAt:null,
 events:[],resources:new Set(),budget:{tokens:400,time:now},commandBudget:{tokens:160,time:now}};}
function netLinks(n=NET){return !n?[]:n.role==='host'?n.guests.slice(1).filter(Boolean):[n];}
const netTeamMode=mode=>mode==='coop'||mode==='teams';
function netHostCount(){const mode=document.getElementById('mpMode'),counts={duel:2,ffa:3,ffa4:4,coop2:2,coop:3,coop4:4,coop5:5,teams:4};if(mode&&counts[mode.value])return counts[mode.value];const e=document.getElementById('mpPlayers');return e&&['3','4'].includes(String(e.value))?Number(e.value):2;}
function netConfig(input){const selected=document.getElementById('mpMode'),cfg=netObj(input)?input:{},options=['duel','ffa','ffa4','coop2','coop','coop4','coop5','teams'];
 const option=typeof input==='number'?(input===4?'ffa4':input===3?'ffa':'duel'):options.includes(cfg.mode)?cfg.mode:selected&&options.includes(selected.value)?selected.value:netHostCount()===4?'ffa4':netHostCount()===3?'ffa':'duel';
 const mode=option==='ffa4'?'ffa':['coop2','coop4','coop5'].includes(option)?'coop':option,coop=mode==='coop';
 const count=coop?(option==='coop5'?10:option==='coop4'?8:option==='coop2'?4:[4,8,10].includes(cfg.count)?cfg.count:6):mode==='teams'?4:mode==='ffa'?(option==='ffa4'||cfg.count===4?4:3):2,humanCount=coop?count/2:count,diff=coop&&String(cfg.diff===undefined?document.getElementById('coopDiff')?.value:cfg.diff)==='2'?2:1;
 return {mode,count,humanCount,diff,sides:Array.from({length:count},(_,i)=>netTeamMode(mode)?(i<count/2?0:1):i)};}
function netMatchConfig(n=NET){return {mode:n.mode,count:n.count,humanCount:n.humanCount,sides:n.sides.slice(),diff:n.diff};}
function validNetConfig(m){if(!netObj(m)||!['duel','ffa','coop','teams'].includes(m.mode))return false;const coop=m.mode==='coop',count=m.count;
 if(!(coop?[4,6,8,10].includes(count):m.mode==='ffa'?[3,4].includes(count):m.mode==='teams'?count===4:count===2))return false;const humanCount=coop?count/2:count;
 return m.humanCount===humanCount&&(m.diff===1||(coop&&m.diff===2))&&Array.isArray(m.sides)&&m.sides.length===count&&m.sides.every((s,i)=>s===(netTeamMode(m.mode)?(i<count/2?0:1):i));}
function sameNetConfig(m,n=NET){return validNetConfig(m)&&m.mode===n.mode&&m.count===n.count&&m.humanCount===n.humanCount&&m.diff===n.diff&&m.sides.every((s,i)=>s===n.sides[i]);}
function validAiTeams(a,cfg){return Array.isArray(a)&&a.length===cfg.count&&a.every((v,i)=>typeof v==='boolean'&&(i<cfg.humanCount||v));}
function netReset(role,input){netDispose();const config=netConfig(input),now=performance.now(),n={role,id:netId(),fac:startFac,...config,slot:role==='host'?0:1,phase:'connecting',ev:[],dirty:new Set(),peer:null,bc:null,roster:[],
 acc:0,snapAt:now,created:now,match:null,simAt:now,simDebt:0,pumping:false,snapDue:false,serviceAt:now,resumeUntil:0,leaving:false};
 if(role==='host'){n.botFacs=n.mode==='coop'?Array.from({length:n.humanCount},(_,i)=>{const f=Number(netObj(input)&&input.botFacs?input.botFacs[i]:document.getElementById('botFac'+i)?.value);return netFac(f)?f:PLAY_FACS[(Math.random()*PLAY_FACS.length)|0];}):[];n.guests=Array.from({length:n.humanCount},(_,i)=>i?netLink(i):null);
  // Compatibilità delle API locali a due giocatori: i campi del primo ospite restano accessibili.
  for(const k of Object.keys(n.guests[1]))if(!['slot','created','events','resources','open'].includes(k))Object.defineProperty(n,k,{get:()=>n.guests[1][k],set:v=>{n.guests[1][k]=v;},configurable:true});
  Object.defineProperty(n,'open',{get:()=>netLinks(n).some(e=>e.open),set:v=>{n.guests[1].open=v;}});
 }else Object.assign(n,netLink(1));
 NET=n;n.send=m=>netSend(n,m);n.timer=setInterval(()=>{if(NET===n){netService();netAdvance();}},100);return n;}
function netDispose(){const n=NET;if(!n)return;NET=null;clearInterval(n.timer);clearTimeout(n.leaveTimer);n.ev.length=0;n.dirty.clear();
 for(const e of netLinks(n)){e.open=false;try{if(e.conn)e.conn.close();}catch(err){}}try{if(n.bc)n.bc.close();}catch(e){}try{if(n.peer)n.peer.destroy();}catch(e){}netStatus('');}
function netCancel(){if(NET)NET.send({t:'bye'});netDispose();document.getElementById('lobby').classList.add('hidden');}
function netLeave(after){const n=NET;if(!n){if(after)after();return;}if(n.leaving)return;n.send({t:'bye'});n.leaving=true;clearInterval(n.timer);
 if(G&&G.mp&&!G.over)G.netAborted=true;for(const e of netLinks(n))try{if(e.conn&&e.conn.open)e.conn.close({flush:true});}catch(err){}
 n.leaveTimer=setTimeout(()=>{if(NET!==n)return;netDispose();if(after)after();},200);}
function netLobbyFailure(n,message){if(NET!==n)return;netDispose();document.getElementById('lobbyGo').classList.add('hidden');lobbyMsg(message+' Annulla e riprova.');}
function netSend(n,m,to,endpoint){if(NET!==n)return false;
 if(!endpoint&&n.role==='host'){const links=netLinks(n).filter(e=>e.transport&&(to?e.remoteId===to:e.open));if(!links.length&&n.bc&&to){try{n.bc.postMessage({...m,v:NET_VERSION,build:NET_BUILD,from:n.id,to});return true;}catch(e){return false;}}
  let sent=false;for(const e of links)sent=netSend(n,m,to,e)||sent;return sent;}
 const e=endpoint||n;if(!e.transport)return false;if(e.conn&&(e.conn.bufferSize>32||(e.conn.dataChannel&&e.conn.dataChannel.bufferedAmount>1024*1024)))return false;
 try{e.transport({...m,v:NET_VERSION,build:NET_BUILD,from:n.id,to:to===undefined?e.remoteId:to});return true;}catch(err){onConnClose('Il collegamento non è più disponibile.',n,e);return false;}}
function netBudget(bucket,now,rate,cap){bucket.tokens=Math.min(cap,bucket.tokens+Math.max(0,now-bucket.time)*rate/1000);bucket.time=now;if(bucket.tokens<1)return false;bucket.tokens--;return true;}
function netBad(n,e=n.role==='host'?n.guests[1]:n){if(++e.bad>=5)onConnClose('Messaggi non validi: riaprite la stessa versione del gioco.',n,e);}
function netReject(n,text,to,e){netSend(n,{t:'reject',reason:text},to,e);}
function netRoster(n=NET){return Array.from({length:n.count},(_,slot)=>{const bot=slot>=n.humanCount,e=n.guests[slot];return {slot,side:n.sides[slot],kind:bot?'bot':'human',fac:bot?n.botFacs[slot-n.humanCount]:slot===0?n.fac:e.peerFac,state:bot?'ai':slot===0?'host':e.open?'ready':n.match&&G&&G.aiTeams&&G.aiTeams[slot]?'ai':'waiting'};});}
function netLobbyPublish(n=NET){if(!n||n.role!=='host')return;n.roster=netRoster(n);for(const e of netLinks(n))if(e.open)netSend(n,{t:'roster',...netMatchConfig(n),roster:n.roster},undefined,e);lobbyUpdate();}
function validRoster(r,cfg){return Array.isArray(r)&&r.length===cfg.count&&r.every((p,i)=>netObj(p)&&p.slot===i&&p.side===cfg.sides[i]&&p.kind===(i<cfg.humanCount?'human':'bot')&&(i>=cfg.humanCount?netFac(p.fac)&&p.state==='ai':(p.fac===null||netFac(p.fac))&&(i===0?p.state==='host'&&netFac(p.fac):['ready','waiting','ai'].includes(p.state))));}
function netMaybePlay(n){if(n.role!=='host'||n.phase!=='starting')return;const pending=netLinks(n).some(e=>e.open&&!e.ready);if(pending)return;
 n.phase='playing';G.netWaiting=false;n.simAt=performance.now();n.simDebt=0;netStatus('');sendSnap(true);}
function onConnData(m,n=NET,endpoint){if(!n||NET!==n||n.leaving||!netObj(m)||typeof m.t!=='string')return;if(m.from===n.id||(m.to&&m.to!==n.id))return;
 let e=endpoint;if(n.role==='host'&&!e){e=netLinks(n).find(x=>x.remoteId===m.from);if(!e&&m.t==='hello'&&!n.match)e=netLinks(n).find(x=>!x.remoteId&&!x.conn);if(!e){if(m.t==='hello')netReject(n,n.match?'Partita già iniziata.':'Stanza già occupata.',m.from);return;}if(n.bc&&!e.transport)e.transport=v=>n.bc.postMessage(v);}
 e=e||n;if(n.role==='host'&&n.guests[e.slot]!==e)return;if(!netToken(m.from))return netBad(n,e);
 if(e.remoteId&&m.from!==e.remoteId){if(n.role==='host'&&m.t==='hello')netReject(n,'Posto già occupato.',m.from,e);return;}
 const now=performance.now();if(!netBudget(e.budget,now,200,400))return onConnClose('Troppi messaggi ricevuti: collegamento interrotto.',n,e);
 if(m.t==='reject'){if(typeof m.reason==='string'&&n.role==='client')onConnClose(m.reason.slice(0,200),n,e);return;}
 if(m.v!==NET_VERSION||m.build!==NET_BUILD){const reason='Versioni diverse: aggiornate tutti Montaperti alla versione 1.9.1.';netReject(n,reason,m.from,e);onConnClose(reason,n,e);return;}
 if(m.t==='hello'&&n.role==='host'){
  if(!netFac(m.fac))return netBad(n,e);if(n.match)return netReject(n,'Partita già iniziata.',m.from,e);
  if(netLinks(n).some(other=>other!==e&&other.remoteId===m.from)){netReject(n,'Identità del giocatore già collegata.',m.from,e);onConnClose('Identità del giocatore duplicata.',n,e);return;}
  e.remoteId=m.from;e.peerFac=m.fac;e.peerName=typeof m.name==='string'?m.name.slice(0,40):'Giocatore '+(e.slot+1);e.open=true;e.lastSeen=now;n.phase='lobby';
  netSend(n,{t:'welcome',fac:n.fac,slot:e.slot,...netMatchConfig(n),roster:netRoster(n)},undefined,e);netLobbyPublish(n);return;}
 if(m.t==='welcome'&&n.role==='client'&&!n.match){if(!netFac(m.fac)||!validNetConfig(m)||!netInt(m.slot,1,m.humanCount-1)||!validRoster(m.roster,m)||m.roster[m.slot].fac!==n.fac||m.roster[0].fac!==m.fac||(n.open&&(!sameNetConfig(m,n)||m.slot!==n.slot)))return netBad(n,e);
  n.remoteId=m.from;n.hostFac=m.fac;n.slot=m.slot;Object.assign(n,netMatchConfig(m));n.roster=m.roster;n.open=true;n.phase='lobby';n.lastSeen=now;lobbyUpdate();return;}
 if(!e.open||!e.remoteId)return;
 switch(m.t){
 case 'roster':if(n.role!=='client'||!sameNetConfig(m,n)||!validRoster(m.roster,n)||m.roster[n.slot].fac!==n.fac||m.roster[0].fac!==n.hostFac)return netBad(n,e);n.roster=m.roster;e.lastSeen=now;lobbyUpdate();break;
 case 'init':if(n.role!=='client'||!netToken(m.match)||!netInt(m.seed,0,1e9)||!sameNetConfig(m,n)||m.slot!==n.slot||!Array.isArray(m.facs)||m.facs.length!==n.count||!m.facs.every((f,t)=>netFac(f)&&(t<n.humanCount||f===n.roster[t].fac))||m.facs[0]!==n.hostFac||m.facs[n.slot]!==n.fac||!validAiTeams(m.aiTeams,n)||!m.aiTeams.every((v,i)=>v===(i>=n.humanCount)))return netBad(n,e);
  if(n.match&&n.match!==m.match)return netBad(n,e);e.lastSeen=now;
  if(!n.match){n.match=m.match;n.phase='starting';try{clientStart(m);G.netWaiting=true;netStatus('Attendo l’avvio della partita…');}catch(err){onConnClose('Impossibile avviare la partita. Ricarica il gioco.',n,e);return;}}
  n.send({t:'ready',match:n.match});break;
 case 'ready':if(n.role!=='host'||m.match!==n.match||!G)return netBad(n,e);e.lastSeen=now;e.ready=true;netMaybePlay(n);break;
 case 's':if(n.role!=='client'||!G||m.match!==n.match||!validSnapshot(m))return netBad(n,e);e.lastSeen=now;
  if(m.seq>n.lastSeq){n.lastSeq=m.seq;n.remoteBackground=m.background;clientSnap(m);G.netWaiting=false;n.phase=G.over?'ended':'playing';netConnectionStatus();}if(m.over)clientFinish(m.winner,m.winnerSide);break;
 case 'c':if(n.role!=='host'||n.phase!=='playing'||!G||G.over||!netInt(m.seq,1)||!validCmd(m.c))return netBad(n,e);e.lastSeen=now;
  if(m.seq<=e.lastCommand)return;e.lastCommand=m.seq;if(netSimulationBlocked())return;
  if(!netBudget(e.commandBudget,now,80,160))return onConnClose('Troppi comandi ricevuti.',n,e);applyCmd(e.slot,m.c);if(m.c.type==='pick'||m.c.type==='reroll')sendSnap(true);break;
 case 'ackEnd':if(n.role==='host'&&m.match===n.match&&G&&G.over&&m.winner===G.winner&&m.winnerSide===(netTeamMode(G.mode)?G.winnerSide:null)){e.finalAck=true;e.lastSeen=now;}break;
 case 'status':if(n.role!=='client'||typeof m.background!=='boolean')return netBad(n,e);n.remoteBackground=m.background;e.lastSeen=now;netConnectionStatus();break;
 case 'ping':if(!netNum(m.ts))return netBad(n,e);e.lastSeen=now;netSend(n,{t:'pong',ts:m.ts},undefined,e);break;
 case 'pong':if(!netNum(m.ts))return netBad(n,e);e.lastSeen=now;e.rtt=Math.max(0,now-m.ts);break;
 case 'bye':e.lastSeen=now;onConnClose('L’altro giocatore ha lasciato la partita.',n,e);break;
 default:netBad(n,e);
 }}
function onConnClose(reason='L’altro giocatore si è disconnesso.',n=NET,endpoint){if(!n||NET!==n||n.leaving)return;const e=endpoint||(n.role==='host'?n.guests[1]:n);if(n.role==='host'&&n.guests[e.slot]!==e)return;
 const active=!!n.match,conn=e.conn;e.open=false;e.ready=false;e.conn=null;e.remoteId=null;e.peerFac=null;e.events.length=0;e.resources.clear();e.transport=n.bc?(m=>n.bc.postMessage(m)):null;
 try{if(conn)conn.close();}catch(err){}
 if(active&&G&&!G.over&&!G.netAborted){
  if(n.role==='host'){G.aiTeams=G.aiTeams||Array(playerCount()).fill(false);if(isActivePlayer(e.slot)&&!G.aiTeams[e.slot]){G.aiTeams[e.slot]=true;if(playerCount()===2&&e.slot===1)G.aiTakeover=true;if(!AIS.some(a=>a.t===e.slot))AIS.push(mkAI(e.slot));toast('Giocatore '+(e.slot+1)+' disconnesso: l’IA prende il suo posto.','#ffd76a',4000);}netMaybePlay(n);netConnectionStatus();if(n.phase!=='starting')sendSnap(true);}
  else{n.phase='disconnected';G.netWaiting=false;G.netAborted=true;netStatus('');netInterrupted(reason+' La partita è interrotta; nessun vincitore è stato assegnato.');}
 }else if(!active){if(n.role==='host'){n.guests[e.slot]=netLink(e.slot);n.phase=n.open?'lobby':'listening';netLobbyPublish(n);}else n.phase='failed';document.getElementById('lobbyGo').classList.add('hidden');lobbyMsg(reason+(n.role==='host'?' La stanza resta disponibile.':''));}
 if(!n.open){n.ev.length=0;n.dirty.clear();}
 if(!active&&n.role==='client'){clearInterval(n.timer);try{if(n.bc)n.bc.close();if(n.peer)n.peer.destroy();}catch(err){}}
}
function netTransportCheck(n,now=performance.now(),endpoint){if(NET!==n||n.leaving)return;for(const e of endpoint?[endpoint]:netLinks(n)){if(!e.open||!e.conn)continue;const dc=e.conn.dataChannel,pc=e.conn.peerConnection;
  if(e.conn.open===false||(dc&&dc.readyState==='closed')||(pc&&['closed','failed'].includes(pc.connectionState))){onConnClose('Il collegamento con il giocatore è stato chiuso.',n,e);continue;}
  if(pc&&pc.connectionState==='disconnected'){if(e.transportLostAt===null)e.transportLostAt=now;if(now-e.transportLostAt>=8000&&now-e.lastSeen>=8000)onConnClose('Connessione con il giocatore persa.',n,e);}else e.transportLostAt=null;}}
function netService(){const n=NET;if(!n||n.leaving)return;const now=performance.now();if(now-n.serviceAt>5000)n.resumeUntil=now+3000;n.serviceAt=now;netTransportCheck(n,now);if(NET!==n)return;
 if(n.role==='host'&&!n.roomReady&&now-n.created>20000){netLobbyFailure(n,'Il servizio delle stanze non risponde.');return;}
 if(n.phase==='connecting'&&now-n.created>20000){onConnClose('Connessione scaduta. Controlla il codice e la connessione Internet.',n);return;}
 if(n.role==='client'&&!n.open&&n.phase==='connecting'&&n.transport&&now-n.lastHello>1000){n.lastHello=now;n.send({t:'hello',fac:n.fac});}
 for(const e of netLinks(n)){if(e.open){
  if(n.phase==='starting'&&n.role==='host'&&!e.ready&&now-n.startAt>20000){onConnClose('Il giocatore non è riuscito ad avviare la partita.',n,e);continue;}
  if(now-e.lastSeen>=NET_DEAD_MS&&now>=n.resumeUntil){onConnClose('Nessuna risposta dall’altro giocatore per 12 secondi.',n,e);continue;}
  if(now-e.lastPing>=1000){e.lastPing=now;netSend(n,{t:'ping',ts:now},undefined,e);}
  if(n.role==='host'&&n.phase==='starting'&&!e.ready&&now-e.lastInit>=1000){e.lastInit=now;netSend(n,e.initPacket,undefined,e);}
  if(n.role==='host'&&G&&G.over&&!e.finalAck&&now-e.lastFinal>=1000){e.lastFinal=now;sendSnap(true);}
 }if(e.conn&&!e.open&&now-e.connectedAt>15000)onConnClose('Il giocatore non ha completato il collegamento.',n,e);}
 netConnectionStatus();}
function netVisibility(){if(!NET)return;netService();netAdvance();if(isHost()&&NET.open&&G&&G.mp&&!G.over)NET.send({t:'status',background:!!document.hidden});netConnectionStatus();}
function bindConnection(n,conn,endpoint){const e=endpoint||(n.role==='host'?netLinks(n).find(x=>!x.conn&&!x.remoteId):n);if(!e){conn.close();return;}e.conn=conn;e.connectedAt=performance.now();
 const current=()=>NET===n&&e.conn===conn&&(n.role!=='host'||n.guests[e.slot]===e);
 // JSON conserva il formato del protocollo; BinaryPack lo suddivide oltre 16.300 byte.
 // Il serializer "json" di PeerJS rifiuta invece gli aggiornamenti grandi.
 conn.on('open',()=>{if(!current())return;e.transport=m=>conn.send(JSON.stringify(m));const close=()=>{if(current())onConnClose(undefined,n,e);},check=()=>{if(current())netTransportCheck(n,performance.now(),e);};
  if(conn.dataChannel&&conn.dataChannel.addEventListener)conn.dataChannel.addEventListener('close',close);if(conn.peerConnection&&conn.peerConnection.addEventListener)conn.peerConnection.addEventListener('connectionstatechange',check);if(n.role==='client')n.send({t:'hello',fac:n.fac});});
 conn.on('data',data=>{if(!current())return;let m=data;if(typeof m==='string'){if(m.length>2*1024*1024)return netBad(n,e);try{m=JSON.parse(m);}catch(err){return netBad(n,e);}}onConnData(m,n,e);});conn.on('close',()=>{if(current())onConnClose(undefined,n,e);});conn.on('error',()=>{if(current())onConnClose('Errore nel collegamento con il giocatore.',n,e);});}
async function hostLobby(attempt=0){if(G&&!G.over)return;const n=netReset('host');n.code=newCode();n.phase='listening';lobbyShow(true);
 if(LOCAL){try{n.bc=new BroadcastChannel('montaperti-'+n.code);n.bc.onmessage=e=>onConnData(e.data,n);n.roomReady=true;lobbyCode(n.code);}catch(e){netLobbyFailure(n,'Prova locale non disponibile. Usa il collegamento online.');}return;}
 lobbyMsg('Apro la stanza…');try{await loadPeer();if(NET!==n)return;const peer=new window.Peer('montaperti-'+n.code.toLowerCase());n.peer=peer;
 peer.on('open',()=>{if(NET===n){n.roomReady=true;lobbyCode(n.code);}});
 peer.on('error',e=>{if(NET!==n||n.open)return;if(e.type==='unavailable-id'&&attempt<3){hostLobby(attempt+1);return;}netLobbyFailure(n,'Impossibile aprire o mantenere la stanza. Controlla Internet.');});
 peer.on('connection',conn=>{if(NET!==n||n.match||!netLinks(n).some(e=>!e.conn&&!e.remoteId)){conn.close();return;}bindConnection(n,conn);});peer.on('disconnected',()=>{if(NET===n&&!n.open)lobbyMsg('Il servizio delle stanze non risponde. Annulla e riprova.');});
 }catch(e){netLobbyFailure(n,e.message||'Collegamento online non disponibile.');}}
async function joinLobby(code){if(G&&!G.over)return;code=(typeof code==='string'?code:'').trim().toUpperCase();netDispose();lobbyShow(false);if(!/^[ABCDEFGHJKLMNPQRSTUVWXYZ]{5}$/.test(code)){lobbyMsg('Inserisci le 5 lettere del codice ricevuto dall’host.');return;}
 const n=netReset('client');n.code=code;lobbyMsg('Cerco la stanza '+code+'…');
 if(LOCAL){try{n.bc=new BroadcastChannel('montaperti-'+code);n.transport=m=>n.bc.postMessage(m);n.bc.onmessage=e=>onConnData(e.data,n);n.send({t:'hello',fac:n.fac});}catch(e){onConnClose('Prova locale non disponibile. Usa il collegamento online.',n);}return;}
 try{await loadPeer();if(NET!==n)return;const peer=new window.Peer();n.peer=peer;peer.on('error',e=>{if(NET!==n)return;
  // Il servizio delle stanze può cadere mentre il canale diretto continua a funzionare.
  if(n.open&&['network','socket-error','socket-closed','server-error'].includes(e.type)){netTransportCheck(n);return;}
  onConnClose(e.type==='peer-unavailable'?'Stanza non trovata: controlla il codice.':'Collegamento non riuscito: controlla Internet e riprova.',n);
 });peer.on('open',()=>{if(NET===n)bindConnection(n,peer.connect('montaperti-'+code.toLowerCase(),{reliable:true,serialization:'binary'}));});}catch(e){if(NET===n)onConnClose(e.message||'Collegamento online non disponibile.',n);}}
function hostStart(){const n=NET;if(!isHost()||n.phase!=='lobby'||!netLinks(n).every(e=>e.open&&netFac(e.peerFac)))return;
 n.match=netId();n.phase='starting';n.startAt=performance.now();document.getElementById('lobby').classList.add('hidden');document.getElementById('start').classList.add('hidden');
 try{const facs=[n.fac,...netLinks(n).map(e=>e.peerFac),...n.botFacs],aiTeams=facs.map((_,i)=>i>=n.humanCount);newGame(n.fac,n.diff,facs[1],{mp:true,mode:n.mode,facs,aiTeams});G.netWaiting=true;for(const e of netLinks(n)){e.ready=false;e.initPacket={t:'init',match:n.match,seed:G.seed,facs,aiTeams,...netMatchConfig(n),slot:e.slot};e.lastInit=performance.now();netSend(n,e.initPacket,undefined,e);}netStatus('Attendo che tutti i giocatori siano pronti…');}
 catch(e){G=null;netDispose();window.MontapertiBoot.fail('Impossibile preparare la partita. Ricarica e riprova.',e);}}
function netFinish(){if(!isHost()||!G||!G.over)return;NET.phase='ended';for(const e of netLinks()){e.finalAck=false;e.lastFinal=performance.now();}sendSnap(true);}
function clientFinish(w,side=null){if(!G||(w!==null&&!netInt(w,0,playerCount()-1))||(netTeamMode(G.mode)?(w===null?side!==null:side!==sideOf(w)):side!==null))return;if(!G.over){G.over=true;G.winner=w;G.winnerSide=side;G.netWaiting=false;closeCards();netStatus('');endGame(w);}if(NET){NET.phase='ended';NET.send({t:'ackEnd',match:NET.match,winner:w,winnerSide:side});}}

// Validazione dello stato ricevuto; nessun oggetto remoto viene usato come codice.
function validMods(m){const base=baseMods();return netObj(m)&&Object.keys(m).length===Object.keys(base).length&&Object.keys(base).every(k=>typeof base[k]==='number'?netNum(m[k],0,1e6):netObj(m[k])&&Object.keys(m[k]).length===Object.keys(base[k]).length&&Object.keys(base[k]).every(s=>netNum(m[k][s],0,1e6)));}
function validResources(r){return netObj(r)&&Object.keys(r).every(k=>RES.includes(k))&&Object.values(r).every(v=>netNum(v));}
function validCardProgress(p){return netObj(p)&&Object.keys(p).length<=UPS.length&&Object.keys(p).every(id=>netOwn(UPI,id)&&netInt(p[id],0,1e6));}
function validReinforcements(q){return Array.isArray(q)&&q.length<=TYPES.length&&new Set(q.map(e=>e&&e.type)).size===q.length&&q.every(e=>netObj(e)&&Object.keys(e).length===2&&netOwn(UT,e.type)&&!UT[e.type].hero&&netInt(e.count,1,1e6));}
const NET_CARD_COUNTERS=['attacks','shots','cavHits','vsCavShots','siegeShots'],NET_CARD_COUNTER_MAX=[2,11,2,3,3];
function validUnitStates(m,owners){if(!Array.isArray(m.hu)||m.hu.length>owners.size||!Array.isArray(m.uc)||m.uc.length>owners.size)return false;
 const heroIds=new Set(),cardIds=new Set();for(const r of m.hu){if(!Array.isArray(r)||r.length!==HERO_NET_LIMITS.length+1||!netInt(r[0],1)||!owners.has(r[0])||heroIds.has(r[0])||!heroValidNetState(r.slice(1)))return false;heroIds.add(r[0]);}
 for(const r of m.uc){if(!Array.isArray(r)||r.length!==6||!netInt(r[0],1)||owners.get(r[0])!==m.slot||cardIds.has(r[0])||!r.slice(1).every((v,i)=>netInt(v,0,NET_CARD_COUNTER_MAX[i])))return false;cardIds.add(r[0]);}return true;}
function validTeam(s,t,recipient=ME,final=false){const common=['fac','popUsed','popMax','martT','mods','carr','kills','lost','made','upsTaken','eliminated','tagN'];if(final)common.push('gath');
 const extra=['res','gath','jobs','newJob','noFarm','upT','glory','gloryNeed','ups','rerolls','picks','offer','offerSeq','martCd','cardCooldowns','cardProgress','reinforcementQueue','heroReviveLeft'];
 if(!netObj(s)||Object.keys(s).some(k=>!common.includes(k)&&!(t===recipient&&extra.includes(k)))||s.fac!==teams[t].fac||!validMods(s.mods)||!netObj(s.tagN)||!Object.keys(s.tagN).every(k=>TAGS.includes(k)&&netInt(s.tagN[k],0,1e6))||typeof s.eliminated!=='boolean'||!netNum(s.martT,-10)||!['popUsed','popMax','carr','kills','lost','made','upsTaken'].every(k=>netInt(s[k],0,1e9)))return false;
 if(t!==recipient)return !final||(validResources(s.gath)&&RES.every(r=>netNum(s.gath[r])));
 return netObj(s.cardCooldowns)&&Object.keys(s.cardCooldowns).length===2&&['martinella','spesse'].every(k=>netNum(s.cardCooldowns[k],0,90))&&netInt(s.heroReviveLeft,0,600)&&validCardProgress(s.cardProgress)&&validReinforcements(s.reinforcementQueue)&&validResources(s.res)&&RES.every(r=>netNum(s.res[r]))&&validResources(s.gath)&&RES.every(r=>netNum(s.gath[r]))&&netObj(s.jobs)&&RES.every(r=>netInt(s.jobs[r],0,10000))&&RES.includes(s.newJob)&&typeof s.noFarm==='boolean'&&netNum(s.upT,-1)&&netNum(s.glory)&&netNum(s.gloryNeed,1)&&netInt(s.rerolls,0,10000)&&netNum(s.martCd,-10)&&
 netObj(s.ups)&&Object.keys(s.ups).every(k=>netOwn(UPI,k)&&netInt(s.ups[k],0,UPI[k].max))&&
 Array.isArray(s.picks)&&s.picks.length<=1024&&s.picks.every(p=>netObj(p)&&['preparativi','tempo','gloria','reliquia'].includes(p.src)&&netNum(p.at)&&(p.minR===undefined||['C','R','E'].includes(p.minR)))&&netInt(s.offerSeq,0)&&
 (s.offer==null||(Array.isArray(s.offer)&&s.offer.length===3&&new Set(s.offer).size===3&&s.offer.every(id=>netOwn(UPI,id))));}
function validCamp(s){return Array.isArray(s)&&s.length===4&&[0,1].includes(s[0])&&netInt(s[1],-1,playerCount()-1)&&[0,1].includes(s[2])&&Array.isArray(s[3])&&s[3].length<=2&&s[3].every(id=>netInt(id,1))&&new Set(s[3]).size===s[3].length&&
 (s[2]===1?s[0]===0&&s[1]>=0&&s[3].length===2:s[0]===1&&s[1]===-1&&s[3].length===0);}
function validEvent(e,recipient=ME){if(!Array.isArray(e)||e.length>10)return false;const coord=v=>netNum(v,-100000,100000),bit=v=>v===0||v===1;
 switch(e[0]){
 case 'p':return e.length===8&&['b','s'].includes(e[1])&&e.slice(2,6).every(coord)&&netNum(e[6],0,1e6)&&netInt(e[7],0,3);
 case 'd':return e.length===7&&coord(e[1])&&coord(e[2])&&[-1,1].includes(e[3])&&netInt(e[4],0,FAC.length-1)&&bit(e[5])&&bit(e[6]);
 case 'x':return e.length===6&&coord(e[1])&&coord(e[2])&&netInt(e[3],1,GW)&&netInt(e[4],1,GH)&&bit(e[5]);
 case 'h':return e.length===6&&coord(e[1])&&coord(e[2])&&netNum(e[3])&&bit(e[4])&&bit(e[5]);
 case 'end':return e.length===2&&(e[1]===null||netInt(e[1],0,playerCount()-1));
 case 'n':if(e.length!==4||e[1]!==recipient||!Array.isArray(e[3]))return false;const a=e[3];
  if(e[2]==='toast')return a.length<=3&&typeof a[0]==='string'&&a[0].length<=500&&(a[1]==null||(typeof a[1]==='string'&&a[1].length<=64))&&(a[2]==null||netNum(a[2],0,30000));
  if(e[2]==='sfx')return a.length<=3&&typeof a[0]==='string'&&a[0].length<32&&a.slice(1).every(coord);
  if(e[2]==='ping')return a.length===2&&a.every(coord);return e[2]==='flash'&&a.length===0;
 default:return false;
 }}
function validSnapshot(m){if(!netObj(m)||!sameNetConfig(m)||m.count!==playerCount()||!netInt(m.slot,1,m.humanCount-1)||(isClient()&&m.slot!==ME)||!Array.isArray(m.facs)||m.facs.length!==m.count||!m.facs.every((f,t)=>f===teams[t].fac)||!Array.isArray(m.eliminated)||m.eliminated.length!==m.count||!m.eliminated.every(x=>typeof x==='boolean')||!validAiTeams(m.aiTeams,m))return false;
 if(m.over&&netTeamMode(m.mode)?(m.winner===null?m.winnerSide!==null:!netInt(m.winner,0,m.count-1)||m.winnerSide!==m.sides[m.winner]):m.winnerSide!==null)return false;
 if(!netInt(m.seq,1)||!netNum(m.gt)||typeof m.over!=='boolean'||typeof m.background!=='boolean'||(m.over?m.winner!==null&&!netInt(m.winner,0,playerCount()-1):m.winner!==null)||!Array.isArray(m.u)||m.u.length%9||m.u.length>90000||!Array.isArray(m.ev)||m.ev.length>2048||!m.ev.every(e=>validEvent(e,m.slot))||!Array.isArray(m.res)||m.res.length%4||m.res.length>NCELL*4||!Array.isArray(m.camps)||m.camps.length!==camps.length||!m.camps.every(validCamp))return false;
 const ids=new Set(),owners=new Map();for(let i=0;i<m.u.length;i+=9){const a=m.u,id=a[i];if(!netInt(id,1)||ids.has(id)||!netInt(a[i+1],0,TYPES.length-1)||!netInt(a[i+2],0,neutralTeam())||!netNum(a[i+3],0,WW)||!netNum(a[i+4],0,WH)||!netNum(a[i+5],0)||!netNum(a[i+6],1)||!netInt(a[i+7],0,65535)||!netNum(a[i+8],-1,1e6))return false;ids.add(id);owners.set(id,a[i+2]);const old=uMap.get(id);if(old&&(old.type!==TYPES[a[i+1]]||old.team!==a[i+2]))return false;}
 if(!validUnitStates(m,owners))return false;
 for(let i=0;i<m.res.length;i+=4)if(!netInt(m.res[i],0,NCELL-1)||!netNum(m.res[i+1])||!netNum(m.res[i+2])||![0,1].includes(m.res[i+3]))return false;
 if(m.tm&&(!Array.isArray(m.tm)||m.tm.length!==playerCount()||!m.tm.every((s,t)=>validTeam(s,t,m.slot,m.over)&&s.eliminated===m.eliminated[t])))return false;
 if(m.b){if(!Array.isArray(m.b)||m.b.length>NCELL)return false;const bids=new Set();for(const b of m.b){if(!Array.isArray(b)||b.length!==13||!netInt(b[0],1)||bids.has(b[0])||!netInt(b[1],0,KINDS.length-1)||!netInt(b[2],0,neutralTeam()))return false;bids.add(b[0]);const d=BT[KINDS[b[1]]];
  if(b[2]!==m.slot&&(b[9]!==0||b[10]!==0||b[12]!==0))return false;
  if(!netInt(b[3],0,GW-d.w)||!netInt(b[4],0,GH-d.h)||![0,1].includes(b[5])||!netNum(b[6],0,100)||!netNum(b[7])||!netNum(b[8],1)||![0,1].includes(b[11])||!(b[12]===0||validResources(b[12])))return false;
  if(b[9]!==0&&(!Array.isArray(b[9])||b[9].length>10||b[9].some(q=>!Array.isArray(q)||q.length!==3||!netInt(q[0],0,TYPES.length-1)||!d.train||!d.train.includes(TYPES[q[0]])||!netNum(q[1])||!netNum(q[2],.001))))return false;
  if(b[10]!==0&&(!Array.isArray(b[10])||b[10].length!==2||!netNum(b[10][0],0,WW)||!netNum(b[10][1],0,WH)))return false;
  const old=bMap.get(b[0]);if(old&&(old.kind!==KINDS[b[1]]||old.team!==b[2]||old.cx!==b[3]||old.cy!==b[4]))return false;
 }}return true;}

// ---------- host: stato da mandare ----------
function netHostTick(dt){if(!NET.open||NET.phase!=='playing')return;NET.acc+=dt;if(NET.acc>=.1){NET.acc=0;if(NET.pumping)NET.snapDue=true;else sendSnap(false);}}
function teamState(t,mine){const T=teams[t];const o={fac:T.fac,popUsed:T.popUsed,popMax:T.popMax,martT:T.martT,mods:T.mods,tagN:T.tagN,carr:T.carr&&!T.carr.dead?T.carr.id:0,
  kills:T.kills,lost:T.lost,made:T.made,upsTaken:T.upsTaken,eliminated:!!T.eliminated};
 if(mine)Object.assign(o,{res:T.res,gath:T.gath,jobs:T.jobs,newJob:T.newJob,noFarm:T.noFarm,upT:T.upT,glory:T.glory,gloryNeed:T.gloryNeed,ups:T.ups,rerolls:T.rerolls,cardCooldowns:{...T.cardCooldowns},cardProgress:T.cardProgress||{},reinforcementQueue:(T.reinforcementQueue||[]).map(e=>({type:e.type,count:e.count})),heroReviveLeft:Math.max(0,Math.ceil(((T.heroReviveAt||0)-G.t)*10-1e-7)),
  picks:T.picks.map(p=>({src:p.src,at:p.at,minR:p.minR})),offer:T.offer,offerSeq:T.offerSeq,martCd:T.martCd});if(G.over)o.gath=T.gath;return o;}
function sendSnap(full){if(!NET||!NET.open||!G)return false;const n=NET;full=full||G.over;const U=[],HU=[],UC=Array.from({length:playerCount()},()=>[]);
 for(const u of units){if(u.dead)continue;let fl=((u.tacticState||0)&31)<<7|((u.strikeSeq||0)&15)<<12;if(u.f<0)fl|=1;if(u.mv)fl|=2;if(u.atk>0)fl|=4;if(u.working)fl|=8;if(u.carry>1)fl|=16;if(u.ct==='l')fl|=32;if(u.burn>0)fl|=64;
  U.push(u.id,TYPES.indexOf(u.type),u.team,Math.round(u.x),Math.round(u.y),Math.ceil(u.hp),Math.round(u.max),fl,u.type==='worker'?(u.job?'glp'.indexOf(u.job):-1):Math.round(Math.max(0,u.cd)*10));const hs=heroNetState(u);if(hs)HU.push([u.id,...hs]);
  if(isPlayerTeam(u.team)&&u.cardCounters){const c=NET_CARD_COUNTERS.map(k=>u.cardCounters[k]||0);if(c.some(Boolean))UC[u.team].push([u.id,...c]);}}
 const peers=netLinks(n).filter(e=>e.open);for(const e of peers){e.events.push(...n.ev.filter(v=>v[0]!=='n'||v[1]===e.slot));if(e.events.length>2048)e.events.splice(0,e.events.length-2048);for(const i of n.dirty)e.resources.add(i);}n.ev.length=0;n.dirty.clear();
 let sent=false;for(const e of peers){const seq=e.snapN+1,res=[];for(const i of e.resources)res.push(i,Math.round(tree[i]),Math.round(stone[i]),stump[i]);
  const m={t:'s',seq,match:n.match,...netMatchConfig(n),slot:e.slot,facs:playerIds().map(t=>teams[t].fac),eliminated:playerIds().map(t=>!!teams[t].eliminated),aiTeams:playerIds().map(t=>!!(G.aiTeams&&G.aiTeams[t])),over:!!G.over,winner:G.over?G.winner:null,winnerSide:G.over&&netTeamMode(G.mode)?G.winnerSide:null,background:!!document.hidden,gt:+G.t.toFixed(2),u:U,hu:HU,uc:UC[e.slot],ev:e.events.slice(),res,camps:camps.map(c=>[c.relic?1:0,c.owner,c.conquered?1:0,c.buildings])};
  if(full||seq%3===0)m.b=blds.filter(b=>!b.dead).map(b=>{const mine=b.team===e.slot;return [b.id,KINDS.indexOf(b.kind),b.team,b.cx,b.cy,b.built?1:0,Math.round(b.prog*100),Math.ceil(b.hp),Math.round(b.max),mine?b.queue.map(q=>[TYPES.indexOf(q.type),+q.t.toFixed(1),q.total]):0,mine&&b.rally?[b.rally.x|0,b.rally.y|0]:0,b.blocked?1:0,mine&&b.paid?b.paid:0];});
  if(full||seq%2===0)m.tm=playerIds().map(t=>teamState(t,t===e.slot));
  if(netSend(n,m,undefined,e)){sent=true;e.snapN=seq;e.events.splice(0,m.ev.length);e.resources.clear();}
 }return sent;}

// ---------- client: ricostruisce la partita dallo stato ricevuto ----------
const uMap=new Map(),bMap=new Map();
function clientStart(m){document.getElementById('start').classList.add('hidden');document.getElementById('lobby').classList.add('hidden');ME=m.slot;
 closeCards();choosing=false;offerKey='';curOfferSeq=0;
 G={t:0,seed:m.seed,diff:m.diff,mode:m.mode,sides:m.sides.slice(),winnerSide:null,over:false,paused:false,shake:0,reveal:false,auto:false,setup:false,fac:m.facs[ME],mp:true,playerCount:m.count,aiTeams:m.aiTeams.slice(),spectating:false};
 units=[];blds=[];projs=[];parts=[];floats=[];decals=[];pings=[];AIS=[];uMap.clear();bMap.clear();fieldCache.clear();gridVer++;
 if(!genMap(G.seed))throw new Error('Generazione della mappa non riuscita.');teams=m.facs.map((f,t)=>mkTeam(t,f));teams.push(mkTeam(neutralTeam(),2));
 for(const t of playerIds())FAC[teams[t].fac].apply(teams[t].mods,teams[t]);for(let t=0;t<=neutralTeam();t++)refreshStats(t);
 initFog();renderTerrain();if(teams[ME].mods.relics)for(const c of camps)c.seen=true;
 cam.z=1;const b=bases[ME];centerOn((b.cx+.5)*CELL,(b.cy+.5)*CELL+60);
 sel=[];selB=null;selE=null;groups={};placing=null;buildUI();document.getElementById('hud').classList.remove('hidden');toast('Partita online iniziata!','#ffe3a0',2500);}
function clientSnap(m){const now=performance.now();G.t=m.gt;const eliminatedBefore=teams.map(t=>!!t.eliminated);G.aiTeams=m.aiTeams.slice();const U=m.u,seen=new Set();
 for(let k=0;k<U.length;k+=9){const id=U[k];seen.add(id);let u=uMap.get(id);const type=TYPES[U[k+1]];
  if(!u){u={id,team:U[k+2],type,d:UT[type],x:U[k+3],y:U[k+4],px:U[k+3],py:U[k+4],an:Math.random()*4,atk:0,cd:0,sel:false,dead:false,f:1};uMap.set(id,u);units.push(u);}
  u.px=u.x;u.py=u.y;u.tx=U[k+3];u.ty=U[k+4];u.hp=U[k+5];u.max=U[k+6];const fl=U[k+7];u.f=fl&1?-1:1;u.mv=!!(fl&2);const strike=fl>>>12&15;
  if((fl&4)&&(u.atk<=0||u.strikeSeq!==strike))u.atk=.3;u.strikeSeq=strike;u.tacticState=fl>>>7&31;
  u.working=!!(fl&8);u.carry=fl&16?6:0;u.ct=fl&32?'l':'p';u.burn=fl&64?1:0;if(type==='worker')u.job=U[k+8]>=0?'glp'[U[k+8]]:null;else u.cd=U[k+8]/10;}
 for(const u of units)if(!seen.has(u.id)){u.dead=true;uMap.delete(u.id);}units=units.filter(u=>!u.dead);
 const hs=new Map(m.hu.map(r=>[r[0],r.slice(1)])),cs=new Map(m.uc.map(r=>[r[0],r.slice(1)]));for(const u of units){heroApplyNetState(u,hs.get(u.id)||null);const c=cs.get(u.id);u.cardCounters=Object.fromEntries(NET_CARD_COUNTERS.map((k,i)=>[k,c?c[i]:0]));}
 NET.snapAt=now;
 if(m.b)clientBlds(m.b);
 if(m.tm)clientTeams(m.tm);
 for(const t of playerIds()){teams[t].eliminated=m.eliminated[t];if(!eliminatedBefore[t]&&m.eliminated[t]&&typeof playerEliminated==='function')playerEliminated(t);}
 let resourcesChanged=false;for(let k=0;k<m.res.length;k+=4){const i=m.res[k],blocked=tree[i]>0||stone[i]>0;tree[i]=m.res[k+1];stone[i]=m.res[k+2];stump[i]=m.res[k+3];if(blocked!==(tree[i]>0||stone[i]>0))resourcesChanged=true;}
 if(resourcesChanged)gridVer++;
 m.camps.forEach((r,i)=>{const c=camps[i];if(c){c.relic=!!r[0];c.owner=r[1];c.conquered=!!r[2];c.buildings=r[3].slice();}});
 for(const e of m.ev)clientEvent(e);}
function clientBlds(B){const seen=new Set();let changed=false;
 for(const r of B){const [id,ki,team,cx,cy,built,prog,hp,max,queue,rally,blocked,paid]=r;seen.add(id);let b=bMap.get(id);
  if(!b){const kind=KINDS[ki],def=BT[kind];b={id,isB:true,team,kind,def,cx,cy,w:def.w,h:def.h,x0:cx*CELL,y0:cy*CELL,x:(cx+def.w/2)*CELL,y:(cy+def.h/2)*CELL,queue:[],slots:[],seen:areAllies(team,ME),smokeT:0,dead:false};
   bMap.set(id,b);blds.push(b);changed=true;if(kind==='palazzo')teams[team].home=b;
   for(let y=cy;y<cy+def.h;y++)for(let x=cx;x<cx+def.w;x++){const i=y*GW+x;decor[i]=0;stump[i]=0;}}
  if(b.built!==!!built)changed=true;b.built=!!built;b.prog=prog/100;b.hp=hp;b.max=max;b.blocked=!!blocked;
  if(team===ME){b.queue=queue?queue.map(q=>({type:TYPES[q[0]],t:q[1],total:q[2]})):[];b.rally=rally?{x:rally[0],y:rally[1]}:null;b.paid=paid||null;}}
 for(const b of blds)if(!seen.has(b.id)){b.dead=true;bMap.delete(b.id);changed=true;}
 if(changed){blds=blds.filter(b=>!b.dead);bAt.fill(null);for(const b of blds)for(let y=b.cy;y<b.cy+b.h;y++)for(let x=b.cx;x<b.cx+b.w;x++)bAt[y*GW+x]=b;gridVer++;}}
function clientTeams(tm){for(const t of playerIds()){const T=teams[t],s=tm[t];const pu=s.popUsed,pm=s.popMax;Object.assign(T,s);refreshStats(t);T.popUsed=pu;T.popMax=pm;
  if(t===ME)T.heroReviveAt=s.heroReviveLeft?G.t+s.heroReviveLeft/10:0;T.carr=s.carr?uMap.get(s.carr)||null:null;if(!s.picks)T.picks=T.picks||[];if(!('offer' in s))T.offer=null;}}
function clientEvent(e){switch(e[0]){
 case 'p':if(projs.length>500)projs.shift();projs.push({k:e[1],x0:e[2],y0:e[3],x1:e[4],y1:e[5],t:0,dur:Math.max(.05,e[6]/100),crit:!!(e[7]&1),fire:!!(e[7]&2)});break;
 case 'd':decals.push({k:'c',x:e[1],y:e[2],f:e[3],fac:e[4],big:!!e[5],worker:!!e[6],t:0,life:6});break;
 case 'x':break;
 case 'h':addFloat(e[1],e[2],e[3],!!e[4],!!e[5]);break;
 case 'n':if(e[1]===ME)applyNote(e[2],e[3]);break;
 case 'end':break; // Il risultato autorevole è nello stato persistente m.over/m.winner.
 }}
// ogni fotogramma sul client: movimento fluido tra uno stato e l'altro, proiettili ed effetti
function clientFrame(dt){if(G.over||G.netAborted||G.netWaiting)return;const k=Math.min(1,(performance.now()-NET.snapAt)/110);
 for(const u of units){if(u.tx==null)continue;const nx=u.px+(u.tx-u.px)*k,ny=u.py+(u.ty-u.py)*k;u.an+=hyp(nx-u.x,ny-u.y)*.09;u.x=nx;u.y=ny;if(u.atk>0)u.atk-=dt;}
 for(const p of projs){p.t+=dt/p.dur;if(p.t<1)continue;p.done=true;
  if(p.k==='b')decals.push({k:'b',x:p.x1,y:p.y1+9,a:Math.atan2(p.y1-p.y0,p.x1-p.x0),t:0,life:3});
  else if(visAt(p.x1,p.y1))sfx('boom',p.x1,p.y1);}
 projs=projs.filter(p=>!p.done);
 updFx(dt);visT-=dt;if(visT<=0){visT=.15;updVision();}}

// ---------- stanza (schermata iniziale) ----------
function lobbyShow(host){const el=document.getElementById('lobby');el.classList.remove('hidden');document.getElementById('lobbyHost').classList.toggle('hidden',!host);
 document.getElementById('lobbyGo').classList.add('hidden');document.getElementById('lobbyCode').textContent='';}
function lobbyCode(code){document.getElementById('lobbyCode').textContent=code;lobbyMsg(LOCAL?'Prova locale: apri le altre schede con ?local ed entra con questo codice.':'Dai questo codice agli altri giocatori e aspetta che entrino.');lobbyUpdate();}
function lobbyMsg(t){document.getElementById('lobbyMsg').textContent=t;}
function lobbyUpdate(){const n=NET;if(!n)return;const roster=n.role==='host'?netRoster(n):n.roster,el=document.getElementById('lobbyRoster');
 const modeLabel={duel:'Duello 1 contro 1',ffa:(n.count===4?'Quattro':'Tre')+' giocatori — tutti contro tutti',coop:'Cooperativa '+n.humanCount+' contro '+n.humanCount+' — IA '+(n.diff===2?'Difficile':'Normale'),teams:'Squadre 2 contro 2 — G1 e G2 contro G3 e G4 (ordine di ingresso)'}[n.mode];
 const modeEl=document.getElementById('lobbyMode');if(modeEl)modeEl.textContent=modeLabel;
 if(el)el.textContent=modeLabel+'\n'+roster.map(p=>'G'+(p.slot+1)+' — '+(p.fac===null?'Posto libero':FAC[p.fac].name)+' — '+({host:'Host',ready:'Pronto',waiting:'In attesa',ai:'IA'}[p.state])+(n.mode==='coop'?' — '+(p.side===0?'Alleanza umana':'Alleanza IA'):n.mode==='teams'?' — Squadra '+(p.side+1):'')).join('\n');
 const ready=n.role==='host'&&n.phase==='lobby'&&netLinks(n).every(e=>e.open&&netFac(e.peerFac));document.getElementById('lobbyGo').classList.toggle('hidden',!ready);
 if(n.phase==='lobby')lobbyMsg(ready?'Tutti i giocatori sono pronti. Puoi iniziare!':n.role==='host'?'Attendo gli altri giocatori ('+(1+netLinks(n).filter(e=>e.open).length)+'/'+n.humanCount+').':'Sei G'+(n.slot+1)+'. Attendi che l’host inizi la partita.');}
