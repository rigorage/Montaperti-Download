'use strict';
// ===================== tela e telecamera =====================
const cv=document.getElementById('c');let ctx=cv.getContext('2d');let DPR=Math.min(2,window.devicePixelRatio||1);
const cam={x:0,y:0,z:1};let VW=innerWidth,VH=innerHeight;
function resize(){VW=innerWidth;VH=innerHeight;cv.width=VW*DPR;cv.height=VH*DPR;cv.style.width=VW+'px';cv.style.height=VH+'px';clampCam();}
function clampCam(){const vw=VW/cam.z,vh=VH/cam.z;cam.x=clamp(cam.x,-150,Math.max(-150,WW-vw+150));cam.y=clamp(cam.y,-180,Math.max(-180,WH-vh+260));}
function centerOn(x,y){cam.x=x-VW/cam.z/2;cam.y=y-VH/cam.z/2;clampCam();}
addEventListener('resize',resize);

// ===================== suoni sintetizzati =====================
let AC=null;const sfxLast={};
function tone(f,t0,d,type,v,slide){if(!AC)return;const o=AC.createOscillator(),g=AC.createGain();o.type=type||'triangle';o.frequency.value=f;const s=AC.currentTime+t0;
 if(slide)o.frequency.exponentialRampToValueAtTime(slide,s+d);g.gain.setValueAtTime(0,s);g.gain.linearRampToValueAtTime(v,s+.01);g.gain.exponentialRampToValueAtTime(.001,s+d);o.connect(g).connect(AC.destination);o.start(s);o.stop(s+d+.05);}
function sfx(n,x,y){if(!AC||G&&G.auto)return;const now=performance.now();if(now-(sfxLast[n]||0)<90)return;sfxLast[n]=now;
 if(x!=null&&!(x>cam.x&&x<cam.x+VW/cam.z&&y>cam.y&&y<cam.y+VH/cam.z))return;
 switch(n){case 'flip':tone(300,0,.12,'sawtooth',.025,180);break;
  case 'rC':tone(523,0,.4,'triangle',.1);break;case 'rR':[523,659].forEach((f,i)=>tone(f,i*.07,.45,'triangle',.1));break;
  case 'rE':[523,659,784].forEach((f,i)=>tone(f,i*.07,.5,'triangle',.11));break;
  case 'rL':[392,523,659,784,1046].forEach((f,i)=>tone(f,i*.07,.6,'triangle',.11));tone(98,0,1.2,'sine',.3);tone(1568,.4,.8,'sine',.05);break;
  case 'pick':[523,659,784,1046,1318].forEach((f,i)=>tone(f,i*.05,.35,'square',.035));break;
  case 'glory':[784,988,1175,1568].forEach((f,i)=>tone(f,i*.06,.4,'triangle',.08));break;
  case 'alarm':tone(220,0,.35,'sawtooth',.06,180);tone(220,.4,.35,'sawtooth',.06,180);break;
  case 'built':tone(392,0,.2,'triangle',.08);tone(523,.12,.3,'triangle',.08);break;
  case 'ready':tone(660,0,.1,'triangle',.05);break;
  case 'boom':tone(70,0,.5,'sine',.25,40);break;
  case 'bell':[196,392,196,392].forEach((f,i)=>tone(f,i*.35,1.4,'sine',.22));tone(784,0,1.6,'triangle',.05);break;
  case 'ack':tone(440,0,.07,'square',.03);tone(560,.06,.07,'square',.03);break;
  case 'place':tone(300,0,.1,'triangle',.08,200);break;
  case 'no':tone(160,0,.18,'square',.04);break;}}

// ===================== messaggi =====================
function toast(txt,col,ms){const el=document.createElement('div');el.className='toast';el.textContent=txt;el.style.color=col||'#ffe3a0';
 const box=document.getElementById('toasts');box.appendChild(el);while(box.children.length>4)box.firstChild.remove();
 requestAnimationFrame(()=>el.classList.add('show'));setTimeout(()=>{el.classList.remove('show');setTimeout(()=>el.remove(),400);},ms||1800);}

// ===================== nuova partita =====================
function newGame(fac,diff,foe,opts){opts=opts||{};if(!opts.mp)netDispose();if(!opts.facs&&!opts.mp&&(foe==null||foe<0||foe===fac)){const o=PLAY_FACS.filter(f=>f!==fac);foe=o[(Math.random()*o.length)|0];}
 const facs=opts.facs?opts.facs.slice():[fac,foe],mode=opts.mode||(facs.length>=6?'coop':facs.length>=3?'ffa':'duel'),humanCount=mode==='coop'?facs.length/2:facs.length;if(!({duel:[2],ffa:[3,4],coop:[4,6,8,10],teams:[4]})[mode]?.includes(facs.length)||!facs.every(f=>PLAY_FACS.includes(f)))throw new Error('Fazioni o modalità non valide.');
 closeCards();choosing=false;offerKey='';curOfferSeq=0;
 ME=0;G={t:0,seed:Math.floor(Math.random()*1e9),diff,over:false,paused:false,shake:0,reveal:false,auto:/auto/.test(location.search),setup:true,fac:facs[0],mp:!!opts.mp,mode,sides:facs.map((_,t)=>mode==='coop'||mode==='teams'?(t<facs.length/2?0:1):t),playerCount:facs.length,aiTeams:facs.map((_,t)=>!!(opts.aiTeams?opts.aiTeams[t]:opts.mp?mode==='coop'&&t>=humanCount:t>0)),spectating:false};
 document.getElementById('spectatorStatus')?.classList.add('hidden');
 units=[];blds=[];projs=[];parts=[];floats=[];decals=[];pings=[];AIS=[];nextId=1;fieldCache.clear();resClaim.fill(0);gridVer++;
 if(!genMap(G.seed))throw new Error('Generazione della mappa non riuscita.');
 teams=facs.map((f,t)=>mkTeam(t,f));teams.push(mkTeam(neutralTeam(),2));
 for(const t of playerIds())FAC[teams[t].fac].apply(teams[t].mods,teams[t]);
 for(let t=0;t<teams.length;t++)refreshStats(t);
 initFog();renderTerrain();
 for(const t of playerIds()){const b=bases[t],T=teams[t];const pal=mkBld(t,'palazzo',b.cx-2,b.cy-1,true);
  for(let k=0;k<2;k++){const s=aiFindSpot(t,'campo',pal.x,pal.y+30,3,7);if(s)mkBld(t,'campo',s.cx,s.cy,true);}
  const s=aiFindSpot(t,'casa',pal.x,pal.y-40,3,7);if(s)mkBld(t,'casa',s.cx,s.cy,true);
  const nw=6+T.mods.startW+(mode==='coop'?(G.aiTeams[t]?aiDifficulty(t).startW:0):(t>0&&!G.mp?DIFF[diff].startW:0));for(let k=0;k<nw;k++){const u=spawnFrom(pal,'worker');if(u)u.job=k<4?'g':'l';}
  T.jobs={g:4,l:nw-4,p:0};
  for(let k=0;k<2;k++)spawnFrom(pal,'inf');spawnFrom(pal,'cav');recountPop(t);}
 for(const c of camps){const far=playerCount()>2?!!c.central:Math.abs(c.cx-GW/2)<25;for(let k=0;k<(far?6:4);k++){const u=mkUnit(neutralTeam(),'inf',c.x+MR(-50,50),c.y+MR(-40,40));u.camp=c;c.guardIds.push(u.id);}
  for(let k=0;k<(far?3:2);k++){const u=mkUnit(neutralTeam(),'xb',c.x+MR(-40,40),c.y+MR(-30,30));u.camp=c;c.guardIds.push(u.id);}}
 for(const t of playerIds().slice(1))if(G.aiTeams[t])AIS.push(mkAI(t));if(G.auto||G.aiTeams[0]){AIS.push(mkAI(0));G.aiTeams[0]=true;}
 for(const t of playerIds()){queuePreparation(t);ensureOffer(t);}
 if(teams[ME].mods.relics)for(const c of camps)c.seen=true;
 G.setup=false;cam.z=1;const h=teams[ME].home;centerOn(h.x,h.y+60);updVision();
 sel=[];selB=null;selE=null;groups={};placing=null;
 buildUI();document.getElementById('hud').classList.remove('hidden');}

// ===================== disegno del mondo =====================
const DRAW=[];let selBox=null;const marks=[];
function render(){const z=cam.z;ctx.setTransform(DPR,0,0,DPR,0,0);ctx.fillStyle='#0e0b07';ctx.fillRect(0,0,VW,VH);
 ctx.setTransform(DPR*z,0,0,DPR*z,DPR*(-cam.x*z),DPR*(-cam.y*z));
 const vx0=cam.x,vy0=cam.y,vx1=vx0+VW/z,vy1=vy0+VH/z;
 const ix0=Math.max(0,vx0),iy0=Math.max(0,vy0),ix1=Math.min(WW,vx1),iy1=Math.min(WH,vy1);
 if(ix1>ix0&&iy1>iy0)ctx.drawImage(terrC,ix0,iy0,ix1-ix0,iy1-iy0,ix0,iy0,ix1-ix0,iy1-iy0);
 const c0=Math.max(0,Math.floor(vx0/CELL)-2),c1=Math.min(GW-1,Math.ceil(vx1/CELL)+2),r0=Math.max(0,Math.floor(vy0/CELL)-1),r1=Math.min(GH-1,Math.ceil(vy1/CELL)+5);
 const t=G.t;
 // --- livello del suolo
 for(let y=r0;y<=r1;y++)for(let x=c0;x<=c1;x++){const i=y*GW+x;if(stump[i]&&exp[i]){ell(ctx,cX(i)+3,cY(i)+4,5,3);ctx.fillStyle='#6a4a2a';ctx.fill();ell(ctx,cX(i)+3,cY(i)+3,3.5,2);ctx.fillStyle='#b08a5a';ctx.fill();}}
 for(const b of blds){if(b.kind!=='campo'||!(b.team===ME||b.seen))continue;if(b.x0>vx1||b.x0+b.w*CELL<vx0||b.y0>vy1||b.y0+b.h*CELL<vy0)continue;drawBld(b,t);}
 for(const d of decals){if(d.x<vx0-20||d.x>vx1+20||d.y<vy0-20||d.y>vy1+20||!exp[cellI(d.x,d.y)])continue;
  if(d.k==='b'){ctx.save();ctx.translate(d.x,d.y);ctx.rotate(d.a);ctx.globalAlpha=Math.min(1,d.life-d.t);ctx.strokeStyle='#5a3e22';ctx.lineWidth=1.2;ctx.beginPath();ctx.moveTo(-5,0);ctx.lineTo(1,0);ctx.stroke();ctx.restore();ctx.globalAlpha=1;}
  else drawCorpse(ctx,d);}
 for(const tt of playerIds()){const c=teams[tt].carr;if(c&&!c.dead&&(tt===ME||visAt(c.x,c.y))){const ar=UT.carr.aura*(1+.4*teams[tt].mods.carrAura);
  ell(ctx,c.x,c.y,ar,ar);ctx.strokeStyle='#c9a95a';ctx.setLineDash([8,8]);ctx.lineDashOffset=0;ctx.lineWidth=1;ctx.stroke();ctx.setLineDash([]);}}
 for(const u of sel){if(u.dead)continue;ell(ctx,u.x,u.y,u.d.r+3,(u.d.r+3)*.45);ctx.strokeStyle='#7dff7a';ctx.lineWidth=1.5;ctx.stroke();}
 if(selB&&!selB.dead){ctx.strokeStyle='#7dff7a';ctx.lineWidth=2;ctx.setLineDash([6,4]);ctx.strokeRect(selB.x0-2,selB.y0-2,selB.w*CELL+4,selB.h*CELL+4);ctx.setLineDash([]);
  if(selB.rally&&selB.team===ME){ctx.strokeStyle='rgba(125,255,122,.5)';ctx.setLineDash([4,6]);ctx.beginPath();ctx.moveTo(selB.x,selB.y);ctx.lineTo(selB.rally.x,selB.rally.y);ctx.stroke();ctx.setLineDash([]);drawFlag(ctx,selB.rally.x,selB.rally.y,teams[ME].fac,false,t);}}
 // --- oggetti ordinati per profondità
 DRAW.length=0;
 for(let y=r0;y<=r1;y++)for(let x=c0;x<=c1;x++){const i=y*GW+x;if(!exp[i])continue;if(tree[i]>0)DRAW.push({y:cY(i)+10,k:1,i});else if(stone[i]>0)DRAW.push({y:cY(i)+8,k:2,i});else if(decor[i])DRAW.push({y:cY(i)+6,k:3,i});}
 for(const b of blds){if(b.kind==='campo'||!(b.team===ME||b.seen))continue;if(b.x0>vx1+40||b.x0+b.w*CELL<vx0-80||b.y0-260>vy1||b.y0+b.h*CELL<vy0)continue;DRAW.push({y:b.y0+b.h*CELL-(b.def.wall?6:0),k:4,o:b});}
 for(const u of units){if(u.x<vx0-60||u.x>vx1+60||u.y<vy0-40||u.y>vy1+80)continue;if(u.team!==ME&&!visAt(u.x,u.y))continue;DRAW.push({y:u.y,k:5,o:u});}
 for(const c of camps)if(c.seen&&!c.conquered&&c.x>vx0-100&&c.x<vx1+100&&c.y>vy0-100&&c.y<vy1+100)DRAW.push({y:c.y+30,k:6,o:c});
 DRAW.sort((a,b)=>a.y-b.y);
 for(const d of DRAW){switch(d.k){
  case 1:{const i=d.i,s=SPR.tree[(hash2(i,3)*6)|0],jx=(hash2(i,1)-.5)*10,jy=(hash2(i,2)-.5)*8;ctx.drawImage(s,cX(i)-26+jx,cY(i)+10-64+jy,64,72);break;}
  case 2:{const i=d.i,s=SPR.rock[(hash2(i,4)*4)|0],k=.55+.45*stone[i]/350;ctx.drawImage(s,cX(i)-22*k,cY(i)+8-30*k,48*k,36*k);break;}
  case 3:{const i=d.i,v=decor[i],x=cX(i)+(hash2(i,5)-.5)*12,y=cY(i)+6;
   if(v===1)ctx.drawImage(SPR.cyp[i%2],x-14,y-50,44,56);else if(v===2)ctx.drawImage(SPR.olive[i%2],x-18,y-38,44,44);else if(v===3)ctx.drawImage(SPR.bush[i%2],x-14,y-22,32,28);else ctx.drawImage(SPR.hay[0],x-15,y-26,36,32);break;}
  case 4:drawBld(d.o,t);break;
  case 5:drawUnit(d.o,t);break;
  case 6:drawCamp(ctx,d.o,t);break;}}
 // --- proiettili
 for(const p of projs){const mx=p.x0+(p.x1-p.x0)*p.t,my=p.y0+(p.y1-p.y0)*p.t;if(mx<vx0-50||mx>vx1+50||my<vy0-250||my>vy1+50)continue;if(!visAt(mx,my)&&!visAt(p.x0,p.y0))continue;
  const L=hyp(p.x1-p.x0,p.y1-p.y0);
  if(p.k==='b'){const h=L*.18*Math.sin(Math.PI*p.t),a=Math.atan2(p.y1-p.y0-L*.18*Math.PI*Math.cos(Math.PI*p.t),p.x1-p.x0);
   ctx.fillStyle='rgba(20,20,10,.22)';ctx.fillRect(mx-1,my+9,2,1);ctx.save();ctx.translate(mx,my-h);ctx.rotate(a);drawBoltArt(ctx,p.fire,z,p.crit);ctx.restore();}
  else{const h=Math.min(260,L*.45)*Math.sin(Math.PI*p.t);ell(ctx,mx,my+30,6*(1-.5*Math.sin(Math.PI*p.t)),2.5);ctx.fillStyle='rgba(20,20,10,.3)';ctx.fill();
   ell(ctx,mx,my-h,5.5,5.5);ctx.fillStyle='#8a8378';ctx.fill();ctx.strokeStyle='#4a4640';ctx.lineWidth=1;ctx.stroke();}}
 // --- nebbia
 ctx.imageSmoothingEnabled=true;ctx.drawImage(fogC,0,0,GW,GH,-CELL*.5,-CELL*.5,WW,WH);
 // --- barre vita e numeri
 for(const d of DRAW){if(d.k===5){const u=d.o;if((u.sel||u.hp<u.max)&&!(u.team!==ME&&!visAt(u.x,u.y)))hpBar(u.x,u.y-(u.d.r>9?38:34),u.d.r>9?24:16,u.hp/u.max,u.team);}
  else if(d.k===4){const b=d.o;if(!b.def.wall&&(b===selB||b.hp<b.max*.999)&&(b.team===ME||visAt(b.x,b.y)))hpBar(b.x,b.y0-14,b.w*CELL*.6,b.hp/b.max,b.team);
   if(!b.built&&b.team===ME){ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(b.x-20,b.y+b.h*CELL*.5+4,40,4);ctx.fillStyle='#ffd76a';ctx.fillRect(b.x-20,b.y+b.h*CELL*.5+4,40*b.prog,4);}}}
 ctx.textAlign='center';for(const f of floats){ctx.globalAlpha=1-f.t/.9;ctx.font=`700 ${f.big?20:f.crit?15:11}px 'Crimson Text',serif`;ctx.lineWidth=3;ctx.strokeStyle='rgba(0,0,0,.7)';
  const y=f.y-f.t*26;ctx.strokeText(f.txt,f.x,y);ctx.fillStyle=f.crit?'#ffd34a':'#fff';ctx.fillText(f.txt,f.x,y);}ctx.globalAlpha=1;
 for(const m of marks){m.t+=1/60;const a=1-m.t/.6;if(a<=0)continue;ell(ctx,m.x,m.y,14*(1-m.t),7*(1-m.t));ctx.strokeStyle=m.atk?`rgba(255,80,60,${a})`:`rgba(125,255,122,${a})`;ctx.lineWidth=2;ctx.stroke();}
 while(marks.length&&marks[0].t>.6)marks.shift();
 for(const p of pings){const a=1-p.t/4;ell(ctx,p.x,p.y,30+p.t*40%80,(30+p.t*40%80)*.5);ctx.strokeStyle=`rgba(255,70,50,${a})`;ctx.lineWidth=3;ctx.stroke();}
 if(placing)drawGhost();
 // --- spazio schermo
 ctx.setTransform(DPR,0,0,DPR,0,0);
 if(selBox){ctx.strokeStyle='#7dff7a';ctx.lineWidth=1.2;ctx.fillStyle='rgba(125,255,122,.08)';const x=Math.min(selBox.x0,selBox.x1),y=Math.min(selBox.y0,selBox.y1),w=Math.abs(selBox.x1-selBox.x0),h=Math.abs(selBox.y1-selBox.y0);ctx.fillRect(x,y,w,h);ctx.strokeRect(x,y,w,h);}
}
function hpBar(x,y,w,f,team){ctx.fillStyle='rgba(0,0,0,.6)';ctx.fillRect(x-w/2-1,y-1,w+2,5);ctx.fillStyle=team===ME?(f>.5?'#6fdc5a':f>.25?'#e8c33a':'#e8503a'):team===neutralTeam()?'#d9a520':isTeamMatch()&&areAllies(ME,team)?'#73d7c0':playerCount()>2?playerColor(team):'#e8503a';ctx.fillRect(x-w/2,y,w*Math.max(0,f),3);}
function drawBld(b,t){if(b.def.wall){drawWall(ctx,b);return;}const fac=teams[b.team].fac,spr=bldSpr(b.kind,fac),top=bTop(b.kind,fac),W2=spr.width/2,H2=spr.height/2,x=b.x0-BPAD.l,y=b.y0-top;
 if(b.built){ctx.drawImage(spr,x,y,W2,H2);for(const f of BMETA[b.kind+fac].flags)drawFlag(ctx,b.x0+f[0],b.y0+f[1]-top+top,fac,!!f[2],t);if(playerCount()>2&&isPlayerTeam(b.team)){ctx.save();ctx.fillStyle='#171109';ctx.fillRect(b.x-10,b.y0+b.h*CELL-4,20,11);ctx.fillStyle=playerColor(b.team);ctx.font='bold 9px sans-serif';ctx.textAlign='center';ctx.fillText('G'+(b.team+1),b.x,b.y0+b.h*CELL+5);ctx.restore();}}
 else{const vh=H2*Math.max(.15,b.prog);ctx.save();ctx.beginPath();ctx.rect(x,y+H2-vh,W2,vh);ctx.clip();ctx.globalAlpha=.7;ctx.drawImage(spr,x,y,W2,H2);ctx.restore();ctx.globalAlpha=1;
  ctx.strokeStyle='rgba(90,60,30,.8)';ctx.lineWidth=1.5;ctx.setLineDash([5,4]);ctx.strokeRect(b.x0+2,b.y0+2,b.w*CELL-4,b.h*CELL-4);ctx.setLineDash([]);
  ctx.strokeStyle='#7a5430';ctx.lineWidth=2;for(const [px,py] of [[b.x0+4,b.y0+4],[b.x0+b.w*CELL-4,b.y0+4],[b.x0+4,b.y0+b.h*CELL-4],[b.x0+b.w*CELL-4,b.y0+b.h*CELL-4]]){ctx.beginPath();ctx.moveTo(px,py);ctx.lineTo(px,py-24);ctx.stroke();}}}
function drawUnit(u,t){const T=teams[u.team],fac=T.fac;
 drawPlayerMarker(ctx,u.team,u.x,u.y+7,5);
 if(u.d.hero||u.temporaryUntil||u.heroRootUntil>G.t||u.heroTauntUntil>G.t)drawHeroState(u);
 drawTacticState(u);
 if(T.martT>0&&isPlayerTeam(u.team)){ctx.fillStyle='#c9a95a';ctx.fillRect(u.x-2,u.y-40,4,4);}
 if(u.d.cls==='treb'){const S=T.S[u.type],ph=1-Math.max(0,u.cd)/S.cd;const arm=u.atk>0?1.15:1.15+(-1.75-1.15)*clamp(ph*1.6,0,1);const k=u.type==='mang'?.8:1;ctx.save();ctx.translate(u.x,u.y);ctx.scale(u.f*k,k);drawTrebArt(ctx,fac,arm,ph>.6&&u.atk<=0);ctx.restore();return;}
 if(u.type==='carr'){ctx.save();ctx.translate(u.x,u.y);ctx.scale(u.f,1);drawCarrArt(ctx,fac,t);ctx.restore();return;}
 const pose=u.atk>0?(u.atk>.22?'a0':u.atk>.1?'a1':'a2'):u.working?((Math.floor(t*3+u.id)%2)?'k':'i'):u.mv?'w'+(Math.floor(u.an)%4):(u.tacticState&16)?'p':(u.tacticState&1)?'b':'i';
 ctx.drawImage(unitSpr(fac,u.type,pose,u.f<0),u.x-42,u.y-54,84,64);
 if(u.type==='worker'&&u.carry>1){ctx.fillStyle=u.ct==='l'?'#8a5a2a':'#a9a69c';rr(ctx,u.x-u.f*7-3,u.y-21,7,6,2);ctx.fill();}}
function drawHeroState(u){ctx.save();ctx.lineWidth=1.3/Math.max(.6,cam.z);ctx.strokeStyle='#382712';ctx.fillStyle='#e1bf6f';
 if(u.d.hero){const y=u.y-(u.d.cls==='cav'?49:45);ctx.beginPath();ctx.moveTo(u.x-5,y);ctx.lineTo(u.x-6,y-6);ctx.lineTo(u.x-2,y-3);ctx.lineTo(u.x,y-8);ctx.lineTo(u.x+2,y-3);ctx.lineTo(u.x+6,y-6);ctx.lineTo(u.x+5,y);ctx.closePath();ctx.fill();ctx.stroke();
  if(u.heroCast&&u.heroCast.at>G.t){ctx.fillStyle='#251d12';ctx.fillRect(u.x-12,y+4,24,3);ctx.fillStyle='#e1bf6f';ctx.fillRect(u.x-12,y+4,24*clamp(1-(u.heroCast.at-G.t)/(u.heroCast.kind==='pin'?1:.6),0,1),3);}}
 if(u.temporaryUntil){ctx.font='bold 9px sans-serif';ctx.textAlign='center';ctx.fillStyle='#fff0bf';ctx.strokeStyle='#251d12';ctx.lineWidth=2;const label=Math.ceil(Math.max(0,u.temporaryUntil-G.t))+'s';ctx.strokeText(label,u.x,u.y-31);ctx.fillText(label,u.x,u.y-31);}
 if(u.heroRootUntil>G.t){ctx.strokeStyle='#d4bc84';ctx.beginPath();ctx.moveTo(u.x-5,u.y+3);ctx.lineTo(u.x+5,u.y+3);ctx.moveTo(u.x-5,u.y);ctx.lineTo(u.x-5,u.y+6);ctx.moveTo(u.x+5,u.y);ctx.lineTo(u.x+5,u.y+6);ctx.stroke();}
 if(u.heroTauntUntil>G.t){ctx.fillStyle='#e7c98a';ctx.font='bold 13px sans-serif';ctx.fillText('!',u.x+10,u.y-25);}ctx.restore();}
function drawTacticState(u){const s=u.tacticState||0;if(!(s&14))return;let y=u.y-30;const x=u.x+16;
 // Segni fermi accanto al soldato: dardi pronti, protezione o cura effettivamente attive.
 for(const bit of [2,4,8]){if(!(s&bit))continue;ctx.fillStyle='#202b24';ctx.fillRect(x-2,y-2,11,10);ctx.lineWidth=1;
  if(bit===2){ctx.strokeStyle='#eed795';for(const dy of [0,4]){ctx.beginPath();ctx.moveTo(x,y+dy);ctx.lineTo(x+6,y+dy);ctx.moveTo(x+4,y+dy-2);ctx.lineTo(x+6,y+dy);ctx.lineTo(x+4,y+dy+2);ctx.stroke();}}
  else if(bit===4){ctx.strokeStyle='#aacbe2';ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+6,y);ctx.lineTo(x+6,y+4);ctx.lineTo(x+3,y+7);ctx.lineTo(x,y+4);ctx.closePath();ctx.stroke();}
  else{ctx.fillStyle='#b4dbad';ctx.fillRect(x+2,y,2,6);ctx.fillRect(x,y+2,6,2);}y+=12;}}
function tacticText(state){return [[1,'In posizione'],[2,'Salva pronta'],[4,'Protegge un alleato'],[8,'Cura in corso'],[16,'Pavese pronto']].filter(([bit])=>state&bit).map(([,label])=>label).join(' · ');}
function drawGhost(){const d=BT[placing.kind];const w=s2w(mouse.x,mouse.y);let cells=[];
 if(placing.kind==='mura'&&placing.start){const e={cx:Math.floor(w.x/CELL),cy:Math.floor(w.y/CELL)};cells=lineCells(placing.start,e);}
 else{const g=ghostCell(w);cells=[[g.cx,g.cy]];}
 const cost=costOf(ME,placing.kind,true);let total=0;
 for(const [cx,cy] of cells){const ok=canPlace(ME,placing.kind,cx,cy);total++;const aff=canAfford(ME,{p:(cost.p||0)*total,l:(cost.l||0)*total});
  ctx.fillStyle=ok&&aff?'rgba(120,255,120,.28)':'rgba(255,80,60,.32)';ctx.fillRect(cx*CELL,cy*CELL,d.w*CELL,d.h*CELL);
  ctx.strokeStyle=ok&&aff?'#7dff7a':'#ff6a5a';ctx.lineWidth=1.5;ctx.strokeRect(cx*CELL,cy*CELL,d.w*CELL,d.h*CELL);
  if(!d.wall){const fac=teams[ME].fac,spr=bldSpr(placing.kind,fac),top=bTop(placing.kind,fac);ctx.globalAlpha=.55;ctx.drawImage(spr,cx*CELL-BPAD.l,cy*CELL-top,spr.width/2,spr.height/2);ctx.globalAlpha=1;}}}
function ghostCell(w){const d=BT[placing.kind];return{cx:Math.round(w.x/CELL-d.w/2),cy:Math.round(w.y/CELL-d.h/2)};}
function lineCells(a,b){const out=[];let x=a.cx,y=a.cy;const dx=Math.abs(b.cx-x),dy=Math.abs(b.cy-y),sx=b.cx>x?1:-1,sy=b.cy>y?1:-1;let err=dx-dy;out.push([x,y]);
 while((x!==b.cx||y!==b.cy)&&out.length<60){const e2=2*err;if((e2>-dy&&x!==b.cx)||y===b.cy){err-=dy;x+=sx;}else{err+=dx;y+=sy;}out.push([x,y]);}return out;}

// ===================== input =====================
let sel=[],selB=null,selE=null,groups={},placing=null;const keys={};
const mouse={x:innerWidth/2,y:innerHeight/2,ld:false,bx:0,by:0,md:false,mx0:0,my0:0,cx0:0,cy0:0,lastR:0,lastRX:0,lastRY:0,lastL:0,in:true};
const s2w=(sx,sy)=>({x:cam.x+sx/cam.z,y:cam.y+sy/cam.z});
function pickAt(wx,wy){let best=null,bd=1e9;
 for(const u of units){if(u.dead||(u.team!==ME&&!visAt(u.x,u.y)))continue;const d=hyp(u.x-wx,u.y-12-wy);if(d<u.d.r+10&&d<bd){bd=d;best=u;}}if(best)return best;
 for(const b of blds){if(b.dead||!(b.team===ME||b.seen))continue;if(wx>=b.x0&&wx<=b.x0+b.w*CELL&&wy>=b.y0-(b.def.wall?20:40)&&wy<=b.y0+b.h*CELL)return b;}return null;}
function setSel(list){if(G)G.heroAim=null;for(const u of sel)u.sel=false;sel=list.filter(u=>!u.dead);for(const u of sel)u.sel=true;selB=null;selE=null;panelSig='';}
function heroInputReady(){return !!G&&!G.over&&!G.netAborted&&!G.spectating&&!G.paused&&isActivePlayer(ME)&&!netSimulationBlocked()&&!(cardsOpen&&!G.mp);}
function selectHero(){if(!heroInputReady())return;const u=units.find(e=>!e.dead&&e.team===ME&&e.d.hero);if(u){placing=null;setSel([u]);centerOn(u.x,u.y);sfx('ack');}else toast('Recluta il tuo eroe nel Palazzo.','#ffe3a0',1800);}
function beginHeroAbility(id){if(!heroInputReady())return;const u=id?units.find(e=>e.id===id):sel.find(e=>!e.dead&&e.team===ME&&e.d.hero),meta=heroMeta(u);if(!meta||u.dead||u.team!==ME)return;
 const left=Math.ceil(Math.max(0,(u.heroReadyAt||0)-G.t));if(left){toast('Abilità pronta fra '+left+' secondi.','#ffe3a0',1400);return;}if(u.heroCast){toast('Abilità in preparazione.','#ffe3a0',1400);return;}
 placing=null;if(meta.target){G.heroAim=u.id;panelSig='';toast(meta.target==='siege'?'Clicca una tua macchina d’assedio vicina. Esc o destro per annullare.':'Clicca un soldato nemico in gittata. Esc o destro per annullare.','#ffe3a0',3200);return;}
 const why=heroAbilityBlock(ME,u,null);if(why){toast(why,'#ffb08c',1800);return;}cmd({type:'hero',id:u.id});G.heroAim=null;panelSig='';}
function targetHeroAbility(wx,wy){if(!G?.heroAim)return false;const u=units.find(e=>e.id===G.heroAim&&!e.dead&&e.team===ME);if(!u||!heroInputReady()){G.heroAim=null;return true;}const target=pickAt(wx,wy),why=heroAbilityBlock(ME,u,target);
 if(why){toast(why,'#ffb08c',1800);return true;}cmd({type:'hero',id:u.id,targetId:target.id});G.heroAim=null;panelSig='';sfx('ack');return true;}
function heroPanel(u){const h=heroMeta(u);if(!h)return '';const left=Math.ceil(Math.max(0,(u.heroReadyAt||0)-G.t)),aim=G.heroAim===u.id,need=({0:4,3:3,5:3,7:4})[h.fac];
 return `<div class="hero-info"><div class="tip"><b>Passiva${need?' · '+(u.heroCount||0)+'/'+need:''}:</b> ${h.passive}</div><button class="hero-ability" data-act="hero" data-id="${u.id}" ${left||u.heroCast?'disabled':''}><b>${h.activeName}</b> · ${left?left+' s':u.heroCast?'In preparazione':aim?'Scegli bersaglio':'E'}</button><div class="tip">${h.active}</div>${u.heroParryUntil>G.t?'<div class="tip">Parate rimaste: '+u.heroParryN+'</div>':''}${aim?'<div class="tip">Clicca il bersaglio · Esc o tasto destro per annullare.</div>':''}</div>`;}
function progressHtml(rows){return rows.map(r=>`<div class="tip"><b>${r.name}:</b> ${r.need>0?r.current+'/'+r.need:''}${r.cooldown>0?' · ricarica '+r.cooldown+' s':r.ready?'Pronta (servono 3 posti liberi)':''}${r.pending?' · '+r.pending+' in attesa di spazio':''}</div>`).join('');}
function selectSameType(allMap){
 const eligible=u=>!u.dead&&!u.isB&&u.team===ME&&teams[ME].S[u.type]?.spd>0;
 if(!sel.length||sel.some(u=>u.team!==ME||u.isB))return;
 const current=sel.filter(eligible);if(!current.length)return;
 const type=current[0].type;if(current.some(u=>u.type!==type)){toast('Selezione mista: scegli prima un tipo nel pannello in basso.','#ffe3a0',2200);return;}
 const list=units.filter(u=>eligible(u)&&u.type===type&&(allMap||(u.x>=cam.x&&u.x<=cam.x+VW/cam.z&&u.y>=cam.y&&u.y<=cam.y+VH/cam.z)));
 setSel(list);if(list.length)sfx('ack');else toast('Nessuna unità di questo tipo nello schermo.','#ffe3a0',1600);
}
function clickSelect(wx,wy,add,dbl){const o=pickAt(wx,wy);
 if(!o){if(!add){setSel([]);}return;}
 if(o.isB){setSel([]);if(o.team===ME)selB=o;else selE=o;return;}
 if(o.team!==ME){setSel([]);selE=o;return;}
 if(dbl){const v=units.filter(u=>!u.dead&&u.team===ME&&u.type===o.type&&u.x>cam.x&&u.x<cam.x+VW/cam.z&&u.y>cam.y&&u.y<cam.y+VH/cam.z);setSel(v);return;}
 if(add&&sel.length&&(sel[0].type==='worker')!==(o.type==='worker'))add=false;
 if(add){if(sel.includes(o))setSel(sel.filter(u=>u!==o));else setSel([...sel,o]);}else setSel([o]);}
// il riquadro prende l'esercito; se dentro ci sono solo contadini, prende i contadini
function boxSelect(b,add){const a=s2w(Math.min(b.x0,b.x1),Math.min(b.y0,b.y1)),c=s2w(Math.max(b.x0,b.x1),Math.max(b.y0,b.y1));
 const inBox=units.filter(u=>!u.dead&&u.team===ME&&u.x>=a.x&&u.x<=c.x&&u.y-10>=a.y&&u.y-10<=c.y);
 let list=inBox.filter(u=>u.type!=='worker');if(!list.length)list=inBox;
 if(add&&sel.length&&list.length&&(sel[0].type==='worker')!==(list[0].type==='worker'))add=false;
 setSel(add?[...new Set([...sel,...list])]:list);if(list.length)sfx('ack');}
function command(wx,wy,forced){if(!isActivePlayer(ME)||G.spectating)return;if(selB&&selB.team===ME&&selB.def.train){cmd({type:'rally',bid:selB.id,x:wx,y:wy});if(!isClient())selB.rally={x:wx,y:wy};sfx('ack');return;}
 const all=sel.filter(u=>!u.dead);if(!all.length)return;const ws=all.filter(u=>u.type==='worker'),list=all.filter(u=>u.type!=='worker');
 if(ws.length){const r=classifyW(wx,wy);cmd({type:'wcmd',ids:ws.map(u=>u.id),x:wx,y:wy});marks.push({x:wx,y:wy,t:0,atk:false});sfx('ack');
  const msg={l:'Al legname!',p:'Alla pietra!',g:'Al campo!',build:'Al cantiere!',drop:'A depositare!'}[r];if(msg)toast(msg,'#c8f0b0',800);}
 if(!list.length)return;const o=pickAt(wx,wy);const ids=list.map(u=>u.id);
 if(o&&areEnemies(ME,o.team)&&!o.dead&&(o.isB?o.seen:true)){cmd({type:'attack',ids,tid:o.id});marks.push({x:o.x,y:o.y,t:0,atk:true});sfx('ack');return;}
 cmd({type:'move',ids,x:wx,y:wy,forced:!!forced});marks.push({x:wx,y:wy,t:0,atk:false});sfx('ack');}
// cosa succede se mando i contadini in quel punto (solo per il messaggio a schermo)
function classifyW(wx,wy){const i=cellI(wx,wy);for(const d of [0,1,-1,GW,-GW]){const j=i+d;if(j>=0&&j<NCELL){if(tree[j]>0)return 'l';if(stone[j]>0)return 'p';}}
 for(const b of blds){if(!b.dead&&b.team===ME&&wx>=b.x0&&wx<=b.x0+b.w*CELL&&wy>=b.y0-30&&wy<=b.y0+b.h*CELL)return !b.built?'build':b.kind==='campo'?'g':b.def.drop?'drop':'move';}return 'move';}
// niente menu, gesti del mouse o tasti avanti/indietro del browser durante la partita
document.addEventListener('contextmenu',e=>e.preventDefault());
addEventListener('mousedown',e=>{if(e.button>=2)e.preventDefault();},true);
addEventListener('mouseup',e=>{if(e.button===3||e.button===4)e.preventDefault();},true);
addEventListener('auxclick',e=>e.preventDefault());
let leaving=false;
addEventListener('beforeunload',e=>{if(G&&!G.mp&&!G.over&&!leaving){e.preventDefault();e.returnValue='';}});
try{history.pushState(null,'',location.href);addEventListener('popstate',()=>{if(G&&!G.over)try{history.pushState(null,'',location.href);}catch(e){}});}catch(e){}
cv.addEventListener('mousedown',e=>{if(!G||G.over)return;ensureAudio();mouse.x=e.clientX;mouse.y=e.clientY;const w=s2w(e.clientX,e.clientY);
 if(G.heroAim&&(e.button===0||e.button===2)){if(e.button===2){G.heroAim=null;panelSig='';}else targetHeroAbility(w.x,w.y);mouse.ld=false;selBox=null;e.preventDefault();return;}
 if(e.button===1){mouse.md=true;mouse.mx0=e.clientX;mouse.my0=e.clientY;mouse.cx0=cam.x;mouse.cy0=cam.y;e.preventDefault();return;}
 if(e.button===2){if(placing){placing=null;return;}const now=performance.now();const dbl=now-mouse.lastR<380&&hyp(e.clientX-mouse.lastRX,e.clientY-mouse.lastRY)<30;
  mouse.lastR=now;mouse.lastRX=e.clientX;mouse.lastRY=e.clientY;command(w.x,w.y,dbl);if(dbl)toast('Ritirata: ignorano i nemici finché non arrivano','#c8f0b0',1200);return;}
 if(e.button===0){if(placing){if(placing.kind==='mura'){placing.start={cx:Math.floor(w.x/CELL),cy:Math.floor(w.y/CELL)};}else{const g=ghostCell(w);tryPlace(placing.kind,[[g.cx,g.cy]],e.shiftKey);}return;}
  mouse.ld=true;mouse.bx=e.clientX;mouse.by=e.clientY;selBox=null;}});
function tryPlace(kind,cells,keep){const c=costOf(ME,kind,true),ok=[];let tot={};
 if(!isActivePlayer(ME)||G.spectating)return;
 for(const [cx,cy] of cells){if(!canPlace(ME,kind,cx,cy))continue;const nt={};for(const r in c)nt[r]=(tot[r]||0)+c[r];if(!canAfford(ME,nt)){toast('Risorse insufficienti','#ff9a8a',1000);sfx('no');break;}tot=nt;ok.push([cx,cy]);}
 if(ok.length){cmd({type:'place',kind,cells:ok});sfx('place');}else if(cells.length===1){sfx('no');}if(!keep)placing=null;}
addEventListener('mousemove',e=>{mouse.x=e.clientX;mouse.y=e.clientY;mouse.in=true;
 if(mouse.md){cam.x=mouse.cx0-(e.clientX-mouse.mx0)/cam.z;cam.y=mouse.cy0-(e.clientY-mouse.my0)/cam.z;clampCam();}
 if(mouse.ld&&hyp(e.clientX-mouse.bx,e.clientY-mouse.by)>6)selBox={x0:mouse.bx,y0:mouse.by,x1:e.clientX,y1:e.clientY};});
document.addEventListener('mouseleave',()=>{mouse.in=false;});
addEventListener('mouseup',e=>{if(e.button===1)mouse.md=false;if(e.button!==0)return;
 if(placing&&placing.kind==='mura'&&placing.start){const w=s2w(e.clientX,e.clientY);tryPlace('mura',lineCells(placing.start,{cx:Math.floor(w.x/CELL),cy:Math.floor(w.y/CELL)}),e.shiftKey);if(placing)placing.start=null;return;}
 if(!mouse.ld)return;mouse.ld=false;
 if(selBox){boxSelect(selBox,e.shiftKey);selBox=null;return;}
 if(e.target!==cv)return;const w=s2w(e.clientX,e.clientY);const now=performance.now();const dbl=now-mouse.lastL<350;mouse.lastL=now;clickSelect(w.x,w.y,e.shiftKey,dbl);});
cv.addEventListener('wheel',e=>{e.preventDefault();const w=s2w(e.clientX,e.clientY);cam.z=clamp(cam.z*(e.deltaY<0?1.12:1/1.12),.5,1.7);cam.x=w.x-e.clientX/cam.z;cam.y=w.y-e.clientY/cam.z;clampCam();},{passive:false});
addEventListener('keydown',e=>{if(!G)return;const k=e.key.toLowerCase(),target=e.target;
 if(e.isComposing||target&&(/^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName)||target.isContentEditable))return;
 if(['q','e','j'].includes(k)&&(e.ctrlKey||e.metaKey||e.altKey||e.repeat))return;
 keys[k]=true;
 if(k===' '||k==='tab'){e.preventDefault();}
 if(G.over||G.netAborted)return;
 if(k==='escape'){if(G.heroAim){G.heroAim=null;panelSig='';}else if(placing)placing=null;else if(document.getElementById('upsList').classList.contains('show'))toggleUps();else if(sel.length||selB||selE){setSel([]);}else togglePause();return;}
 if(k==='p'){togglePause();return;}
 if(G.spectating){if(k==='u')toggleUps();return;}
 if(G.paused||(cardsOpen&&!G.mp))return;
 if(k==='j'){e.preventDefault();selectHero();return;}
 if(k==='e'&&!selB&&sel.some(u=>u.d.hero)&&!placing){e.preventDefault();beginHeroAbility();return;}
 if(k==='q'){if(!isActivePlayer(ME)||netSimulationBlocked()||placing)return;e.preventDefault();selectSameType(!!e.shiftKey);return;}
 if(k===' '){const h=teams[ME].home;if(h)centerOn(h.x,h.y);return;}
 if(k==='f'){setSel(units.filter(u=>!u.dead&&u.team===ME&&u.type!=='worker'));sfx('ack');return;}
 if(k==='delete'&&selB&&selB.team===ME&&!selB.built){cmd({type:'cancelB',bid:selB.id});toast('Costruzione annullata, risorse restituite','#c8f0b0',1200);selB=null;return;}
 if(k==='h'){setSel([]);selB=teams[ME].home;const h=selB;if(h)centerOn(h.x,h.y);return;}
 if(k==='u'){toggleUps();return;}
 if(/^[1-9]$/.test(k)){if(e.ctrlKey){e.preventDefault();groups[k]=sel.slice();toast('Gruppo '+k+' salvato','#c8f0b0',900);}
  else if(groups[k]){const g=groups[k].filter(u=>!u.dead);if(g.length){const now=performance.now();if(sel.length===g.length&&sel.every(u=>g.includes(u))&&now-(groups['t'+k]||0)<400){let x=0,y=0;for(const u of g){x+=u.x;y+=u.y;}centerOn(x/g.length,y/g.length);}groups['t'+k]=now;setSel(g);}}return;}
 if(selB&&selB.team===ME&&selB.def.train&&['e','r','t'].includes(k)){const types=trainable(selB);const ty=types[['e','r','t'].indexOf(k)];if(ty)doTrain(ty,e.shiftKey?5:1);return;}
 for(const kind of BUILD_LIST)if(BT[kind].key.toLowerCase()===k){startPlace(kind);return;}});
addEventListener('keyup',e=>{keys[e.key.toLowerCase()]=false;});
addEventListener('blur',()=>{for(const k in keys)keys[k]=false;mouse.in=false;});
function placementHelp(kind){if(preparationBuilding(ME,kind))return BT[kind].n+' gratuita e subito pronta: scegli uno spazio libero entro 8 caselle dal tuo Palazzo. Una sola volta; le truppe non devono occupare il terreno.';return teams[ME].fac===5&&BT[kind].wall?'Mura e porte di Lucca: costruiscile entro 8 caselle dai tuoi edifici già completati. Mura, porte e cantieri non estendono questa zona.':'';}
function startPlace(kind){if(!isActivePlayer(ME)||G.spectating)return;if(!canAfford(ME,costOf(ME,kind,true))){toast('Risorse insufficienti per '+BT[kind].n,'#ff9a8a',1000);sfx('no');return;}placing={kind,start:null};setSel([]);if(placementHelp(kind))toast(placementHelp(kind),'#ffe3a0',4200);}
function panCam(dt){const sp=900/cam.z*dt;let dx=0,dy=0;
 if(keys['arrowleft']||keys['a'])dx-=sp;if(keys['arrowright']||keys['d'])dx+=sp;if(keys['arrowup']||keys['w'])dy-=sp;if(keys['arrowdown']||keys['s'])dy+=sp;
 if(mouse.in&&document.hasFocus()&&!mouse.md){const m=6;if(mouse.x<m)dx-=sp;if(mouse.x>VW-m)dx+=sp;if(mouse.y<m)dy-=sp;if(mouse.y>VH-m)dy+=sp;}
 if(dx||dy){cam.x+=dx;cam.y+=dy;clampCam();}}
function ensureAudio(){if(!AC){try{AC=new (window.AudioContext||window.webkitAudioContext)();}catch(e){}}else if(AC.state==='suspended')AC.resume();}

// ===================== interfaccia =====================
const RES_SVG={g:'<svg viewBox="0 0 24 24"><path d="M12 22V8" stroke="#8a6a2a" stroke-width="2"/><g fill="#e8c35a" stroke="#9a7420" stroke-width=".8"><ellipse cx="12" cy="5" rx="2" ry="3"/><ellipse cx="9" cy="9" rx="2" ry="3" transform="rotate(-30 9 9)"/><ellipse cx="15" cy="9" rx="2" ry="3" transform="rotate(30 15 9)"/><ellipse cx="9" cy="14" rx="2" ry="3" transform="rotate(-30 9 14)"/><ellipse cx="15" cy="14" rx="2" ry="3" transform="rotate(30 15 14)"/></g></svg>',
 l:'<svg viewBox="0 0 24 24"><rect x="3" y="8" width="18" height="9" rx="4.5" fill="#9a6a3a" stroke="#5a3a1a"/><ellipse cx="19" cy="12.5" rx="3" ry="4.5" fill="#e0b47a" stroke="#5a3a1a"/><ellipse cx="19" cy="12.5" rx="1.3" ry="2" fill="none" stroke="#9a6a3a"/></svg>',
 p:'<svg viewBox="0 0 24 24"><path d="M3 18l4-9 6-3 7 5 1 7z" fill="#a9aab0" stroke="#55565c"/><path d="M7 9l6-3 7 5-6 1z" fill="#d6d7dc"/></svg>'};
function costHtml(c){return Object.keys(c).map(r=>`<span class="ci">${RES_SVG[r]}${c[r]}</span>`).join('');}
function buildCostHtml(kind){return preparationBuilding(ME,kind)?'Gratis · pronta':costHtml(costOf(ME,kind,true));}
const ICACHE={};function icon(kind,isB,size){const fac=teams[ME].fac;const k=(isB?'b':'u')+kind+fac+size;if(!ICACHE[k])ICACHE[k]=(isB?iconBld(kind,fac,size):iconUnit(fac,kind,size)).toDataURL();return ICACHE[k];}
function buildUI(){
 const rb=document.getElementById('resbox');rb.innerHTML=RES.map(r=>`<div class="rb" title="${RESN[r]}">${RES_SVG[r]}<b id="r_${r}">0</b>
  <div class="wk"><button data-act="jm" data-r="${r}" title="Togli un contadino da ${RESN[r]}">−</button><span id="w_${r}" title="Contadini su ${RESN[r]}">0</span><button data-act="jp" data-r="${r}" title="Metti un contadino su ${RESN[r]}">+</button></div>
  ${r==='g'?'<div id="nofarm" class="warn hidden">servono campi!</div>':''}</div>`).join('');
 const bp=document.getElementById('buildp');bp.innerHTML='<div class="ptitle">Costruisci</div><div class="bgrid">'+BUILD_LIST.map(k=>`<button class="bb" data-act="build" data-k="${k}" title="${BT[k].n}: ${BT[k].desc}${placementHelp(k)?' '+placementHelp(k):''}">
  <img src="${icon(k,true,44)}"><span class="hk">${BT[k].key}</span><span class="bn">${BT[k].n}</span><span class="bc">${buildCostHtml(k)}</span></button>`).join('')+'</div>';
 document.getElementById('facName').textContent=FAC[teams[ME].fac].name;document.getElementById('facName').title=FAC[teams[ME].fac].perks.map(p=>p[1]+': '+p[2]).join(' · ');panelSig='';}
document.addEventListener('click',e=>{const el=e.target.closest('[data-act]');if(!el)return;ensureAudio();const a=el.dataset.act;if(!G&&!['host','join','lobbyGo','lobbyClose'].includes(a))return;const T=G?teams[ME]:null;
 if(G&&G.spectating&&!['ups','pause','later','host','join','lobbyGo','lobbyClose'].includes(a))return;
 if(a==='jp'||a==='jm'){const r=el.dataset.r,j={...T.jobs};let nj=T.newJob;if(a==='jp'){const from=RES.filter(k=>k!==r&&j[k]>0).sort((x,y)=>j[y]-j[x])[0];if(from){j[from]--;j[r]++;nj=r;}}
  else if(j[r]>0){const to=RES.filter(k=>k!==r).sort((x,y)=>j[x]-j[y])[0];j[r]--;j[to]++;}T.jobs=j;T.newJob=nj;cmd({type:'jobs',jobs:j,newJob:nj});sfx('ack');}
 else if(a==='build')startPlace(el.dataset.k);
 else if(a==='train')doTrain(el.dataset.u,e.shiftKey?5:1);
 else if(a==='cancel'&&selB){cmd({type:'cancelTrain',bid:selB.id,i:+el.dataset.i});panelSig='';}
 else if(a==='seltype'){setSel(sel.filter(u=>u.type===el.dataset.u));}
 else if(a==='cancelB'&&selB){cmd({type:'cancelB',bid:selB.id});sfx('place');toast('Costruzione annullata, risorse restituite','#c8f0b0',1200);selB=null;panelSig='';}
 else if(a==='cancelWalls'){cmd({type:'cancelWalls'});toast('Mura non finite annullate','#c8f0b0',1200);selB=null;panelSig='';}
 else if(a==='wjob'){cmd({type:'wjob',ids:sel.filter(u=>u.type==='worker').map(u=>u.id),r:el.dataset.r});sfx('ack');panelSig='';}
 else if(a==='stop'){cmd({type:'stop',ids:sel.map(u=>u.id)});}
 else if(a==='hero')beginHeroAbility(+el.dataset.id);
 else if(a==='ups')toggleUps();else if(a==='pause')togglePause();
 else if(a==='pickopen')openCards();else if(a==='later')closeCards();
 else if(a==='host')hostLobby();else if(a==='join')joinLobby(document.getElementById('joinCode').value);else if(a==='lobbyGo')hostStart();
 else if(a==='lobbyClose')netCancel();});
function trainable(b){return b.def.train.filter(ty=>facOk(UT[ty].fac,teams[ME].fac));}
function doTrain(ty,n){if(!isActivePlayer(ME)||G.spectating)return;const why=trainBlock(ME,selB,ty);if(why){if(why!=='X')toast(why,'#ff9a8a',1000);sfx('no');return;}cmd({type:'train',bid:selB.id,ty,n});sfx('ack');panelSig='';}
let panelSig='',hudT=0,rosterSig='';
function hudTick(dt){const leave=document.getElementById('leaveOnline');leave.classList.toggle('hidden',!G.mp||G.over);leave.textContent=G.spectating&&isHost()?'Esci e interrompi per tutti':'Esci dalla partita';hudT-=dt;if(hudT>0)return;hudT=.15;const T=teams[ME];
 if(T.eliminated&&!G.spectating&&!G.over)playerEliminated(ME);
 document.getElementById('buildp').classList.toggle('hidden',!!G.spectating);
 const roster=document.getElementById('matchRoster');roster.classList.toggle('hidden',playerCount()<3);roster.classList.toggle('coop',isTeamMatch());roster.style.gridTemplateRows=isTeamMatch()?`repeat(${playerCount()/2},auto)`:'';
 const rosterHtml=playerIds().map(t=>`<span style="border-color:${playerColor(t)};${teams[t].eliminated?'opacity:.5':''}"><b style="color:${playerColor(t)}">${PLAYER_SYMBOL[t]} G${t+1}</b> ${FAC[teams[t].fac].name}${t===ME?' · Tu':isTeamMatch()?(areAllies(ME,t)?' · Alleato':' · Nemico'):''} · ${teams[t].eliminated?'Eliminato':G.aiTeams?.[t]?(G.mode!=='coop'||t<playerCount()/2?'IA sostitutiva':'IA'):'In partita'}</span>`).join('');if(rosterHtml!==rosterSig){roster.innerHTML=rosterHtml;rosterSig=rosterHtml;}
 for(const r of RES){document.getElementById('r_'+r).textContent=fmt(T.res[r]);}
 const cnt={g:0,l:0,p:0};let nb=0;for(const u of units)if(!u.dead&&u.team===ME&&u.type==='worker'){if(u.build)nb++;else if(u.job)cnt[u.job]++;}
 for(const r of RES)document.getElementById('w_'+r).textContent=T.jobs[r];
 document.getElementById('nofarm').classList.toggle('hidden',!T.noFarm);
 const pe=document.getElementById('pop');pe.textContent=`${T.popUsed}/${T.popMax}`;pe.parentElement.classList.toggle('full',T.popUsed>=T.popMax);
 {const nw=cnt.g+cnt.l+cnt.p+nb;document.getElementById('builders').textContent=`👤 ${nw}/${T.mods.wCap} contadini`+(nb?` · ${nb} costruttori al lavoro`:'');}
 document.getElementById('clock').textContent=fmtT(G.t);document.getElementById('tm').textContent=fmtT(T.upT);
 document.getElementById('tbar').style.width=(100-T.upT/UP_INT*100)+'%';document.getElementById('gbar').style.width=Math.min(100,T.glory/T.gloryNeed*100)+'%';
 document.getElementById('glv').textContent=`${Math.floor(T.glory)}/${T.gloryNeed}`;
 document.getElementById('upsBtn').textContent=`✦ Potenziamenti: ${T.upsTaken} (U)`;
 for(const el of document.querySelectorAll('.bb')){const k=el.dataset.k;el.classList.toggle('dis',!canAfford(ME,costOf(ME,k,true)));el.classList.toggle('on',placing&&placing.kind===k);
  const price=buildCostHtml(k),bc=el.querySelector('.bc');if(bc&&bc.innerHTML!==price)bc.innerHTML=price;el.title=BT[k].n+': '+BT[k].desc+(placementHelp(k)?' '+placementHelp(k):'');}
 if(document.getElementById('upsList').classList.contains('show')&&typeof cardProgressInfo==='function'){const el=document.getElementById('cardProgress'),html=progressHtml(cardProgressInfo(ME));if(el&&el.innerHTML!==html)el.innerHTML=html;}
 updPanel();drawMini();if(!G.over&&!G.netAborted&&!G.spectating)cardsTick();}
function updPanel(){const el=document.getElementById('selp');let sig='',html='';
 if(sel.length){sel=sel.filter(u=>!u.dead);}
 if(selB&&selB.dead)selB=null;if(selE&&(selE.dead||(selE.isB?false:!visAt(selE.x,selE.y))))selE=null;
 if(placing&&placementHelp(placing.kind)){sig='placing:'+placing.kind;html=`<div class="ptitle">Costruisci: ${BT[placing.kind].n}</div><div class="tip">${placementHelp(placing.kind)}</div><div class="tip">${BT[placing.kind].desc} · Esc o tasto destro per annullare.</div>`;}
 else if(sel.length&&sel[0].type==='worker'){const n=sel.length,c={g:0,l:0,p:0};for(const u of sel)if(u.job)c[u.job]++;sig='w'+n+c.g+c.l+c.p;
  html=`<div class="ptitle">Contadini selezionati: ${n}</div><div class="trow">${RES.map(r=>`<button class="tb" data-act="wjob" data-r="${r}" title="Mandali a raccogliere ${RESN[r]} vicino a dove sono"><span style="font-size:24px">${RES_SVG[r].replace('<svg','<svg width="30" height="30"')}</span><span class="bn">${RESN[r]}</span><span class="bc">${c[r]} ora</span></button>`).join('')}</div>
   <div class="tip">Tasto destro su un albero, una cava, un campo o un cantiere per mandarli lì · destro sul terreno per spostarli (poi lavorano lì vicino)</div><div class="tip">Q: stesso tipo sullo schermo · Maiusc+Q: stesso tipo su tutta la mappa</div>`;}
 else if(sel.length){const by={};for(const u of sel)by[u.type]=(by[u.type]||0)+1;let hp=0,mx=0;for(const u of sel){hp+=u.hp;mx+=u.max;}
  sig='u'+Object.entries(by).join()+Math.round(hp/mx*20)+(sel.length===1?':'+(sel[0].tacticState||0)+':'+statLine(sel[0].type,teams[ME].S[sel[0].type]):'');
  html=`<div class="ptitle">Esercito selezionato: ${sel.length}</div><div class="chips">${Object.entries(by).map(([ty,n])=>`<button class="chip" data-act="seltype" data-u="${ty}" title="Seleziona solo: ${UT[ty].n}"><img src="${icon(ty,false,40)}"><b>${n}</b><span>${UT[ty].n}</span></button>`).join('')}</div>
   <div class="hpl"><div style="width:${hp/mx*100}%"></div></div><div class="tip">Tasto destro: avanzano e attaccano chi incontrano · doppio destro: ritirata (ignorano i nemici)</div><div class="tip">Q: stesso tipo sullo schermo · Maiusc+Q: stesso tipo su tutta la mappa${Object.keys(by).length>1?' · Scegli prima un tipo qui sopra.':''}</div><button class="sb" data-act="stop">Fermi!</button>`;
  if(sel.length===1){const u=sel[0],S=teams[ME].S[u.type];html+=`<div class="stats">${statLine(u.type,S)}</div>`;if(u.tacticState)html+=`<div class="tip">${tacticText(u.tacticState)}</div>`;if(typeof unitCardProgressInfo==='function'){const progress=unitCardProgressInfo(u);sig+=':cards:'+JSON.stringify(progress);html+=progressHtml(progress);}}
  const hero=sel.find(u=>u.d.hero&&u.team===ME);if(hero){sig+=':hero:'+Math.ceil(Math.max(0,(hero.heroReadyAt||0)-G.t))+':'+!!hero.heroCast+':'+G.heroAim+':'+hero.heroCount+':'+hero.heroParryN+':'+(hero.heroParryUntil>G.t);html+=heroPanel(hero);}}
 else if(selB){const b=selB,T=teams[ME],fire=homeFireRate(b);sig=JSON.stringify([b.id,b.built,fire,Math.round(b.prog*100),b.queue.map(q=>[q.type,Math.round(q.t/q.total*20)]),Math.round(b.hp/b.max*20),b.blocked,b.def.train?trainable(b).map(ty=>[ty,costOf(ME,ty),trainBlock(ME,b,ty)]):[T.mods.tower,T.mods.arrows]]);
  html=`<div class="ptitle">${BT[b.kind].n}</div><div class="hpl"><div style="width:${b.hp/b.max*100}%"></div></div><div class="tip">${BT[b.kind].desc}</div>`;
  if(fire===3)html+='<div class="tip">Difesa iniziale: spara 3 volte più spesso fino a 6:00.</div>';
  if(!b.built){html+=`<div class="tip">In costruzione: ${Math.round(b.prog*100)}%</div><button class="sb" style="position:static;margin-top:6px" data-act="cancelB" title="Canc">✖ Annulla costruzione (rimborso completo: ${costHtml(b.paid||{})})</button>`;if(b.def.wall)html+=` <button class="sb" style="position:static;margin-top:6px" data-act="cancelWalls">✖ Annulla tutte le mura non finite</button>`;}
  else if(b.def.train){html+='<div class="trow">'+trainable(b).map((ty,i)=>{const why=trainBlock(ME,b,ty);return `<button class="tb ${why?'dis':''}" data-act="train" data-u="${ty}" title="${UT[ty].n}: ${UT[ty].desc}${why&&why!=='X'?' ('+why+')':''}"><img src="${icon(ty,false,46)}"><span class="hk">${'ERT'[i]}</span><span class="bn">${UT[ty].n}</span><span class="bc">${costHtml(costOf(ME,ty))}</span></button>`;}).join('')+'</div>';
   if(b.queue.length)html+='<div class="queue">'+b.queue.map((q,i)=>`<button class="qi" data-act="cancel" data-i="${i}" title="Annulla"><img src="${icon(q.type,false,32)}">${i===0?`<i style="width:${q.t/q.total*100}%"></i>`:''}</button>`).join('')+'</div>';
   if(b.blocked)html+='<div class="warn">Popolazione al massimo: costruisci delle Case!</div>';
   html+='<div class="tip">Tasto destro sulla mappa: punto di raccolta · Maiusc+clic: 5 unità</div>';}
  else if(b.def.atk){html+=`<div class="tip">Danno ${Math.round(b.def.atk.dmg*(1+T.mods.tower)+(T.mods.flatTower||0))} · gittata ${b.def.atk.rng} · dardi ${1+T.mods.arrows}</div>`;}}
 else if(selE){const o=selE;sig='e'+o.id+Math.round(o.hp/o.max*20)+':'+(o.tacticState||0)+(o.isB?'':':'+statLine(o.type,teams[o.team].S[o.type]));const nm=o.isB?BT[o.kind].n:UT[o.type].n;const who=o.team===neutralTeam()?'Briganti':o.team===ME?'Tuo':(playerCount()>2?'G'+(o.team+1)+' · ':'')+(isTeamMatch()?(areAllies(ME,o.team)?'Alleato · ':'Nemico · '):'')+FAC[teams[o.team].fac].name;
  html=`<div class="ptitle">${nm} <small>(${who})</small></div><div class="hpl ${o.team===ME?'':'en'}"><div style="width:${o.hp/o.max*100}%"></div></div>`;
  if(!o.isB)html+=`<div class="stats">${statLine(o.type,teams[o.team].S[o.type])}</div>`;if(!o.isB&&o.tacticState)html+=`<div class="tip">${tacticText(o.tacticState)}</div>`;if(!o.isB&&o.type==='worker'&&o.team===ME)html+=`<div class="tip">I contadini lavorano da soli: decidi quanti su ogni risorsa in alto a sinistra.</div>`;}
 else{sig='none';html=`<div class="ptitle">Nessuna selezione</div><div class="tip">Trascina col sinistro per selezionare l'esercito (o i contadini, se nel riquadro ci sono solo loro) · Q = stesso tipo selezionato sullo schermo · Maiusc+Q = stesso tipo su tutta la mappa · F = tutto l'esercito · H = Palazzo · J = eroe · E = abilità eroe · Spazio = torna a casa · tasti 1-9 = gruppi (Ctrl+numero per salvarli)</div>`;}
 if(sig!==panelSig){panelSig=sig;el.innerHTML=html;}}
function statLine(ty,S){return `❤ ${Math.round(S.hp)} · ⚔ ${S.dmg?S.dmg.toFixed(1):'-'}${UT[ty].ranged?' · 🎯 '+Math.round(S.rng):''} · 🛡 ${S.aM}/${S.aR} · 👣 ${Math.round(S.spd)}`;}
function toggleUps(){const el=document.getElementById('upsList');const on=!el.classList.contains('show');el.classList.toggle('show',on);
 if(on){const T=teams[ME];const taken=UPS.filter(u=>T.ups[u.id]);
  el.innerHTML=`<div class="ptitle">Bonus di ${FAC[T.fac].name}</div><ul class="perks">${FAC[T.fac].perks.map(p=>`<li><em>${p[0]}</em><b>${p[1]}</b><span>${p[2]}</span></li>`).join('')}</ul><div class="ptitle">Potenziamenti presi: ${T.upsTaken}</div><div class="mast">${TAGS.map(t=>`<span>${t}: ${T.tagN[t]||0} ${mastN(T,t)?`<b>· Maestria ${mastN(T,t)}</b>`:''}</span>`).join('')}</div>
   <div id="cardProgress">${typeof cardProgressInfo==='function'?progressHtml(cardProgressInfo(ME)):''}</div><div class="ulist">${taken.length?taken.map(u=>`<div class="ui" style="--c:${(RC[u.r]||[u.fac!=null?FAC[u.fac].mini:'#d4bc84'])[0]}"><b>${u.n}</b> <span class="lvl">${u.max>=1e9?'Scelta '+T.ups[u.id]+' volte':u.max===1?'Acquisita':'liv. '+T.ups[u.id]+'/'+u.max}</span><div>${u.d}</div></div>`).join(''):'<div class="tip">Scegli i preparativi iniziali. Il prossimo potenziamento arriva al minuto 2.</div>'}</div><div class="tip">U o Esc per chiudere</div>`;}}
function togglePause(){if(!G||G.over)return;if(G.mp){toast('Online la partita non si può mettere in pausa','#c8c0a8',1500);return;}G.paused=!G.paused;document.getElementById('pause').classList.toggle('hidden',!G.paused);}

// ===================== minimappa =====================
const mm=document.getElementById('mm'),mg=mm.getContext('2d');
function drawMini(){if(!miniT)return;mg.drawImage(miniT,0,0);mg.imageSmoothingEnabled=true;mg.drawImage(fogC,0,0,GW,GH,-1,-1,300,200);
 for(const c of camps)if(c.seen&&c.relic){mg.fillStyle='#ffd76a';mg.beginPath();mg.arc(c.cx*2,c.cy*2,3.5,0,TAU);mg.fill();}
 for(const b of blds){if(b.dead||!(b.team===ME||b.seen))continue;mg.fillStyle=playerColor(b.team);mg.fillRect(b.cx*2,b.cy*2,Math.max(2,b.w*2),Math.max(2,b.h*2));
  if(b.team!==ME){mg.strokeStyle='#000';mg.lineWidth=.6;mg.strokeRect(b.cx*2,b.cy*2,Math.max(2,b.w*2),Math.max(2,b.h*2));}}
 for(const u of units){if(u.dead||(u.team!==ME&&!visAt(u.x,u.y)))continue;mg.fillStyle=playerColor(u.team);mg.fillRect(u.x/CELL*2-1,u.y/CELL*2-1,2.4,2.4);}
 for(const p of pings){mg.strokeStyle=`rgba(255,60,40,${1-p.t/4})`;mg.lineWidth=2;mg.beginPath();mg.arc(p.x/CELL*2,p.y/CELL*2,4+p.t*4%12,0,TAU);mg.stroke();}
 mg.strokeStyle='#fff';mg.lineWidth=1;mg.strokeRect(cam.x/CELL*2,cam.y/CELL*2,VW/cam.z/CELL*2,VH/cam.z/CELL*2);}
function mmPos(e){const r=mm.getBoundingClientRect();return{x:(e.clientX-r.left)/r.width*WW,y:(e.clientY-r.top)/r.height*WH};}
let mmDrag=false;mm.addEventListener('mousedown',e=>{if(!G)return;const p=mmPos(e);if(e.button===2){command(p.x,p.y,false);return;}mmDrag=true;centerOn(p.x,p.y);});
mm.addEventListener('mousemove',e=>{if(mmDrag){const p=mmPos(e);centerOn(p.x,p.y);}});addEventListener('mouseup',()=>{mmDrag=false;});mm.addEventListener('contextmenu',e=>e.preventDefault());

// ===================== fine partita =====================
function playerEliminated(t){if(!G||t!==ME||G.spectating)return;G.spectating=true;G.reveal=!isTeamMatch();closeCards();choosing=false;placing=null;setSel([]);selBox=null;mouse.ld=false;
 const el=document.getElementById('spectatorStatus');el.textContent='Il tuo Palazzo è caduto. '+(isTeamMatch()?'Continui a seguire la visuale della tua squadra: puoi ancora vincere con i tuoi alleati.':'Ora puoi seguire la partita.')+(isHost()?' Sei l’host: lascia aperta questa scheda perché gli altri possano continuare.':'');el.classList.remove('hidden');
 document.getElementById('pickBtn').classList.add('hidden');document.getElementById('buildp').classList.add('hidden');updVision();}
function endGame(w){closeCards();document.getElementById('spectatorStatus').classList.add('hidden');const el=document.getElementById('end');el.classList.remove('hidden');const draw=w===null,win=!draw&&(isTeamMatch()?G.winnerSide===sideOf(ME):w===ME);
 document.getElementById('endTitle').textContent=draw?'PAREGGIO':win?'VITTORIA!':'SCONFITTA';document.getElementById('endTitle').className=win?'win':'lose';
 document.getElementById('endSub').textContent=draw?'Gli ultimi Palazzi sono caduti nello stesso momento.':isTeamMatch()?(win?`La tua squadra ha abbattuto tutti e ${{4:'due',6:'tre',8:'quattro',10:'cinque'}[playerCount()]} i Palazzi avversari.`:'Tutti i Palazzi della tua squadra sono caduti.'):win?'Il tuo è l’ultimo Palazzo rimasto.':`${playerCount()>2?'G'+(w+1)+' · ':''}${FAC[teams[w].fac].name} ha vinto. Il tuo Palazzo è caduto.`;
 const ids=playerIds(),stats=[['Nemici uccisi',T=>T.kills],['Unità perse',T=>T.lost],['Unità create',T=>T.made],['Potenziamenti',T=>T.upsTaken],['Risorse raccolte',T=>fmt(T.gath.g+T.gath.l+T.gath.p)]];
 document.getElementById('endStats').innerHTML=`<table><tr><th></th>${ids.map(t=>`<th>${playerCount()>2?'G'+(t+1)+' · ':''}${FAC[teams[t].fac].name}${t===ME?' (Tu)':isTeamMatch()?(areAllies(ME,t)?' (Alleato)':' (Nemico)'):''}</th>`).join('')}</tr><tr><td>Durata</td><td colspan="${ids.length}">${fmtT(G.t)}</td></tr>${stats.map(([name,value])=>`<tr><td>${name}</td>${ids.map(t=>`<td>${value(teams[t])}</td>`).join('')}</tr>`).join('')}</table>`;
 sfx(win?'glory':'alarm');}

// ===================== avvio =====================
let startFac=0,startDiff=1,startFoe=-1;
const SHC={};function shieldImg(fac,w,h){const k=fac+'_'+w;if(SHC[k])return SHC[k];const c=mkCanvas(w*2,h*2),g=c.getContext('2d');g.scale(2,2);
 g.beginPath();g.moveTo(2,2);g.lineTo(w-2,2);g.lineTo(w-2,h*.5);g.quadraticCurveTo(w-2,h*.85,w/2,h-2);g.quadraticCurveTo(2,h*.85,2,h*.5);g.closePath();
 g.save();g.clip();paintArms(g,fac,2,2,w-4,h-4);g.restore();g.strokeStyle='#4a3a20';g.lineWidth=1.5;g.stroke();return SHC[k]=c.toDataURL();}
function setupStart(){const fc=document.getElementById('facs');const F=FAC[startFac];const sp=Object.keys(UT).find(k=>facOk(UT[k].fac,startFac)&&UT[k].fac);
 fc.innerHTML=`<div class="ftiles">${PLAY_FACS.map(f=>`<button class="ft ${f===startFac?'on':''}" data-f="${f}"><img src="${shieldImg(f,44,52)}"><b>${FAC[f].name}</b></button>`).join('')}</div>
  <div class="finfo"><img class="fsh" src="${shieldImg(startFac,70,84)}"><div><b class="fname">${F.name}</b><i>${F.sub}</i>
   <ul class="perks">${F.perks.map(p=>`<li><em>${p[0]}</em><b>${p[1]}</b><span>${p[2]}</span></li>`).join('')}</ul></div>
   ${sp?`<div class="fsp"><img src="${iconUnit(startFac,sp,64).toDataURL()}"><b>${UT[sp].n}</b><span>${UT[sp].desc}</span></div>`:''}</div>
  <div class="lblrow">Avversario in solitaria · per giocare online scegli la modalità qui sotto</div>
  <div class="ftiles small"><button class="ft ${startFoe<0?'on':''}" data-foe="-1"><span class="rnd">?</span><b>Casuale</b></button>${PLAY_FACS.filter(f=>f!==startFac).map(f=>`<button class="ft ${f===startFoe?'on':''}" data-foe="${f}"><img src="${shieldImg(f,30,36)}"><b>${FAC[f].name}</b></button>`).join('')}</div>`;
 fc.onclick=e=>{const b=e.target.closest('.ft');if(!b)return;if(b.dataset.f!=null){startFac=+b.dataset.f;if(startFoe===startFac)startFoe=-1;}else startFoe=+b.dataset.foe;setupStart();};
 const dc=document.getElementById('diffs');dc.innerHTML=DIFF.map((d,i)=>`<button class="dc ${i===startDiff?'on':''}" data-d="${i}">${d.n}</button>`).join('');
 dc.onclick=e=>{const b=e.target.closest('.dc');if(!b)return;startDiff=+b.dataset.d;setupStart();};}
document.getElementById('go').onclick=()=>{ensureAudio();document.getElementById('start').classList.add('hidden');document.getElementById('loading').classList.remove('hidden');
 setTimeout(()=>{try{newGame(startFac,startDiff,startFoe);}catch(e){window.MontapertiBoot.fail('Impossibile iniziare la partita. Ricarica e riprova.',e);}finally{document.getElementById('loading').classList.add('hidden');}},40);};
document.getElementById('reroll').onclick=rerollCards;
document.getElementById('resume').onclick=togglePause;
function leaveGame(){leaving=true;netLeave(()=>location.reload());}
for(const el of document.querySelectorAll('.again'))el.onclick=leaveGame;
document.getElementById('leaveOnline').onclick=leaveGame;
document.addEventListener('visibilitychange',netVisibility);
addEventListener('pagehide',()=>netLeave());
addEventListener('pageshow',e=>{if(e.persisted&&G&&G.mp){netDispose();G.netAborted=true;netInterrupted('Questa partita è stata lasciata. Torna al menu per iniziarne una nuova.');}});
let last=0;
function loop(now){let dt=Math.min(.1,(now-last)/1000||0);last=now;if(VW!==innerWidth||VH!==innerHeight)resize();
 if(G&&isClient())clientFrame(dt);else if(G&&G.mp&&isHost())netAdvance();else if(G&&!G.over&&!G.paused&&!netSimulationBlocked()&&(G.mp||!cardsOpen)){const n=Math.ceil(dt/(1/30));for(let k=0;k<n&&!G.over;k++)tick(dt/n);}
 if(G){panCam(dt);render();hudTick(dt);}
 requestAnimationFrame(loop);}
// per le prove: fa avanzare la partita di colpo
window.ff=function(sec,step){if(!G||G.mp)return;step=step||1/20;const n=Math.round(sec/step);for(let k=0;k<n&&!G.over;k++){tick(step);const T=teams[ME];if(T.offer&&!G.auto)applyCmd(ME,{type:'pick',id:T.offer[0],offerSeq:T.offerSeq});}};
function setupOnline(){const mode=document.getElementById('mpMode'),panel=document.getElementById('coopOptions');
 for(let n=0;n<5;n++)document.getElementById('botFac'+n).innerHTML='<option value="-1">Casuale</option>'+PLAY_FACS.map(f=>'<option value="'+f+'">'+FAC[f].name+'</option>').join('');
 const update=()=>{const count={coop2:2,coop:3,coop4:4,coop5:5}[mode.value]||0,word={2:'due',3:'tre',4:'quattro',5:'cinque'}[count]||'tre';panel.classList.toggle('hidden',!count);for(let n=2;n<5;n++)document.getElementById('botFac'+n+'Row').classList.toggle('hidden',count<=n);document.getElementById('teamsOptions').classList.toggle('hidden',mode.value!=='teams');document.getElementById('coopSummary').textContent=word[0].toUpperCase()+word.slice(1)+' città alleate contro '+word+' IA coordinate. Visuale condivisa, risorse e carte personali. Nessun fuoco amico. Per vincere abbattete tutti e '+word+' i Palazzi nemici.';};mode.addEventListener('change',update);update();}
resize();bakeNature();setupStart();setupOnline();requestAnimationFrame(loop);window.MontapertiBoot.ready();
if(/auto/.test(location.search)){document.getElementById('start').classList.add('hidden');newGame(0,1);}
