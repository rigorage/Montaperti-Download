'use strict';
// Sagoma solidale al dardo: nessuna scia, particella, luce o stato aggiuntivo.
function drawBoltArt(g,fire,zoom=1,crit=false){g.save();
 if(!fire){g.strokeStyle=crit?'#ffe27a':'#3a2a1a';g.lineWidth=1.4;g.beginPath();g.moveTo(-7,0);g.lineTo(2,0);g.stroke();g.restore();return;}
 const scale=Math.max(1,.9/Math.max(.5,zoom));g.scale(scale,scale);g.lineCap='round';g.lineJoin='round';
 g.beginPath();g.moveTo(-13,0);g.lineTo(4,0);g.strokeStyle='#302016';g.lineWidth=3.2;g.stroke();g.strokeStyle='#e6c083';g.lineWidth=1.3;g.stroke();
 g.beginPath();g.moveTo(-12.5,-2);g.lineTo(-10,0);g.lineTo(-12.5,2);g.strokeStyle='#302016';g.lineWidth=1.5;g.stroke();
 // Il lato arrotondato avvolge la punta; le lingue corte puntano verso la coda.
 g.beginPath();g.moveTo(5.5,0);g.bezierCurveTo(5,-3.1,1,-4,-1,-2.7);g.lineTo(-5.7,-3.3);
 g.bezierCurveTo(-4.5,-1.4,-4,.1,-6,.2);g.bezierCurveTo(-3.7,.4,-4.2,2.3,-3.3,3.5);g.lineTo(-1.6,2.4);g.bezierCurveTo(1.2,4.2,4.8,3.3,5.5,0);g.closePath();
 g.fillStyle='#f47720';g.fill();g.strokeStyle='#3d2518';g.lineWidth=1.2;g.stroke();
 g.beginPath();g.moveTo(4.4,0);g.bezierCurveTo(3.2,-1.8,1.3,-2,-1.2,-.8);g.lineTo(-2.4,0);g.bezierCurveTo(.7,.6,1.7,2.6,4.4,0);g.closePath();g.fillStyle='#ffe57b';g.fill();
 g.beginPath();g.moveTo(6.3,0);g.lineTo(3.7,-1);g.lineTo(3.7,1);g.closePath();g.fillStyle='#3d2518';g.fill();g.restore();}

// Colori di appartenenza distinti anche quando più giocatori scelgono la stessa fazione.
const PLAYER_INK=['#64cfff','#ff866b','#c69bff','#9fe774','#ffd476','#f291c1','#5ce2cc','#f5f0e6','#edaa55','#7395f5'];
const PLAYER_SYMBOL=['●','▲','■','◆','▼','⬢','✚','★','⬟','▶'];
function playerColor(t){if(t===neutralTeam())return '#d9a520';return playerCount()>2?PLAYER_INK[t]||'#b8b8b8':FAC[teams[t]?.fac]?.mini||'#b8b8b8';}
function drawPlayerMarker(ctx,t,x,y,size=5){if(playerCount()<3||!isPlayerTeam(t))return;
 ctx.save();ctx.fillStyle=playerColor(t);ctx.strokeStyle='#28231c';ctx.lineWidth=1;ctx.beginPath();
 if(t===0)ell(ctx,x,y,size*.65,size*.45);else if(t===1){ctx.moveTo(x,y-size*.65);ctx.lineTo(x+size*.7,y+size*.4);ctx.lineTo(x-size*.7,y+size*.4);ctx.closePath();}
 else if(t===2)ctx.rect(x-size*.5,y-size*.45,size,size*.9);
 else if(t===3){ctx.moveTo(x,y-size*.65);ctx.lineTo(x+size*.7,y);ctx.lineTo(x,y+size*.65);ctx.lineTo(x-size*.7,y);ctx.closePath();}
 else if(t===4){ctx.moveTo(x-size*.7,y-size*.4);ctx.lineTo(x+size*.7,y-size*.4);ctx.lineTo(x,y+size*.65);ctx.closePath();}
 else if(t===5){for(let k=0;k<6;k++){const a=k*TAU/6;ctx[k?'lineTo':'moveTo'](x+Math.cos(a)*size*.65,y+Math.sin(a)*size*.55);}ctx.closePath();}
 else if(t===6){const p=[[-.22,-.65],[.22,-.65],[.22,-.22],[.65,-.22],[.65,.22],[.22,.22],[.22,.65],[-.22,.65],[-.22,.22],[-.65,.22],[-.65,-.22],[-.22,-.22]];for(let k=0;k<p.length;k++)ctx[k?'lineTo':'moveTo'](x+p[k][0]*size,y+p[k][1]*size);ctx.closePath();}
 else if(t===7){for(let k=0;k<10;k++){const a=k*TAU/10-Math.PI/2,r=size*(k%2?.3:.75);ctx[k?'lineTo':'moveTo'](x+Math.cos(a)*r,y+Math.sin(a)*r);}ctx.closePath();}
 else if(t===8){for(let k=0;k<5;k++){const a=k*TAU/5-Math.PI/2;ctx[k?'lineTo':'moveTo'](x+Math.cos(a)*size*.7,y+Math.sin(a)*size*.7);}ctx.closePath();}
 else{ctx.moveTo(x-size*.45,y-size*.65);ctx.lineTo(x+size*.7,y);ctx.lineTo(x-size*.45,y+size*.65);ctx.closePath();}
 ctx.fill();ctx.stroke();ctx.restore();}
// ===================== stemmi =====================
function giglio(g,s,col){g.save();g.scale(s/22,s/22);g.fillStyle=col;
 g.beginPath();g.moveTo(0,-11);g.quadraticCurveTo(4.5,-4,1.6,2);g.lineTo(-1.6,2);g.quadraticCurveTo(-4.5,-4,0,-11);g.fill();
 for(const m of [1,-1]){g.beginPath();g.moveTo(1.6*m,1.5);g.quadraticCurveTo(9*m,-1,8*m,-8);g.quadraticCurveTo(11.5*m,-1,4.5*m,4.5);g.closePath();g.fill();
  g.beginPath();g.moveTo(2*m,-1);g.lineTo(5*m,-7.5);g.lineTo(3.2*m,-1);g.fill();}
 g.fillRect(-5.5,2.4,11,2.6);g.beginPath();g.moveTo(-1.6,5);g.lineTo(1.6,5);g.lineTo(3,11);g.lineTo(-3,11);g.closePath();g.fill();g.restore();}
// riempie il rettangolo con lo stemma della fazione (scudi, bandiere, gualdrappe)
function paintArms(g,fac,x,y,w,h){const s=Math.min(w,h);
 switch(FAC[fac].arms){
  case 'giglio':g.fillStyle='#f4efe2';g.fillRect(x,y,w,h);g.save();g.translate(x+w/2,y+h/2);giglio(g,s*.95,'#c8221e');g.restore();break;
  case 'balzana':g.fillStyle='#f4efe2';g.fillRect(x,y,w,h/2);g.fillStyle='#1c1a1a';g.fillRect(x,y+h/2,w,h/2+.5);break;
  case 'angio':g.fillStyle='#24418f';g.fillRect(x,y,w,h);g.save();g.translate(x+w/2,y+h*.56);giglio(g,s*.8,'#f0c84a');g.restore();g.fillStyle='#c8302c';g.fillRect(x,y,w,h*.14);break;
  case 'croce':g.fillStyle='#f4efe2';g.fillRect(x,y,w,h);g.fillStyle='#c02020';g.fillRect(x+w*.38,y,w*.24,h);g.fillRect(x,y+h*.38,w,h*.24);break;
  case 'lucca':g.fillStyle='#f4efe2';g.fillRect(x,y,w,h/2);g.fillStyle='#c8302c';g.fillRect(x,y+h/2,w,h/2+.5);break;
  case 'roma':{g.fillStyle='#8a1a2a';g.fillRect(x,y,w,h);g.strokeStyle='#f0c040';g.lineWidth=Math.max(1,s*.16);g.lineCap='round';
   g.beginPath();g.moveTo(x+w*.25,y+h*.22);g.lineTo(x+w*.75,y+h*.78);g.moveTo(x+w*.75,y+h*.22);g.lineTo(x+w*.25,y+h*.78);g.stroke();
   g.fillStyle='#f0c040';ell(g,x+w*.25,y+h*.22,s*.13,s*.13);g.fill();ell(g,x+w*.75,y+h*.22,s*.13,s*.13);g.fill();break;}
  case 'bologna':{g.fillStyle='#f4efe2';g.fillRect(x,y,w,h);const hw=w/2,hh=h/2;g.fillStyle='#2f5ea8';g.fillRect(x+hw,y,hw,hh);g.fillRect(x,y+hh,hw,hh+.5);
   g.fillStyle='#c02020';for(const [qx,qy] of [[x,y],[x+hw,y+hh]]){g.fillRect(qx+hw*.4,qy,hw*.2,hh);g.fillRect(qx,qy+hh*.4,hw,hh*.2);}
   g.fillStyle='#f0c040';g.fillRect(x+hw,y+hh*.45,hw,hh*.1);g.fillRect(x,y+hh+hh*.45,hw,hh*.1);break;}
  default:g.fillStyle='#6b5a3a';g.fillRect(x,y,w,h);g.fillStyle='#c9a227';g.fillRect(x+w*.4,y,w*.2,h);}}
function stemma(g,fac,x,y,w,h){g.save();rr(g,x,y,w,h,Math.min(w,h)*.25);g.clip();paintArms(g,fac,x,y,w,h);
 g.restore();rr(g,x,y,w,h,Math.min(w,h)*.25);g.strokeStyle='rgba(40,25,10,.8)';g.lineWidth=.8;g.stroke();}

// ===================== unità =====================
const POSE={i:{},w0:{mv:1,walk:0,ph:0},w1:{mv:1,walk:1,ph:1.57},w2:{mv:1,walk:0,ph:3.14},w3:{mv:1,walk:-1,ph:4.71},a:{atk:1,lunge:4},
 a0:{atk:1,lunge:0,swing:-.45,recoil:0},a1:{atk:1,lunge:5,swing:1.55,recoil:-3},a2:{atk:1,lunge:1,swing:.45,recoil:-1},b:{brace:1},p:{pavise:1},k:{work:1}};
const isHorse=t=>t==='cav'||t==='ted'||t==='ang'||!!(UT[t]?.hero&&UT[t].cls==='cav');
function drawHeroArt(g,fac,type,p){const d=UT[type],base=d.heroArt||({inf:'guard',cav:'ted',xb:'xbe'}[d.cls]||'inf'),horse=d.cls==='cav',f=FAC[fac];
 g.save();g.scale(1.12,1.12);
 // Mantello e cimiero fanno parte della sagoma: niente bagliori o effetti mobili aggiunti.
 const y=horse?-26:-15;g.beginPath();g.moveTo(-3,y);g.lineTo(-10-(p.mv?2:0),y+17);g.lineTo(-1,y+14);g.lineTo(2,y+1);g.closePath();g.fillStyle=shade(f.tunic,-.25);g.fill();g.strokeStyle='#d5b567';g.lineWidth=1;g.stroke();
 drawUnitArt(g,fac,base,p);
 const head=horse?-33:-20;g.fillStyle='#d5b567';g.fillRect(-3,head,6,2);g.fillStyle=f.tunic2;g.beginPath();g.moveTo(-1,head);g.lineTo(-3,head-6);g.lineTo(3,head-4);g.lineTo(2,head);g.closePath();g.fill();g.strokeStyle='#332719';g.lineWidth=.7;g.stroke();
 if(fac===0){g.strokeStyle='#674827';g.lineWidth=1.6;g.beginPath();g.moveTo(-11,1);g.lineTo(-11,-42);g.stroke();paintArms(g,fac,-11,-41,11,13);}
 if(fac===7){g.fillStyle='#a97b44';g.fillRect(-9,-12,5,8);g.strokeStyle='#d8c080';g.strokeRect(-9,-12,5,8);}
 g.restore();}
function drawUnitArt(g,fac,type,p){if(UT[type]?.hero){drawHeroArt(g,fac,type,p);return;}const f=FAC[fac];const walk=p.walk||0,lunge=p.lunge||0;
 const pattern=(x,y,w,h)=>{g.fillStyle=f.tunic2;if(f.pat==='h')g.fillRect(x,y+h/2,w,h/2);else if(f.pat==='x'){g.fillRect(x+w/2-1,y,2,h);g.fillRect(x,y+h*.35,w,2);}else g.fillRect(x+w/2-1,y,2,h);};
 const body=(bx,by,cap,tunic,plain)=>{rr(g,bx-4,by-9,8,10,3);g.fillStyle=tunic||f.tunic;g.fill();
  if(!plain){g.save();rr(g,bx-4,by-9,8,10,3);g.clip();pattern(bx-4,by-9,8,10);g.restore();}
  g.strokeStyle='rgba(30,20,10,.5)';g.lineWidth=.7;rr(g,bx-4,by-9,8,10,3);g.stroke();
  ell(g,bx,by-12,3.2,3.2);g.fillStyle='#e2b88e';g.fill();g.beginPath();g.arc(bx,by-12.5,3.5,Math.PI,0);g.fillStyle=cap||f.helm;g.fill();};
 const big=isHorse(type);
 ell(g,big?2:1,0,big?14:7,big?4.5:3);g.fillStyle='rgba(25,30,10,.38)';g.fill();
 if(big){const heavy=type!=='cav',mv=p.mv,hc=heavy?'#5a5048':f.horse;
  g.strokeStyle=shade(heavy?'#6a6058':f.horse,-.3);g.lineWidth=2;g.lineCap='round';
  for(const [lx,ph] of [[-7,0],[-4,2],[5,1],[8,3]]){g.beginPath();g.moveTo(lx,-7);g.lineTo(lx+(mv?Math.sin((p.ph||0)+ph)*3:0),0);g.stroke();}
  g.strokeStyle=hc;g.lineWidth=2;g.beginPath();g.moveTo(-11,-10);g.quadraticCurveTo(-15,-6,-14,-2);g.stroke();
  ell(g,0,-10,11,5);g.fillStyle=hc;g.fill();
  g.beginPath();g.moveTo(7,-12);g.lineTo(12,-19);g.lineTo(15,-18);g.lineTo(11,-10);g.closePath();g.fill();ell(g,15,-18,4,2.4,.3);g.fill();
  g.save();ell(g,0,-10,11.5,5.5);g.clip();
  if(heavy){paintArms(g,fac,-12,-13,24,10);g.fillStyle='#d4b04a';g.fillRect(-12,-4,24,1);}
  else{g.fillStyle=f.tunic;g.fillRect(-12,-11,24,7);pattern(-12,-11,24,7);}g.restore();
  if(heavy){body(-1,-14,'#8a9096');g.fillStyle='#9aa1a8';g.fillRect(-4.5,-31,7,6);g.fillStyle='#222';g.fillRect(-3.5,-28.5,5,1);g.fillStyle=f.pen;g.fillRect(-2,-34,3,3);}
  else body(-1,-14,f.helm);
  const ang=p.atk?(p.swing==null?-.08:-.95+(p.swing+.45)*.44):p.mv?-.08:-.9;g.save();g.translate(2+lunge,-19);g.rotate(ang);
  g.strokeStyle='#6b4a28';g.lineWidth=1.6;g.beginPath();g.moveTo(-8,0);g.lineTo(24,0);g.stroke();
  g.fillStyle='#d8dde2';g.beginPath();g.moveTo(24,-1.5);g.lineTo(29,0);g.lineTo(24,1.5);g.fill();
  g.fillStyle=f.pen;g.beginPath();g.moveTo(19,0);g.lineTo(14,-1);g.lineTo(13,4);g.lineTo(19,1.6);g.fill();g.restore();
  stemma(g,fac,-6,-19,6,8);return;}
 g.strokeStyle='#3d2c1c';g.lineWidth=2;g.lineCap='round';g.beginPath();g.moveTo(-1.5,-6);g.lineTo(-1.5-walk*2,0);g.moveTo(1.5,-6);g.lineTo(1.5+walk*2,0);g.stroke();
 if(type==='worker'){body(0,-5,'#d9b86a','#8b6b45',true);g.fillStyle=f.tunic;g.fillRect(-4,-9,8,2);
  ell(g,0,-15.8,5.5,1.6);g.fillStyle='#d9b86a';g.fill();
  g.save();g.translate(3,-10);g.rotate(p.work?-1.9:-.5);g.strokeStyle='#6b4a28';g.lineWidth=1.4;g.beginPath();g.moveTo(0,0);g.lineTo(13,0);g.stroke();
  g.fillStyle='#9aa1a8';g.fillRect(11,-2,3,5);g.restore();return;}
 if(type==='inf'||type==='guard'){const gd=type==='guard';body(0,p.brace?-3:-5,gd?'#d8c070':f.helm);
  if(gd){g.fillStyle='#d8c070';g.fillRect(-4.5,-6,9,2.5);g.fillStyle=f.tunic;ell(g,0,-19,1.6,3);g.fill();}
  g.save();g.translate(3+lunge,-12);g.rotate(p.atk?(p.swing==null?1.35:p.swing):p.brace?1.15:0);g.strokeStyle='#6b4a28';g.lineWidth=1.4;g.beginPath();g.moveTo(0,10);g.lineTo(0,gd?-16:-20);g.stroke();
  if(gd){g.fillStyle='#d8dde2';g.beginPath();g.moveTo(-3.5,-16);g.lineTo(0,-23);g.lineTo(3.5,-16);g.lineTo(0,-13);g.fill();}
  else{g.fillStyle='#d8dde2';g.beginPath();g.moveTo(-1.6,-20);g.lineTo(0,-25);g.lineTo(1.6,-20);g.fill();}g.restore();
  g.fillStyle='rgba(0,0,0,.25)';rr(g,4.5+lunge*.5,-20,8,17,2.5);g.fill();stemma(g,fac,(p.brace?7:4)+lunge*.5,p.brace?-19:-21,p.brace?10:8,gd?14:17);return;}
 if(type==='pike'){body(0,p.brace?-3:-5,f.helm);
  g.save();g.translate(2+Math.min(lunge,.5),-12);g.rotate(p.atk?(p.swing==null?1.05:clamp(p.swing,.15,1.35)):p.brace?1.3:p.mv?1.05:.12);g.strokeStyle='#6b4a28';g.lineWidth=1.5;g.beginPath();g.moveTo(0,12);g.lineTo(0,-34);g.stroke();
  g.fillStyle='#e0e4e8';g.beginPath();g.moveTo(-1.8,-34);g.lineTo(0,-40);g.lineTo(1.8,-34);g.fill();g.restore();
  stemma(g,fac,-7,-14,5,8);return;}
 if(type==='xb'||type==='xbe'){const el=type==='xbe';if(p.pavise){g.strokeStyle='#493926';g.lineWidth=2;g.beginPath();g.moveTo(11,-10);g.lineTo(15,0);g.stroke();stemma(g,fac,6,-20,10,20);}
  body(0,-5,el?f.helm:f.cap);if(el){g.fillStyle='rgba(0,0,0,.2)';rr(g,-9,-19,6,14,2);g.fill();stemma(g,fac,-9.5,-20,6,14);}
  const rec=p.atk?(p.recoil==null?-2:p.recoil):0;g.save();g.translate(rec,0);
  g.strokeStyle='#6b4a28';g.lineWidth=2;g.beginPath();g.moveTo(-1,-12);g.lineTo(el?11:10,-13);g.stroke();
  g.strokeStyle=el?'#3d4248':'#5d6268';g.lineWidth=el?2:1.6;g.beginPath();g.arc(7,-13,el?6:5,-1.2,1.2);g.stroke();
  g.strokeStyle='rgba(240,240,220,.8)';g.lineWidth=.6;g.beginPath();g.moveTo(8.8,-17.6);g.lineTo(p.atk?2:7.5,-13);g.lineTo(8.8,-8.4);g.stroke();g.restore();
  if(!el){g.fillStyle='#8a5a2a';g.fillRect(-6,-12,3,7);}}}
const USPR={};
function unitSpr(fac,type,pose,flip){const k=fac+type+pose+(flip?'f':'');let c=USPR[k];if(c)return c;
 c=mkCanvas(168,128);const g=c.getContext('2d');g.scale(2,2);g.translate(42,54);if(flip)g.scale(-1,1);drawUnitArt(g,fac,type,POSE[pose]);USPR[k]=c;return c;}

function drawTrebArt(g,fac,arm,loaded){ell(g,6,1,26,6);g.fillStyle='rgba(25,30,10,.38)';g.fill();
 g.strokeStyle='#5c3e22';g.lineWidth=3;g.lineCap='round';g.beginPath();g.moveTo(-18,0);g.lineTo(18,0);g.moveTo(-12,0);g.lineTo(0,-34);g.lineTo(12,0);g.stroke();
 for(const wx of [-15,15]){ell(g,wx,0,4,4);g.fillStyle='#4a3020';g.fill();}
 g.save();g.translate(0,-34);g.rotate(arm);g.strokeStyle='#7a5430';g.lineWidth=2.6;g.beginPath();g.moveTo(-10,0);g.lineTo(30,0);g.stroke();
 g.fillStyle='#4e4a44';g.fillRect(-16,-2,10,12);if(loaded){ell(g,30,4,3.5,3.5);g.fillStyle='#8a8378';g.fill();}g.restore();
 g.fillStyle=FAC[fac].tunic;g.fillRect(-6,-6,12,4);}
function drawCarrArt(g,fac,t){ell(g,4,2,30,7);g.fillStyle='rgba(25,30,10,.38)';g.fill();
 for(const wx of [-16,14]){ell(g,wx,-5,6,6);g.fillStyle='#5a3b20';g.fill();ell(g,wx,-5,3,3);g.fillStyle='#8a6a3a';g.fill();}
 g.fillStyle='#b23026';g.fillRect(-24,-17,48,10);g.fillStyle='#f0e6cc';for(let i=-24;i<24;i+=8)g.fillRect(i,-17,4,10);
 g.strokeStyle='#4a3020';g.lineWidth=2;g.beginPath();g.moveTo(0,-17);g.lineTo(0,-62);g.stroke();
 g.save();const L=34,Hh=24,top=-60;g.beginPath();g.moveTo(0,top);for(let i=0;i<=8;i++){const u=i/8;g.lineTo(u*L,top+Math.sin(t*4+u*5)*u*3);}
 for(let i=8;i>=0;i--){const u=i/8;g.lineTo(u*L,top+Hh+Math.sin(t*4+u*5)*u*3);}g.closePath();g.clip();
 g.fillStyle='#f3ecdc';g.fillRect(0,top-5,L,Hh+10);g.fillStyle='#c8221e';g.fillRect(14,top-5,6,Hh+10);g.fillRect(0,top+9,L,6);g.restore();
 for(const by of [-2,5]){ell(g,-38,by-6,8,4);g.fillStyle='#e8e0d0';g.fill();ell(g,-46,by-8,3,2.5);g.fill();}}

// ===================== edifici =====================
function merlons(g,x0,x1,y,col,style){for(let x=x0;x<=x1-4;x+=6){g.fillStyle=col;
 if(style==='g'){g.fillRect(x,y-5,4,5);g.fillStyle='rgba(255,255,255,.25)';g.fillRect(x,y-5,4,1.2);}
 else{g.beginPath();g.moveTo(x,y);g.lineTo(x,y-6);g.lineTo(x+1.4,y-6);g.lineTo(x+2.2,y-3.6);g.lineTo(x+3,y-6);g.lineTo(x+4.4,y-6);g.lineTo(x+4.4,y);g.closePath();g.fill();}}}
function facade(g,x0,x1,yb,fh,rd,wall,roof,fac,o){o=o||{};const w=x1-x0;
 fh+=[0,3,0,5,2,-2,6,4][fac]||0;
 g.fillStyle='rgba(30,35,15,.3)';g.beginPath();g.moveTo(x1,yb);g.lineTo(x1+fh*.6,yb-5);g.lineTo(x1+fh*.6,yb-fh-rd*.8);g.lineTo(x1,yb-fh-rd);g.closePath();g.fill();
 ell(g,(x0+x1)/2+6,yb+2,w*.55,5);g.fill();
 g.fillStyle=wall;g.fillRect(x0,yb-fh,w,fh);g.fillStyle=shade(wall,-.12);g.fillRect(x1-5,yb-fh,5,fh);
 if(fac===1){g.fillStyle='#eee7d9';g.fillRect(x0,yb-fh+10,w,4);g.fillStyle='#36312e';g.fillRect(x0,yb-fh+14,w,3);}
 if(fac===5){g.fillStyle='#e7e8e0';g.fillRect(x0+3,yb-fh,4,fh);g.fillRect(x1-7,yb-fh,4,fh);}
 g.strokeStyle='rgba(60,40,20,.12)';g.lineWidth=1;for(let yy=yb-fh+5;yy<yb;yy+=5){g.beginPath();g.moveTo(x0,yy);g.lineTo(x1,yy);g.stroke();}
 g.fillStyle='rgba(40,25,15,.2)';g.fillRect(x0,yb-3,w,3);
 const nw=Math.max(1,Math.floor(w/18));for(let i=0;i<nw;i++){const wx=x0+(i+.5)*w/nw-2.5;g.fillStyle='#3a2a1e';rr(g,wx,yb-fh+7,5,8,2.5);g.fill();if(fh>42){rr(g,wx,yb-fh+25,5,8,2.5);g.fill();}}
 if(!o.noDoor){const dw=o.bigDoor?16:9;g.fillStyle='#4a3020';rr(g,(x0+x1)/2-dw/2,yb-(o.bigDoor?20:12),dw,o.bigDoor?20:12,dw/2);g.fill();}
 if(o.flat){g.fillStyle=shade(wall,.24);g.fillRect(x0-2,yb-fh-rd,w+4,rd);g.fillStyle='rgba(0,0,0,.08)';g.fillRect(x0+4,yb-fh-rd+6,w-8,rd-10);
  merlons(g,x0-2,x1+2,yb-fh,shade(wall,.05),FAC[fac].merlo);merlons(g,x0-2,x1+2,yb-fh-rd+5,shade(wall,.1),FAC[fac].merlo);}
 else{g.fillStyle=shade(roof,-.2);g.fillRect(x0-3,yb-fh-rd,w+6,rd*.5);g.fillStyle=roof;g.fillRect(x0-3,yb-fh-rd*.5,w+6,rd*.5+1);
  g.strokeStyle='rgba(70,25,10,.33)';g.lineWidth=1;for(let xx=x0;xx<x1+3;xx+=3.5){g.beginPath();g.moveTo(xx,yb-fh-rd);g.lineTo(xx,yb-fh+1);g.stroke();}
  g.fillStyle=shade(roof,.25);g.fillRect(x0-3,yb-fh-rd*.5-1,w+6,1.8);g.fillStyle='rgba(0,0,0,.25)';g.fillRect(x0-3,yb-fh,w+6,1.6);}
 buildingIdentity(g,fac,x0,x1,yb,fh,rd,o.flat);}
// Sagome e dettagli ripetuti anche su case, magazzini, scuderie e officine.
function buildingIdentity(g,fac,x0,x1,yb,fh,rd,flat){const f=FAC[fac],w=x1-x0,mid=(x0+x1)/2,top=yb-fh-rd;
 g.fillStyle=f.tunic2;g.fillRect(x0+2,yb-fh+2,w-4,3);
 switch(fac){
  case 0: // Loggia chiara sotto il tetto rosso.
   for(const x of [x0+7,x1-12]){g.fillStyle='#f4ecd6';g.fillRect(x-2,yb-20,9,18);g.fillStyle='#604836';rr(g,x,yb-16,5,14,2.5);g.fill();}break;
  case 1: // Terrazza merlata e fascia della Balzana.
   if(!flat){g.fillStyle=f.stone;g.fillRect(x0-3,top-4,w+6,7);merlons(g,x0-3,x1+3,top-4,f.stone,'s');}break;
  case 3: // Frontone largo blu con cornice oro.
   if(!flat){g.fillStyle=f.roof;g.beginPath();g.moveTo(x0-4,top+12);g.lineTo(mid,top-8);g.lineTo(x1+4,top+12);g.closePath();g.fill();g.strokeStyle='#dfbc58';g.lineWidth=2;g.stroke();}
   for(const x of [x0+2,x1-5]){g.fillStyle='#eee0b2';g.fillRect(x,yb-fh,3,fh);}break;
  case 4: // Guglia centrale e croce sul frontone.
   if(!flat){g.fillStyle=f.roof;g.beginPath();g.moveTo(mid-14,top+14);g.lineTo(mid,top-13);g.lineTo(mid+14,top+14);g.closePath();g.fill();g.fillStyle='#eee7d5';g.fillRect(mid-1,top-4,2,13);g.fillRect(mid-5,top+1,10,2);}break;
  case 5: // Tetto d'ardesia basso e doppio arco chiaro.
   if(!flat){g.fillStyle=f.stone;g.fillRect(x0-3,top-3,w+6,5);g.fillStyle='#e7e8e0';for(let x=x0+2;x<x1;x+=10)g.fillRect(x,top-8,4,7);}
   for(const x of [x0+12,x1-17]){g.strokeStyle='#e7e8e0';g.lineWidth=2;rr(g,x,yb-21,6,17,3);g.stroke();}break;
  case 6: // Portale monumentale e timpano arrotondato.
   if(!flat){g.fillStyle='#f2e7cc';g.beginPath();g.moveTo(mid-16,top+10);g.quadraticCurveTo(mid,top-16,mid+16,top+10);g.closePath();g.fill();g.strokeStyle='#b78d2b';g.lineWidth=2;g.stroke();}
   g.fillStyle='#d5b75a';g.fillRect(mid-9,yb-23,3,23);g.fillRect(mid+6,yb-23,3,23);g.fillRect(mid-9,yb-24,18,3);break;
  case 7: // Due torrette asimmetriche su mattone rosso.
   if(!flat)for(const [x,h] of [[x0+4,19],[x1-12,27]]){g.fillStyle=f.stone;g.fillRect(x,top-h,8,h+12);g.fillStyle='#423c3b';g.fillRect(x+3,top-h+6,2,5);merlons(g,x-1,x+9,top-h,f.stone,'g');}break;
 }
 // L'insegna è ferma: colore e stemma restano leggibili senza luci o scintille.
 stemma(g,fac,mid-4,yb-fh+6,8,10);}
function towerArt(g,cx,yb,w,h,fac,tall){const f=FAC[fac],wall=f.stone;
 if(!tall){w=[36,30,36,42,34,44,40,26][fac];h=[80,96,80,76,88,68,82,104][fac];}
 g.fillStyle='rgba(30,35,15,.3)';g.beginPath();g.moveTo(cx+w/2,yb);g.lineTo(cx+w/2+h*.5,yb-6);g.lineTo(cx+w/2+h*.5,yb-w*.5-6);g.lineTo(cx+w/2,yb-w*.5);g.closePath();g.fill();
 g.fillStyle=wall;g.fillRect(cx-w/2,yb-h,w,h);g.fillStyle=shade(wall,-.15);g.fillRect(cx+w/2-6,yb-h,6,h);
 if(fac===1){g.fillStyle='#eee7d9';for(let y=yb-h+12;y<yb-5;y+=22)g.fillRect(cx-w/2,y,w,4);}
 if(fac===5){g.fillStyle='#e7e8e0';g.fillRect(cx-w/2+3,yb-h,3,h);g.fillRect(cx+w/2-6,yb-h,3,h);}
 if(fac===3||fac===6){g.fillStyle=f.pen;g.fillRect(cx-w/2,yb-h+7,w,4);}
 g.strokeStyle='rgba(60,40,20,.15)';g.lineWidth=1;for(let yy=yb-h+4;yy<yb;yy+=4){g.beginPath();g.moveTo(cx-w/2,yy);g.lineTo(cx+w/2,yy);g.stroke();}
 g.fillStyle=shade(wall,-.05);g.fillRect(cx-w/2-3,yb-h-6,w+6,7);g.fillStyle='rgba(0,0,0,.25)';for(let xx=cx-w/2-2;xx<cx+w/2+2;xx+=4)g.fillRect(xx,yb-h+1,2,3);
 g.fillStyle=shade(wall,.28);g.fillRect(cx-w/2-3,yb-h-6-w*.45,w+6,w*.45);merlons(g,cx-w/2-3,cx+w/2+3,yb-h-6,shade(wall,.1),f.merlo);
 g.fillStyle='#2e2018';const nwin=tall?4:2;for(let i=0;i<nwin;i++){rr(g,cx-2,yb-h+10+i*(h-20)/nwin,4,7,2);g.fill();}
 return [cx,yb-h-6-w*.45];}
const BPAD={l:14,r:72,b:12};
function bTop(kind,fac){return kind==='palazzo'?FAC[fac].tower.h+80:kind==='torre'?150:kind==='campo'?20:90;}
const BSPR={},BMETA={};
function bldSpr(kind,fac){const k=kind+fac;if(BSPR[k])return BSPR[k];const d=BT[kind],w=d.w*CELL,h=d.h*CELL,top=bTop(kind,fac);
 const c=mkCanvas((w+BPAD.l+BPAD.r)*2,(h+top+BPAD.b)*2),g=c.getContext('2d');g.scale(2,2);g.translate(BPAD.l,top);
 const meta={flags:[],top};const f=FAC[fac];
 switch(kind){
  case 'palazzo':{const T0=FAC[fac].tower,tw=T0.w,th=T0.h,tx=w*.5+T0.dx;meta.flags.push([...towerArt(g,tx,h-62,tw,th,fac,true),1]);
   facade(g,4,w-4,h-2,60,46,f.stone,f.roof,fac,{flat:true,bigDoor:true});stemma(g,fac,w/2-10,h-56,20,24);
   if(FAC[fac].arms==='giglio'){g.fillStyle='#8a8070';for(let x=12;x<w-12;x+=14){rr(g,x,h-50,6,10,3);g.fill();}}break;}
  case 'casa':facade(g,6,w-6,h-2,26,34,f.house,f.roof,fac);break;
  case 'magaz':{facade(g,4,w-18,h-2,24,32,f.house,f.roof,fac);for(let i=0;i<4;i++){ell(g,w-12+(i%2)*6,h-6-Math.floor(i/2)*6,3.2,3.2);g.fillStyle='#b58a52';g.fill();g.strokeStyle='#5a3a1a';g.lineWidth=.8;g.stroke();}
   ell(g,w-4,h-14,3,4);g.fillStyle='#8a6a3a';g.fill();break;}
  case 'caserma':{facade(g,4,w-4,h-2,36,52,f.stone,f.roof,fac,{bigDoor:true});
   for(let i=0;i<4;i++)stemma(g,fac,12+i*20,h-31,8,11);
   g.strokeStyle='#4a3020';g.lineWidth=1.5;g.beginPath();g.moveTo(w-8,h-2);g.lineTo(w-8,h-56);g.stroke();meta.flags.push([w-8,h-56,0]);break;}
  case 'scuderia':{facade(g,6,w-6,h-14,30,48,f.house,f.roof,fac,{bigDoor:true});
   g.strokeStyle='#6b4a28';g.lineWidth=2;g.beginPath();g.moveTo(2,h-2);g.lineTo(w-2,h-2);g.moveTo(2,h-7);g.lineTo(w-2,h-7);g.stroke();
   for(let x=2;x<=w-2;x+=12){g.beginPath();g.moveTo(x,h);g.lineTo(x,h-10);g.stroke();}drawHay(g,w-14,h-14,7);break;}
  case 'officina':{facade(g,4,w-26,h-2,32,48,f.house,f.roof,fac,{bigDoor:true});
   g.strokeStyle='#5c3e22';g.lineWidth=3;g.lineCap='round';g.beginPath();g.moveTo(w-24,h-2);g.lineTo(w-14,h-40);g.lineTo(w-4,h-2);g.stroke();
   g.strokeStyle='#7a5430';g.lineWidth=2.4;g.beginPath();g.moveTo(w-30,h-30);g.lineTo(w+4,h-56);g.stroke();g.fillStyle='#4e4a44';g.fillRect(w-34,h-32,8,10);break;}
  case 'torre':meta.flags.push([...towerArt(g,w/2,h-4,36,80,fac,false),0]);break;
  case 'campo':{g.save();rr(g,3,3,w-6,h-6,6);g.fillStyle='#d6b558';g.fill();g.clip();g.fillStyle='#c09a40';for(let x=3;x<w;x+=9)g.fillRect(x,3,4,h);
   g.restore();g.strokeStyle='rgba(90,70,30,.45)';g.lineWidth=2.5;rr(g,3,3,w-6,h-6,6);g.stroke();drawHay(g,w-16,h-10,6);stemma(g,fac,6,h-18,9,12);break;}
 }
 BSPR[k]=c;BMETA[k]=meta;return c;}
function drawFlag(ctx,x,y,fac,big,t){const L=big?26:18,Hh=big?16:11;
 ctx.strokeStyle='#3a2a1a';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x,y-L-6);ctx.stroke();
 const top=y-L-6,N=8;ctx.save();ctx.beginPath();for(let i=0;i<=N;i++){const u=i/N;ctx.lineTo(x+u*L,top+Math.sin(t*5+u*5+x)*u*3);}
 for(let i=N;i>=0;i--){const u=i/N;ctx.lineTo(x+u*L,top+Hh+Math.sin(t*5+u*5+x)*u*3);}ctx.closePath();ctx.clip();
 paintArms(ctx,fac,x,top-6,L,Hh+12);
 ctx.restore();}
function drawWall(ctx,b){const fac=teams[b.team].fac,c=FAC[fac].stone,x0=b.x0,y0=b.y0,H=22;
 const isW=(cx,cy)=>{if(!inb(cx,cy))return false;const o=bAt[cy*GW+cx];return o&&o.def.wall&&o.team===b.team;};
 const L=isW(b.cx-1,b.cy),Rt=isW(b.cx+1,b.cy),U=isW(b.cx,b.cy-1),D=isW(b.cx,b.cy+1);
 let lx=x0+8,rx=x0+24,ty=y0+8,by=y0+24;if(L)lx=x0;if(Rt)rx=x0+32;if(U)ty=y0;if(D)by=y0+32;
 ctx.globalAlpha=b.built?1:.45;
 ctx.fillStyle='rgba(30,35,15,.28)';ctx.fillRect(rx,ty-H+8,10,by-ty+H-8);
 if(!D){ctx.fillStyle=shade(c,-.16);ctx.fillRect(lx,by-H,rx-lx,H);ctx.strokeStyle='rgba(60,40,20,.2)';ctx.lineWidth=1;
  for(let y=by-H+5;y<by;y+=5){ctx.beginPath();ctx.moveTo(lx,y);ctx.lineTo(rx,y);ctx.stroke();}
  if(b.def.gate){ctx.fillStyle='#3a2616';rr(ctx,x0+9,by-17,14,17,7);ctx.fill();ctx.strokeStyle='#7a5430';ctx.lineWidth=1;for(let x=x0+12;x<x0+22;x+=3){ctx.beginPath();ctx.moveTo(x,by-15);ctx.lineTo(x,by);ctx.stroke();}}}
 ctx.fillStyle=shade(c,.2);ctx.fillRect(lx,ty-H,rx-lx,by-ty);
 const mc=shade(c,.05),st=FAC[fac].merlo;
 if(L||Rt||(!U&&!D))merlons(ctx,lx,rx,by-H,mc,st);
 if(U||D){for(let y=ty-H+4;y<by-H-2;y+=7){for(const ex of [lx,rx-4]){ctx.fillStyle=shade(c,-.05);ctx.fillRect(ex,y,4,4);ctx.fillStyle=shade(c,.35);ctx.fillRect(ex,y-2.5,4,2.5);}}}
 if(b.def.gate){ctx.fillStyle='#6a4626';ctx.fillRect(x0+5,y0+5-H,22,22);ctx.strokeStyle='#3a2616';ctx.lineWidth=1;for(let k=0;k<4;k++){ctx.beginPath();ctx.moveTo(x0+5,y0+9-H+k*5);ctx.lineTo(x0+27,y0+9-H+k*5);ctx.stroke();}
  ctx.strokeRect(x0+5,y0+5-H,22,22);ctx.fillStyle=FAC[fac].tunic;ctx.fillRect(x0+14,y0-H-6,4,8);}
 ctx.globalAlpha=1;}
function drawCamp(ctx,c,t){if(c.conquered)return;for(const [dx,dy,s] of [[-40,-20,1],[38,-26,.9],[-10,34,1.1]]){const x=c.x+dx,y=c.y+dy;
  ell(ctx,x+6,y+1,18*s,5*s);ctx.fillStyle='rgba(25,30,10,.35)';ctx.fill();
  ctx.fillStyle='#b9a27a';ctx.beginPath();ctx.moveTo(x-16*s,y);ctx.lineTo(x,y-22*s);ctx.lineTo(x+16*s,y);ctx.closePath();ctx.fill();
  ctx.fillStyle='#8a7350';ctx.beginPath();ctx.moveTo(x,y-22*s);ctx.lineTo(x+16*s,y);ctx.lineTo(x+4*s,y);ctx.closePath();ctx.fill();
  ctx.fillStyle='#3a2a1a';ctx.beginPath();ctx.moveTo(x-4*s,y);ctx.lineTo(x,y-9*s);ctx.lineTo(x+4*s,y);ctx.fill();}
 const fx=c.x+8,fy=c.y+6;ell(ctx,fx,fy,9,4);ctx.fillStyle='#4a3a2a';ctx.fill();
 ctx.strokeStyle='#765539';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(fx-6,fy-3);ctx.lineTo(fx+6,fy+2);ctx.moveTo(fx+5,fy-4);ctx.lineTo(fx-5,fy+2);ctx.stroke();
 if(c.relic){const rx=c.x-6,ry=c.y-2;
  ctx.fillStyle='#7a4a1a';rr(ctx,rx-9,ry-12,18,12,2);ctx.fill();ctx.fillStyle='#e0a530';ctx.fillRect(rx-9,ry-9,18,2.5);ctx.fillRect(rx-1.5,ry-12,3,12);
  ctx.fillStyle='#9a6a2a';rr(ctx,rx-9,ry-17,18,6,3);ctx.fill();}}
function drawCorpse(ctx,d){const a=Math.min(1,(d.life-d.t)*.6)*.85;if(a<=0)return;ctx.save();ctx.globalAlpha=a;ctx.translate(d.x,d.y);ctx.scale(d.f,1);const f=FAC[d.fac];
 ell(ctx,0,0,d.big?12:7,3);ctx.fillStyle='rgba(30,30,10,.3)';ctx.fill();if(d.big){ell(ctx,0,-3,11,4);ctx.fillStyle=f.horse;ctx.fill();}
 ctx.rotate(-1.4);rr(ctx,-4,-9,8,10,3);ctx.fillStyle=d.worker?'#8b6b45':f.tunic;ctx.fill();ctx.restore();}

// ===================== icone per l'interfaccia =====================
function iconUnit(fac,type,size){const c=mkCanvas(size,size),g=c.getContext('2d');
 if(UT[type].cls==='treb'){const k=type==='mang'?.8:1;g.translate(size*.48,size*.86);g.scale(size/58*k,size/58*k);drawTrebArt(g,fac,-.6,true);}
 else if(type==='carr'){g.translate(size*.55,size*.85);g.scale(size/80,size/80);drawCarrArt(g,fac,0);}
 else{const big=isHorse(type);const s=size/(UT[type].hero?58:big?40:34);g.translate(size*.5-(big?2:0),size*.9);g.scale(s,s);drawUnitArt(g,fac,type,POSE.i);}return c;}
function iconBld(kind,fac,size){const c=mkCanvas(size,size),g=c.getContext('2d');
 if(kind==='mura'||kind==='porta'){const s=size/40;g.scale(s,s);const st=FAC[fac].stone;g.fillStyle=shade(st,-.16);g.fillRect(2,18,36,18);g.fillStyle=shade(st,.2);g.fillRect(2,10,36,8);merlons(g,2,38,18,shade(st,.05),FAC[fac].merlo);
  if(kind==='porta'){g.fillStyle='#3a2616';rr(g,13,20,14,16,7);g.fill();}return c;}
 const spr=bldSpr(kind,fac),d=BT[kind],w=d.w*CELL,h=d.h*CELL,top=bTop(kind,fac);const sw=w+BPAD.l+BPAD.r-40,sh=h+top+BPAD.b;
 const k=Math.min(size/sw,size/sh)*(kind==='palazzo'?1.2:1.15);g.drawImage(spr,0,0,spr.width-80,spr.height,(size-sw*k)/2,(size-sh*k)/2+(kind==='palazzo'?8:0),sw*k,sh*k);return c;}
