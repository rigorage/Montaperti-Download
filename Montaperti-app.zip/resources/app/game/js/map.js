'use strict';
// ===================== griglia della mappa =====================
let NCELL=GW*GH;
let water=new Uint8Array(NCELL),tree=new Float32Array(NCELL),stone=new Float32Array(NCELL),decor=new Uint8Array(NCELL),stump=new Uint8Array(NCELL);
// La scadenza sopravvive al ceppo: costruire su un albero abbattuto non annulla la ricrescita.
const treeRegrowAt=new Map();
const bAt=new Array(NCELL).fill(null);
let gridVer=1;
const bases=[],fords=[],rivers=[],roads=[],vines=[];
const DX=[1,-1,0,0,1,1,-1,-1],DY=[0,0,1,-1,1,-1,1,-1],DC=[1,1,1,1,1.4142,1.4142,1.4142,1.4142];

function passFor(team,i){if(water[i]===1||tree[i]>0||stone[i]>0)return false;const b=bAt[i];
 if(b){if(b.def.flat)return true;if(b.def.gate&&areAllies(b.team,team)&&b.built)return true;return false;}return true;}
function cellCost(team,i){if(water[i]===1||tree[i]>0||stone[i]>0)return Infinity;const b=bAt[i];
 if(b&&!b.def.flat){if(areAllies(b.team,team))return(b.def.gate&&b.built)?1:Infinity;return 18;}return water[i]===2?1.6:1;}

// ===================== generazione =====================
// Solo la 5v5 aggiunge una quinta corsia: le mappe precedenti restano 150x100.
// Anche i client passano da qui prima di ricevere lo stato della nuova partita.
function configureMapSize(){const height=playerCount()===10?124:100;if(GH===height)return;
 GH=height;WH=GH*CELL;NCELL=GW*GH;
 water=new Uint8Array(NCELL);tree=new Float32Array(NCELL);stone=new Float32Array(NCELL);decor=new Uint8Array(NCELL);stump=new Uint8Array(NCELL);bAt.length=NCELL;bAt.fill(null);
 HEAP=new Heap(NCELL*9);AG=new Float32Array(NCELL);AF=new Int32Array(NCELL);AS=new Uint32Array(NCELL);ACL=new Uint32Array(NCELL);AST=1;ASTAR_OK=true;ASTAR_STATUS='reached';
 fieldCache.clear();gridVer++;terrC=miniT=null;if(typeof resizeSimGrid==='function')resizeSimGrid();}
function genMap(seed){configureMapSize();treeRegrowAt.clear();for(let a=0;a<40;a++){srand(seed+a*7919);const n=playerCount();if(n===10?tryGenFour(true,false,true):n===8?tryGenFour(true):n===4?tryGenFour(isTeamMatch(),isTeamMatch()):n===6?tryGenCoop():n===3?tryGenFFA():tryGen())return true;}return false;}
function bfs(sx,sy){const seen=new Uint8Array(NCELL);const q=[sy*GW+sx];seen[q[0]]=1;
 for(let h=0;h<q.length;h++){const c=q[h],x=c%GW,y=(c/GW)|0;for(let k=0;k<4;k++){const nx=x+DX[k],ny=y+DY[k];if(!inb(nx,ny))continue;const n=ny*GW+nx;
  if(seen[n]||water[n]===1||tree[n]>0||stone[n]>0)continue;seen[n]=1;q.push(n);}}return seen;}
function tryGen(){
 water.fill(0);tree.fill(0);stone.fill(0);decor.fill(0);stump.fill(0);bAt.fill(null);
 bases.length=0;fords.length=0;rivers.length=0;roads.length=0;vines.length=0;camps.length=0;
 bases.push({cx:RI(10,13),cy:RI(15,GH-16)});bases.push({cx:GW-1-RI(10,13),cy:RI(15,GH-16)});
 // due fiumi con i guadi
 for(const bx of [RI(46,58),RI(92,104)]){
  const ph=R(0,TAU),a=R(.05,.09),b2=R(.13,.2),amp=R(3,6),cs=[],ws=[];
  for(let y=0;y<GH;y++){const c=bx+Math.sin(y*a+ph)*amp+Math.sin(y*b2+ph*2)*1.6,w=1.55+Math.sin(y*.17+ph)*.35;cs.push(c);ws.push(w);
   for(let x=Math.floor(c-w-1);x<=Math.ceil(c+w+1);x++)if(x>=0&&x<GW&&Math.abs(x+.5-c)<=w)water[y*GW+x]=1;}
  const rv={cs,ws,fords:[]};rivers.push(rv);
  const n=RI(4,5),seg=GH/n;
  for(let k=0;k<n;k++){const fy=clamp(Math.floor(seg*k+R(seg*.25,seg*.75)),2,GH-3);rv.fords.push(fy);fords.push({x:cs[fy]*CELL,y:(fy+.5)*CELL,r:rivers.length-1,w:ws[fy]});
   for(let y=fy-2;y<=fy+2;y++){if(y<0||y>=GH)continue;const c=cs[y];for(let x=Math.floor(c-4);x<=Math.ceil(c+4);x++)if(x>=0&&x<GW&&water[y*GW+x]===1)water[y*GW+x]=2;}}
 }
 const nearBase=(x,y,r)=>bases.some(b=>hyp(b.cx-x,b.cy-y)<r);
 const nearFord=(x,y,r)=>fords.some(f=>hyp(f.x/CELL-x-.5,f.y/CELL-y-.5)<r);
 const salt=SEED%977;
 const blob=(cx,cy,r,fn)=>{for(let y=Math.floor(cy-r*1.4);y<=Math.ceil(cy+r*1.4);y++)for(let x=Math.floor(cx-r*1.4);x<=Math.ceil(cx+r*1.4);x++){
   if(!inb(x,y))continue;const d=hyp(x-cx,(y-cy)*1.15)/r+(hash2(x*3+salt,y*5+7)-.5)*.6;if(d<1)fn(x,y,y*GW+x);}};
 // boschi
 for(let k=0;k<62;k++)blob(RI(0,GW-1),RI(0,GH-1),R(2.5,8.5),(x,y,i)=>{if(!water[i]&&!nearBase(x,y,10)&&!nearFord(x,y,4.5))tree[i]=100;});
 for(let k=0;k<170;k++){const x=RI(0,GW-1),y=RI(0,GH-1),i=y*GW+x;if(!water[i]&&!nearBase(x,y,8)&&!nearFord(x,y,3))tree[i]=100;}
 // bosco e cava garantiti vicino a ogni base
 for(const b of bases){const a=R(0,TAU);
  const fx=clamp(b.cx+Math.cos(a)*13,4,GW-5),fy=clamp(b.cy+Math.sin(a)*12,4,GH-5);
  blob(fx,fy,R(4.5,6),(x,y,i)=>{if(!water[i]&&!nearBase(x,y,8.5))tree[i]=100;});
  const a2=a+Math.PI*R(.6,1.4);const sx=clamp(b.cx+Math.cos(a2)*11,3,GW-4),sy=clamp(b.cy+Math.sin(a2)*10,3,GH-4);
  blob(sx,sy,1.8,(x,y,i)=>{if(!water[i]&&!nearBase(x,y,7)){tree[i]=0;stone[i]=350;}});}
 for(let k=0;k<13;k++){const cx=RI(22,GW-23),cy=RI(4,GH-5);blob(cx,cy,R(1.3,2.1),(x,y,i)=>{if(!water[i]&&!nearFord(x,y,3)){tree[i]=0;stone[i]=350;}});}
 for(const b of bases)for(let y=b.cy-7;y<=b.cy+7;y++)for(let x=b.cx-7;x<=b.cx+7;x++)if(inb(x,y)){const i=y*GW+x;tree[i]=0;stone[i]=0;}
 // le due basi devono essere collegate
 const seen=bfs(bases[0].cx,bases[0].cy);if(!seen[bases[1].cy*GW+bases[1].cx])return false;
 // accampamenti dei briganti con le reliquie
 for(let k=0,tries=0;k<5&&tries<900;tries++){const cx=RI(26,GW-27),cy=RI(5,GH-6);
  if(nearBase(cx,cy,28)||camps.some(c=>hyp(c.cx-cx,c.cy-cy)<20)||!seen[cy*GW+cx])continue;let ok=true;
  // Il bordo libero lascia un passaggio anche dopo la comparsa della caserma e della torre.
  for(let y=cy-3;y<=cy+3&&ok;y++)for(let x=cx-3;x<=cx+3;x++){const i=y*GW+x;if(water[i]||tree[i]||stone[i]){ok=false;break;}}
  if(!ok)continue;camps.push({cx,cy,x:(cx+.5)*CELL,y:(cy+.5)*CELL,relic:true,owner:-1,conquered:false,guardIds:[],damage:[0,0],lastKill:-1,buildings:[]});k++;}
 if(camps.length<3)return false;
 // strade (solo decorative)
 for(let bi=0;bi<2;bi++){const b=bases[bi];const rv=bi===0?0:1;let best=null,bd=1e9;
  for(const f of fords)if(f.r===rv){const d=hyp(f.x-(b.cx+.5)*CELL,f.y-(b.cy+.5)*CELL);if(d<bd){bd=d;best=f;}}
  if(best)roads.push(mkRoad((b.cx+.5)*CELL,(b.cy+.5)*CELL,best.x,best.y));}
 for(const f of fords)if(f.r===0){let best=null,bd=1e9;for(const g of fords)if(g.r===1){const d=hyp(f.x-g.x,f.y-g.y);if(d<bd){bd=d;best=g;}}
  if(best&&rnd()<.6)roads.push(mkRoad(f.x,f.y,best.x,best.y));}
 // decorazioni
 const free=(x,y)=>{if(!inb(x,y))return false;const i=y*GW+x;return !water[i]&&!tree[i]&&!stone[i]&&!decor[i]&&!nearBase(x,y,6)&&!camps.some(c=>hyp(c.cx-x,c.cy-y)<4);};
 for(let k=0;k<18;k++){const x=RI(2,GW-3),y=RI(2,GH-3),h=rnd()<.5,L=RI(4,9),two=rnd()<.6;
  for(let j=0;j<L;j++){const xx=h?x+j:x,yy=h?y:y+j;if(free(xx,yy))decor[yy*GW+xx]=1;if(two){const x2=h?xx:xx+2,y2=h?yy+2:yy;if(free(x2,y2))decor[y2*GW+x2]=1;}}}
 for(let k=0;k<14;k++){const x0=RI(2,GW-9),y0=RI(2,GH-7);for(let y=y0;y<y0+5;y+=2)for(let x=x0;x<x0+7;x+=2)if(free(x,y))decor[y*GW+x]=2;}
 for(let k=0;k<600;k++){const x=RI(0,GW-1),y=RI(0,GH-1);if(free(x,y))decor[y*GW+x]=3;}
 for(let k=0;k<50;k++){const x=RI(0,GW-1),y=RI(0,GH-1);if(free(x,y))decor[y*GW+x]=4;}
 for(let k=0;k<24;k++){const x=RI(2,GW-9),y=RI(2,GH-7);if(free(x+2,y+2)&&free(x+4,y+1))vines.push({x:x*CELL,y:y*CELL,w:RI(4,7)*CELL,h:RI(3,5)*CELL,a:R(-.15,.15)});}
 return true;}
// Il duello conserva integralmente il generatore storico e la sua sequenza casuale.
// Tre partenze quasi equidistanti; le risorse iniziali hanno le stesse quantità.
function tryGenFFA(){
 water.fill(0);tree.fill(0);stone.fill(0);decor.fill(0);stump.fill(0);bAt.fill(null);
 bases.length=0;fords.length=0;rivers.length=0;roads.length=0;vines.length=0;camps.length=0;
 const flip=rnd()<.5,spots=[{cx:75,cy:18},{cx:38,cy:82},{cx:112,cy:82}];
 if(flip)for(const b of spots)b.cy=GH-b.cy;
 for(let i=spots.length-1;i>0;i--){const j=RI(0,i);[spots[i],spots[j]]=[spots[j],spots[i]];}bases.push(...spots);
 const center={cx:bases.reduce((n,b)=>n+b.cx,0)/3,cy:bases.reduce((n,b)=>n+b.cy,0)/3};
 const nearBase=(x,y,r)=>bases.some(b=>hyp(b.cx-x,b.cy-y)<r),nearCamp=(x,y,r)=>camps.some(c=>hyp(c.cx-x,c.cy-y)<r);
 for(let t=0;t<3;t++){const a=bases[t],b=bases[(t+1)%3],cx=Math.round((a.cx+b.cx)/2),cy=Math.round((a.cy+b.cy)/2);
  camps.push({cx,cy,x:(cx+.5)*CELL,y:(cy+.5)*CELL,relic:true,owner:-1,conquered:false,guardIds:[],damage:Array(playerCount()).fill(0),lastKill:-1,buildings:[]});}
 // Corridoi larghi seguono le strade: tre lati e tre vie interne, senza un guado obbligato.
 const routes=new Uint8Array(NCELL),mark=(x,y,r)=>{for(let yy=Math.floor(y-r);yy<=Math.ceil(y+r);yy++)for(let xx=Math.floor(x-r);xx<=Math.ceil(x+r);xx++)if(inb(xx,yy)&&hyp(xx-x,yy-y)<=r)routes[yy*GW+xx]=1;};
 const route=(a,b)=>{const road=mkRoad((a.cx+.5)*CELL,(a.cy+.5)*CELL,(b.cx+.5)*CELL,(b.cy+.5)*CELL);roads.push(road);
  for(let k=1;k<road.length;k++){const p=road[k-1],q=road[k],n=Math.ceil(hyp(q[0]-p[0],q[1]-p[1])/12);for(let j=0;j<=n;j++)mark((p[0]+(q[0]-p[0])*j/n)/CELL-.5,(p[1]+(q[1]-p[1])*j/n)/CELL-.5,3);}};
 for(let t=0;t<3;t++){route(bases[t],bases[(t+1)%3]);route(bases[t],center);}
 const salt=SEED%977,blob=(cx,cy,r,fn)=>{for(let y=Math.floor(cy-r*1.4);y<=Math.ceil(cy+r*1.4);y++)for(let x=Math.floor(cx-r*1.4);x<=Math.ceil(cx+r*1.4);x++){
  if(!inb(x,y))continue;const d=hyp(x-cx,(y-cy)*1.15)/r+(hash2(x*3+salt,y*5+7)-.5)*.6;if(d<1)fn(x,y,y*GW+x);}};
 const wild=(x,y,i)=>!nearBase(x,y,22)&&!nearCamp(x,y,5)&&!routes[i];
 for(let k=0;k<68;k++)blob(RI(1,GW-2),RI(1,GH-2),R(2.5,7),(x,y,i)=>{if(wild(x,y,i))tree[i]=100;});
 for(let k=0;k<16;k++)blob(RI(3,GW-4),RI(3,GH-4),R(1.4,2.1),(x,y,i)=>{if(wild(x,y,i)){tree[i]=0;stone[i]=350;}});
 // Quote esatte, orientate all'esterno del triangolo. I corridoi non vengono occupati.
 const resource=(b,angle,distance,count,arr,value)=>{const x0=b.cx+Math.cos(angle)*distance,y0=b.cy+Math.sin(angle)*distance,candidates=[];
  for(let y=Math.max(2,Math.floor(y0-6));y<=Math.min(GH-3,Math.ceil(y0+6));y++)for(let x=Math.max(2,Math.floor(x0-6));x<=Math.min(GW-3,Math.ceil(x0+6));x++){
   const i=y*GW+x,home=hyp(x-b.cx,y-b.cy);if(home<9||home>16||Math.max(Math.abs(x-b.cx),Math.abs(y-b.cy))<=8||routes[i]||tree[i]||stone[i])continue;candidates.push({i,x,y,d:(x-x0)**2+(y-y0)**2});}
  candidates.sort((a,b)=>a.d-b.d||a.i-b.i);if(candidates.length<count)return false;for(const p of candidates.slice(0,count))arr[p.i]=value;return true;};
 const handed=rnd()<.5?-1:1;
 for(const b of bases){const a=Math.atan2(b.cy-center.cy,b.cx-center.cx);if(!resource(b,a,13,48,tree,100)||!resource(b,a+handed*1.05,13,12,stone,350))return false;}
 const seen=bfs(bases[0].cx,bases[0].cy);if(bases.some(b=>!seen[b.cy*GW+b.cx])||camps.some(c=>!seen[c.cy*GW+c.cx]))return false;
 const free=(x,y)=>{if(!inb(x,y))return false;const i=y*GW+x;return !tree[i]&&!stone[i]&&!decor[i]&&!nearBase(x,y,8)&&!nearCamp(x,y,4);};
 for(let k=0;k<18;k++){const x=RI(2,GW-3),y=RI(2,GH-3),h=rnd()<.5,L=RI(4,9);for(let j=0;j<L;j++){const xx=h?x+j:x,yy=h?y:y+j;if(free(xx,yy))decor[yy*GW+xx]=1;}}
 for(let k=0;k<16;k++){const x0=RI(2,GW-9),y0=RI(2,GH-7);for(let y=y0;y<y0+5;y+=2)for(let x=x0;x<x0+7;x+=2)if(free(x,y))decor[y*GW+x]=2;}
 for(let k=0;k<650;k++){const x=RI(0,GW-1),y=RI(0,GH-1);if(free(x,y))decor[y*GW+x]=3;}
 for(let k=0;k<50;k++){const x=RI(0,GW-1),y=RI(0,GH-1);if(free(x,y))decor[y*GW+x]=4;}
 for(let k=0;k<24;k++){const x=RI(2,GW-9),y=RI(2,GH-7);if(free(x+2,y+2)&&free(x+4,y+1))vines.push({x:x*CELL,y:y*CELL,w:RI(4,7)*CELL,h:RI(3,5)*CELL,a:R(-.15,.15)});}
 return true;}
// Sei città su due fronti: risorse esterne, cantieri verso il centro e tre vie collegate.
// Generatore separato: duello e tutti-contro-tutti non consumano nuovi numeri casuali.
function tryGenCoop(){
 water.fill(0);tree.fill(0);stone.fill(0);decor.fill(0);stump.fill(0);bAt.fill(null);
 bases.length=0;fords.length=0;rivers.length=0;roads.length=0;vines.length=0;camps.length=0;
 const rows=[18,50,82],flip=rnd()<.5,order=[0,1,2];
 for(let i=2;i>0;i--){const j=RI(0,i);[order[i],order[j]]=[order[j],order[i]];}
 for(let side=0;side<2;side++)for(const row of order)bases.push({cx:(side===0)!==flip?20:130,cy:rows[row]});
 for(const cy of rows){const cx=75;camps.push({cx,cy,x:(cx+.5)*CELL,y:(cy+.5)*CELL,relic:true,owner:-1,conquered:false,guardIds:[],damage:Array(playerCount()).fill(0),lastKill:-1,buildings:[]});}
 const nearBase=(x,y,r)=>bases.some(b=>hyp(b.cx-x,b.cy-y)<r),nearCamp=(x,y,r)=>camps.some(c=>hyp(c.cx-x,c.cy-y)<r);
 const routes=new Uint8Array(NCELL),mark=(x,y,r)=>{for(let yy=Math.floor(y-r);yy<=Math.ceil(y+r);yy++)for(let xx=Math.floor(x-r);xx<=Math.ceil(x+r);xx++)if(inb(xx,yy)&&hyp(xx-x,yy-y)<=r)routes[yy*GW+xx]=1;};
 const route=(a,b)=>{const road=mkRoad((a.cx+.5)*CELL,(a.cy+.5)*CELL,(b.cx+.5)*CELL,(b.cy+.5)*CELL);roads.push(road);
  for(let k=1;k<road.length;k++){const p=road[k-1],q=road[k],n=Math.ceil(hyp(q[0]-p[0],q[1]-p[1])/12);for(let j=0;j<=n;j++)mark((p[0]+(q[0]-p[0])*j/n)/CELL-.5,(p[1]+(q[1]-p[1])*j/n)/CELL-.5,3);}};
 for(const cy of rows)route({cx:20,cy},{cx:130,cy});
 for(const cx of [42,75,108])route({cx,cy:18},{cx,cy:82});
 const salt=SEED%977,blob=(cx,cy,r,fn)=>{for(let y=Math.floor(cy-r*1.4);y<=Math.ceil(cy+r*1.4);y++)for(let x=Math.floor(cx-r*1.4);x<=Math.ceil(cx+r*1.4);x++){
  if(!inb(x,y))continue;const d=hyp(x-cx,(y-cy)*1.15)/r+(hash2(x*3+salt,y*5+7)-.5)*.6;if(d<1)fn(x,y,y*GW+x);}};
 const wild=(x,y,i)=>!nearBase(x,y,22)&&!nearCamp(x,y,5)&&!routes[i];
 for(let k=0;k<62;k++)blob(RI(1,GW-2),RI(1,GH-2),R(2.5,7),(x,y,i)=>{if(wild(x,y,i))tree[i]=100;});
 for(let k=0;k<15;k++)blob(RI(3,GW-4),RI(3,GH-4),R(1.4,2.1),(x,y,i)=>{if(wild(x,y,i)){tree[i]=0;stone[i]=350;}});
 const resource=(b,a,count,arr,value)=>{const x0=b.cx+Math.cos(a)*13,y0=b.cy+Math.sin(a)*13,candidates=[];
  for(let y=Math.max(2,Math.floor(y0-6));y<=Math.min(GH-3,Math.ceil(y0+6));y++)for(let x=Math.max(2,Math.floor(x0-6));x<=Math.min(GW-3,Math.ceil(x0+6));x++){
   const i=y*GW+x,d=hyp(x-b.cx,y-b.cy);if(d<9||d>16||Math.max(Math.abs(x-b.cx),Math.abs(y-b.cy))<=8||routes[i]||tree[i]||stone[i])continue;candidates.push({i,d:(x-x0)**2+(y-y0)**2});}
  candidates.sort((a,b)=>a.d-b.d||a.i-b.i);if(candidates.length<count)return false;for(const p of candidates.slice(0,count))arr[p.i]=value;return true;};
 const handed=rnd()<.5?-1:1;for(const b of bases){const a=b.cx<GW/2?Math.PI:0;if(!resource(b,a,48,tree,100)||!resource(b,a+handed*1.05,12,stone,350))return false;}
 const seen=bfs(bases[0].cx,bases[0].cy);if(bases.some(b=>!seen[b.cy*GW+b.cx])||camps.some(c=>!seen[c.cy*GW+c.cx]))return false;
 const free=(x,y)=>{if(!inb(x,y))return false;const i=y*GW+x;return !tree[i]&&!stone[i]&&!decor[i]&&!nearBase(x,y,8)&&!nearCamp(x,y,4);};
 for(let k=0;k<18;k++){const x=RI(2,GW-3),y=RI(2,GH-3),h=rnd()<.5,L=RI(4,9);for(let j=0;j<L;j++){const xx=h?x+j:x,yy=h?y:y+j;if(free(xx,yy))decor[yy*GW+xx]=1;}}
 for(let k=0;k<16;k++){const x0=RI(2,GW-9),y0=RI(2,GH-7);for(let y=y0;y<y0+5;y+=2)for(let x=x0;x<x0+7;x+=2)if(free(x,y))decor[y*GW+x]=2;}
 for(let k=0;k<650;k++){const x=RI(0,GW-1),y=RI(0,GH-1);if(free(x,y))decor[y*GW+x]=3;}
 for(let k=0;k<50;k++){const x=RI(0,GW-1),y=RI(0,GH-1);if(free(x,y))decor[y*GW+x]=4;}
 for(let k=0;k<24;k++){const x=RI(2,GW-9),y=RI(2,GH-7);if(free(x+2,y+2)&&free(x+4,y+1))vines.push({x:x*CELL,y:y*CELL,w:RI(4,7)*CELL,h:RI(3,5)*CELL,a:R(-.15,.15)});}
 return true;}
// Nuove mappe a quattro umani: non alterano i generatori storici 2/3/6.
// Quattro città isolate oppure due schieramenti da quattro, sempre su 150x100 celle.
function tryGenFour(coop,paired=false,five=false){
 water.fill(0);tree.fill(0);stone.fill(0);decor.fill(0);stump.fill(0);bAt.fill(null);
 bases.length=0;fords.length=0;rivers.length=0;roads.length=0;vines.length=0;camps.length=0;
 const rows=five?[14,38,62,86,110]:paired?[26,74]:[14,38,62,86],corners=[{cx:43,cy:18},{cx:107,cy:18},{cx:107,cy:82},{cx:43,cy:82}];
 if(coop){const flip=rnd()<.5,order=rows.map((_,i)=>i);for(let i=order.length-1;i>0;i--){const j=RI(0,i);[order[i],order[j]]=[order[j],order[i]];}
  for(let side=0;side<2;side++)for(const row of order)bases.push({cx:(side===0)!==flip?20:130,cy:rows[row]});
 }else{const spots=corners.map(b=>({...b}));for(let i=3;i>0;i--){const j=RI(0,i);[spots[i],spots[j]]=[spots[j],spots[i]];}bases.push(...spots);}
 const sites=coop?rows.map(cy=>({cx:75,cy})):[{cx:75,cy:18},{cx:107,cy:50},{cx:75,cy:82},{cx:43,cy:50}];
 for(const {cx,cy} of sites)camps.push({cx,cy,x:(cx+.5)*CELL,y:(cy+.5)*CELL,relic:true,owner:-1,conquered:false,guardIds:[],damage:Array(playerCount()).fill(0),lastKill:-1,buildings:[]});
 const nearBase=(x,y,r)=>bases.some(b=>hyp(b.cx-x,b.cy-y)<r),nearCamp=(x,y,r)=>camps.some(c=>hyp(c.cx-x,c.cy-y)<r);
 const routes=new Uint8Array(NCELL),mark=(x,y,r)=>{for(let yy=Math.floor(y-r);yy<=Math.ceil(y+r);yy++)for(let xx=Math.floor(x-r);xx<=Math.ceil(x+r);xx++)if(inb(xx,yy)&&hyp(xx-x,yy-y)<=r)routes[yy*GW+xx]=1;};
 const route=(a,b)=>{const road=mkRoad((a.cx+.5)*CELL,(a.cy+.5)*CELL,(b.cx+.5)*CELL,(b.cy+.5)*CELL);roads.push(road);
  for(let k=1;k<road.length;k++){const p=road[k-1],q=road[k],n=Math.ceil(hyp(q[0]-p[0],q[1]-p[1])/12);for(let j=0;j<=n;j++)mark((p[0]+(q[0]-p[0])*j/n)/CELL-.5,(p[1]+(q[1]-p[1])*j/n)/CELL-.5,3);}};
 if(coop){for(const cy of rows)route({cx:20,cy},{cx:130,cy});for(const cx of[42,75,108])route({cx,cy:rows[0]},{cx,cy:rows[rows.length-1]});}
 else for(let t=0;t<4;t++){route(corners[t],corners[(t+1)%4]);route(corners[t],{cx:75,cy:50});}
 const salt=SEED%977,blob=(cx,cy,r,fn)=>{for(let y=Math.floor(cy-r*1.4);y<=Math.ceil(cy+r*1.4);y++)for(let x=Math.floor(cx-r*1.4);x<=Math.ceil(cx+r*1.4);x++){
  if(!inb(x,y))continue;const d=hyp(x-cx,(y-cy)*1.15)/r+(hash2(x*3+salt,y*5+7)-.5)*.6;if(d<1)fn(x,y,y*GW+x);}};
 const wild=(x,y,i)=>!nearBase(x,y,22)&&!nearCamp(x,y,5)&&!routes[i];
 for(let k=0;k<68;k++)blob(RI(1,GW-2),RI(1,GH-2),R(2.5,7),(x,y,i)=>{if(wild(x,y,i))tree[i]=100;});
 for(let k=0;k<16;k++)blob(RI(3,GW-4),RI(3,GH-4),R(1.4,2.1),(x,y,i)=>{if(wild(x,y,i)){tree[i]=0;stone[i]=350;}});
 // Depositi esterni identici. In coop le città alleate distano 24 celle:
 // dx>=9 e |dy|<=8 tengono ogni deposito oltre 16 celle dalle altre basi.
 const handed=rnd()<.5?-1:1;
 for(const b of bases){const dir=b.cx<GW/2?-1:1;
  const put=(dx,dy,arr,value)=>{const x=b.cx+dir*dx,y=b.cy+dy,i=y*GW+x;if(!inb(x,y)||routes[i]||tree[i]||stone[i])return false;arr[i]=value;return true;};
  for(let dx=10;dx<=15;dx++)for(let dy=-4;dy<=3;dy++)if(!put(dx,dy,tree,100))return false;
  for(let dx=9;dx<=12;dx++)for(let dy=6;dy<=8;dy++)if(!put(dx,dy*handed,stone,350))return false;
 }
 const seen=bfs(bases[0].cx,bases[0].cy);if(bases.some(b=>!seen[b.cy*GW+b.cx])||camps.some(c=>!seen[c.cy*GW+c.cx]))return false;
 const free=(x,y)=>{if(!inb(x,y))return false;const i=y*GW+x;return !tree[i]&&!stone[i]&&!decor[i]&&!nearBase(x,y,8)&&!nearCamp(x,y,4);};
 for(let k=0;k<18;k++){const x=RI(2,GW-3),y=RI(2,GH-3),h=rnd()<.5,L=RI(4,9);for(let j=0;j<L;j++){const xx=h?x+j:x,yy=h?y:y+j;if(free(xx,yy))decor[yy*GW+xx]=1;}}
 for(let k=0;k<16;k++){const x0=RI(2,GW-9),y0=RI(2,GH-7);for(let y=y0;y<y0+5;y+=2)for(let x=x0;x<x0+7;x+=2)if(free(x,y))decor[y*GW+x]=2;}
 for(let k=0;k<650;k++){const x=RI(0,GW-1),y=RI(0,GH-1);if(free(x,y))decor[y*GW+x]=3;}
 for(let k=0;k<50;k++){const x=RI(0,GW-1),y=RI(0,GH-1);if(free(x,y))decor[y*GW+x]=4;}
 for(let k=0;k<24;k++){const x=RI(2,GW-9),y=RI(2,GH-7);if(free(x+2,y+2)&&free(x+4,y+1))vines.push({x:x*CELL,y:y*CELL,w:RI(4,7)*CELL,h:RI(3,5)*CELL,a:R(-.15,.15)});}
 return true;}
function mkRoad(x0,y0,x1,y1){const pts=[[x0,y0]];const n=6;const nx=-(y1-y0),ny=x1-x0,L=hyp(nx,ny)||1;
 for(let k=1;k<n;k++){const t=k/n,o=Math.sin(t*Math.PI)*R(-1,1)*90;pts.push([x0+(x1-x0)*t+nx/L*o,y0+(y1-y0)*t+ny/L*o]);}pts.push([x1,y1]);return pts;}

// ===================== disegno del terreno (una volta sola) =====================
let terrC=null,miniT=null;const SPR={};
function renderTerrain(){
 terrC=mkCanvas(WW,WH);const g=terrC.getContext('2d');srand(G.seed+5);
 const bg=g.createLinearGradient(0,0,WW,WH);bg.addColorStop(0,'#a8b066');bg.addColorStop(.5,'#9fad5f');bg.addColorStop(1,'#b0ab63');g.fillStyle=bg;g.fillRect(0,0,WW,WH);
 g.fillStyle='rgb(70,92,35)';for(let k=0;k<50000;k++){g.globalAlpha=R(.08,.22);g.fillRect(R(0,WW),R(0,WH),R(1,3.5),R(.8,1.6));}
 g.fillStyle='rgb(230,220,150)';for(let k=0;k<40000;k++){g.globalAlpha=R(.06,.18);g.fillRect(R(0,WW),R(0,WH),R(1,3.5),R(.8,1.6));}
 g.globalAlpha=1;
 // vigneti
 for(const v of vines){g.save();g.translate(v.x+v.w/2,v.y+v.h/2);g.rotate(v.a);g.fillStyle='rgba(150,120,70,.35)';rr(g,-v.w/2,-v.h/2,v.w,v.h,6);g.fill();
  for(let y=-v.h/2+6;y<v.h/2;y+=10){g.strokeStyle='rgba(110,85,50,.45)';g.lineWidth=2;g.beginPath();g.moveTo(-v.w/2+4,y);g.lineTo(v.w/2-4,y);g.stroke();
   for(let x=-v.w/2+6;x<v.w/2-4;x+=7){ell(g,x,y-1.5,3,2.5);g.fillStyle=(Math.floor(x+y)%3)?'#5f7d34':'#4a6a2a';g.fill();}}g.restore();}
 // strade
 for(const pts of roads){g.lineCap='round';g.lineJoin='round';
  for(const [ww,c] of [[30,'rgba(110,90,50,.3)'],[24,'#c8b287'],[12,'#d8c59c']]){g.beginPath();g.moveTo(pts[0][0],pts[0][1]);
   for(let i=1;i<pts.length-1;i++){const mx=(pts[i][0]+pts[i+1][0])/2,my=(pts[i][1]+pts[i+1][1])/2;g.quadraticCurveTo(pts[i][0],pts[i][1],mx,my);}
   g.lineTo(pts.at(-1)[0],pts.at(-1)[1]);g.strokeStyle=c;g.lineWidth=ww;g.stroke();}}
 // sottobosco e terreno delle cave
 const blobS=mkCanvas(96,96),bg2=blobS.getContext('2d');const gr=bg2.createRadialGradient(48,48,0,48,48,48);gr.addColorStop(0,'rgba(45,62,25,.45)');gr.addColorStop(1,'rgba(45,62,25,0)');bg2.fillStyle=gr;bg2.fillRect(0,0,96,96);
 const blobR=mkCanvas(96,96),bg3=blobR.getContext('2d');const gr3=bg3.createRadialGradient(48,48,0,48,48,48);gr3.addColorStop(0,'rgba(150,145,130,.55)');gr3.addColorStop(1,'rgba(150,145,130,0)');bg3.fillStyle=gr3;bg3.fillRect(0,0,96,96);
 for(let i=0;i<NCELL;i++){if(tree[i]>0)g.drawImage(blobS,cX(i)-48,cY(i)-48);else if(stone[i]>0)g.drawImage(blobR,cX(i)-48,cY(i)-48);}
 // fiumi
 for(const rv of rivers){const pts=[];for(let y=-1;y<=GH;y++){const yy=clamp(y,0,GH-1);pts.push([rv.cs[yy]*CELL,(y+.5)*CELL,rv.ws[yy]*CELL]);}
  const pass=(extra,col)=>{g.strokeStyle=col;g.lineCap='round';for(let k=0;k<pts.length-1;k++){g.lineWidth=Math.max(3,pts[k][2]+pts[k+1][2]+extra);g.beginPath();g.moveTo(pts[k][0],pts[k][1]);g.lineTo(pts[k+1][0],pts[k+1][1]);g.stroke();}};
  pass(30,'#7d8a52');pass(16,'#a89a68');pass(2,'#4f86a6');pass(-26,'#5f98b8');
  g.strokeStyle='rgba(200,230,240,.3)';g.lineWidth=7;g.beginPath();pts.forEach((p,k)=>k?g.lineTo(p[0]-6,p[1]):g.moveTo(p[0]-6,p[1]));g.stroke();}
 for(const f of fords){const rx=f.w*CELL+30;const gr=g.createRadialGradient(f.x,f.y,10,f.x,f.y,Math.max(rx,90));
  gr.addColorStop(0,'rgba(200,188,140,.95)');gr.addColorStop(.65,'rgba(160,184,168,.75)');gr.addColorStop(1,'rgba(90,150,180,0)');g.fillStyle=gr;ell(g,f.x,f.y,rx,90);g.fill();
  for(let i=0;i<45;i++){const a=R(0,TAU),r=R(0,1);ell(g,f.x+Math.cos(a)*r*rx*.85,f.y+Math.sin(a)*r*80,R(2,5),R(1.5,3));g.fillStyle=rnd()<.5?'rgba(120,120,110,.8)':'rgba(175,170,155,.8)';g.fill();}
  g.strokeStyle='rgba(235,245,250,.45)';g.lineWidth=1.3;for(let i=0;i<14;i++){const x=f.x+R(-rx*.7,rx*.7),y=f.y+R(-70,70);g.beginPath();g.arc(x,y,R(6,14),Math.PI*1.1,Math.PI*1.9);g.stroke();}}
 // bordi scuri
 const edge=(x0,y0,x1,y1)=>{const e=g.createLinearGradient(x0,y0,x1,y1);e.addColorStop(0,'rgba(30,20,8,.55)');e.addColorStop(1,'rgba(30,20,8,0)');g.fillStyle=e;};
 edge(0,0,0,120);g.fillRect(0,0,WW,120);edge(0,WH,0,WH-120);g.fillRect(0,WH-120,WW,120);edge(0,0,120,0);g.fillRect(0,0,120,WH);edge(WW,0,WW-120,0);g.fillRect(WW-120,0,120,WH);
 // minimappa di base
 miniT=mkCanvas(300,200);const m=miniT.getContext('2d');m.drawImage(terrC,0,0,300,200);
 for(let i=0;i<NCELL;i++){if(tree[i]>0){m.fillStyle='#3a5424';m.fillRect((i%GW)*2,((i/GW)|0)*2,2,2);}else if(stone[i]>0){m.fillStyle='#b8b6ae';m.fillRect((i%GW)*2,((i/GW)|0)*2,2,2);}}
}

// ===================== sprite della natura =====================
function drawTree(g,x,y,s,h){
 ell(g,x+s*.7,y+1,s*1.25,s*.45);g.fillStyle='rgba(35,45,15,.35)';g.fill();
 g.fillStyle='#5a3f22';g.fillRect(x-1.8,y-s*.9,3.6,s*.9);
 const cy=y-s*1.25*h;
 for(const [dx,dy,r2] of [[-s*.45,s*.15,.75],[s*.45,s*.1,.72],[0,-s*.35,.85],[0,0,.9]]){
  const gr=g.createRadialGradient(x+dx-s*.3,cy+dy-s*.35,1,x+dx,cy+dy,s*r2);gr.addColorStop(0,'#a0b65c');gr.addColorStop(.6,'#5f7d34');gr.addColorStop(1,'#3a5222');
  ell(g,x+dx,cy+dy,s*r2,s*r2*.92);g.fillStyle=gr;g.fill();}}
function drawCyp(g,x,y,s){
 ell(g,x+s*2.2,y-1,s*2.6,s*.5,.15);g.fillStyle='rgba(30,40,15,.35)';g.fill();
 const gr=g.createLinearGradient(x-s,0,x+s,0);gr.addColorStop(0,'#476a37');gr.addColorStop(.5,'#2c4a26');gr.addColorStop(1,'#1a3019');
 g.beginPath();g.moveTo(x,y-s*5.2);g.bezierCurveTo(x+s*1.05,y-s*3.2,x+s,y-s*.8,x+s*.3,y);g.lineTo(x-s*.3,y);g.bezierCurveTo(x-s,y-s*.8,x-s*1.05,y-s*3.2,x,y-s*5.2);g.fillStyle=gr;g.fill();
 g.strokeStyle='rgba(150,180,100,.25)';g.lineWidth=.8;for(let i=1;i<5;i++){g.beginPath();g.moveTo(x-s*.5,y-s*i);g.quadraticCurveTo(x-s*.2,y-s*i-2,x,y-s*i-.5);g.stroke();}}
function drawOlive(g,x,y,s){ell(g,x+s*.6,y+1,s,s*.35);g.fillStyle='rgba(35,45,15,.3)';g.fill();g.strokeStyle='#6a5236';g.lineWidth=2;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x-2,y-s*.5,x+1,y-s*.9);g.stroke();
 for(const [dx,dy,r] of [[-s*.4,-s*1.05,.55],[s*.4,-s*1.1,.5],[0,-s*1.35,.55]]){const gr=g.createRadialGradient(x+dx-2,y+dy-3,1,x+dx,y+dy,s*r);gr.addColorStop(0,'#c2c9a0');gr.addColorStop(1,'#6f7d55');ell(g,x+dx,y+dy,s*r,s*r*.85);g.fillStyle=gr;g.fill();}}
function drawBush(g,x,y,s){ell(g,x+2,y,s*1.1,s*.4);g.fillStyle='rgba(35,45,15,.3)';g.fill();for(const [dx,dy] of [[-s*.4,-s*.4],[s*.35,-s*.35],[0,-s*.7]]){ell(g,x+dx,y+dy,s*.55,s*.48);g.fillStyle='#55743a';g.fill();}
 ell(g,x-s*.15,y-s*.8,s*.25,s*.2);g.fillStyle='#83a055';g.fill();}
function drawHay(g,x,y,s){ell(g,x+3,y,s*1.2,s*.4);g.fillStyle='rgba(35,45,15,.3)';g.fill();const gr=g.createRadialGradient(x-s*.3,y-s*.9,1,x,y-s*.5,s);gr.addColorStop(0,'#f3dc8a');gr.addColorStop(1,'#b8913a');
 g.beginPath();g.moveTo(x-s,y);g.quadraticCurveTo(x-s,y-s*1.4,x,y-s*1.5);g.quadraticCurveTo(x+s,y-s*1.4,x+s,y);g.closePath();g.fillStyle=gr;g.fill();}
function drawRockArt(g,x,y,s,seed){let sd=seed;const r=()=>{sd=(sd*16807)%2147483647;return sd/2147483647;};
 ell(g,x+s*.4,y+1,s*1.15,s*.4);g.fillStyle='rgba(40,40,30,.3)';g.fill();const pts=[];
 for(let i=0;i<7;i++){const a=i/7*TAU;pts.push([x+Math.cos(a)*s*(.75+r()*.35),y-s*.45+Math.sin(a)*s*.55*(.75+r()*.35)]);}
 g.beginPath();pts.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.closePath();g.fillStyle='#9d9b93';g.fill();
 g.beginPath();g.moveTo(pts[3][0],pts[3][1]);for(const i of [4,5,6])g.lineTo(pts[i][0],pts[i][1]);g.lineTo(x,y-s*.5);g.closePath();g.fillStyle='#cfcdc3';g.fill();
 g.strokeStyle='rgba(60,60,50,.6)';g.lineWidth=.8;g.beginPath();pts.forEach((p,i)=>i?g.lineTo(p[0],p[1]):g.moveTo(p[0],p[1]));g.closePath();g.stroke();}
function bakeNature(){const S=2;const mk=(w,h,fn)=>{const c=mkCanvas(w*S,h*S),g=c.getContext('2d');g.scale(S,S);fn(g);return c;};
 SPR.tree=[];for(let v=0;v<6;v++){srand(100+v);const s=R(14,17.5),h=R(.9,1.15);SPR.tree.push(mk(64,72,g=>drawTree(g,26,64,s,h)));}
 SPR.cyp=[0,1].map(v=>mk(44,56,g=>drawCyp(g,14,50,5.8+v*.6)));
 SPR.olive=[0,1].map(v=>mk(44,44,g=>drawOlive(g,18,38,10+v*1.5)));
 SPR.bush=[0,1].map(v=>mk(32,28,g=>drawBush(g,14,22,7+v*1.5)));
 SPR.hay=[mk(36,32,g=>drawHay(g,15,26,9))];
 SPR.rock=[0,1,2,3].map(v=>mk(48,36,g=>{drawRockArt(g,22,30,11+v,77+v*31);drawRockArt(g,12,32,6,13+v);drawRockArt(g,33,33,5,51+v);}));
}

// ===================== percorsi =====================
class Heap{constructor(n){this.k=new Int32Array(n);this.v=new Float32Array(n);this.n=0;}
 push(k,v){let i=this.n++;const K=this.k,V=this.v;while(i>0){const p=(i-1)>>1;if(V[p]<=v)break;K[i]=K[p];V[i]=V[p];i=p;}K[i]=k;V[i]=v;}
 pop(){const K=this.k,V=this.v,top=K[0],n=--this.n;if(n>0){const k=K[n],v=V[n];let i=0;for(;;){let l=2*i+1;if(l>=n)break;const r=l+1;if(r<n&&V[r]<V[l])l=r;if(V[l]>=v)break;K[i]=K[l];V[i]=V[l];i=l;}K[i]=k;V[i]=v;}return top;}
 topV(){return this.v[0];}}
let HEAP=new Heap(NCELL*9);
const fieldCache=new Map();
function computeField(team,goal){const c=new Float32Array(NCELL);for(let i=0;i<NCELL;i++)c[i]=cellCost(team,i);
 const d=new Float32Array(NCELL).fill(Infinity);const h=HEAP;h.n=0;d[goal]=0;h.push(goal,0);
 while(h.n){const v=h.topV(),cur=h.pop();if(v>d[cur])continue;const cc=cur===goal?1:c[cur];const x=cur%GW,y=(cur/GW)|0;
  for(let k=0;k<8;k++){const nx=x+DX[k],ny=y+DY[k];if(nx<0||ny<0||nx>=GW||ny>=GH)continue;const n=ny*GW+nx;if(c[n]===Infinity)continue;
   if(k>=4&&(c[y*GW+nx]===Infinity||c[ny*GW+x]===Infinity))continue;const nd=v+DC[k]*cc;if(nd<d[n]){d[n]=nd;h.push(n,nd);}}}
 return {d,c,ver:gridVer};}
function getField(team,goal){const key=team*NCELL+goal;let f=fieldCache.get(key);if(f&&f.ver===gridVer)return f;
 f=computeField(team,goal);fieldCache.delete(key);fieldCache.set(key,f);if(fieldCache.size>48)fieldCache.delete(fieldCache.keys().next().value);return f;}
let AG=new Float32Array(NCELL),AF=new Int32Array(NCELL),AS=new Uint32Array(NCELL),ACL=new Uint32Array(NCELL);let AST=1;
function astar(team,s,g,maxIt){maxIt=Math.max(1,maxIt||5000);ASTAR_OK=false;ASTAR_STATUS='blocked';if(s<0||s>=NCELL||g<0||g>=NCELL)return null;
 if(s===g){ASTAR_OK=true;ASTAR_STATUS='reached';return [];}if(!passFor(team,g))return null;AST++;
 const gx=g%GW,gy=(g/GW)|0;const H=i=>{const dx=Math.abs(i%GW-gx),dy=Math.abs(((i/GW)|0)-gy);return dx+dy-.5858*Math.min(dx,dy);};
 const h=HEAP;h.n=0;AS[s]=AST;AG[s]=0;AF[s]=-1;h.push(s,H(s));let best=s,bh=H(s),it=0;
 while(h.n&&it<maxIt){const cur=h.pop();if(ACL[cur]===AST)continue;it++;ACL[cur]=AST;if(cur===g){best=g;break;}const hc=H(cur);if(hc<bh){bh=hc;best=cur;}
  const x=cur%GW,y=(cur/GW)|0;for(let k=0;k<8;k++){const nx=x+DX[k],ny=y+DY[k];if(nx<0||ny<0||nx>=GW||ny>=GH)continue;const n=ny*GW+nx;
   if(ACL[n]===AST||!passFor(team,n))continue;if(k>=4&&(!passFor(team,y*GW+nx)||!passFor(team,ny*GW+x)))continue;
   const ng=AG[cur]+DC[k]*(water[n]===2?1.6:1);if(AS[n]!==AST||ng<AG[n]){AS[n]=AST;AG[n]=ng;AF[n]=cur;h.push(n,ng+H(n));}}}
 ASTAR_OK=best===g;ASTAR_STATUS=ASTAR_OK?'reached':h.n?'budget':'exhausted';const path=[];let c=best,guard=0;while(c!==s&&c>=0&&guard++<NCELL){path.push(c);c=AF[c];}path.reverse();return path;}
let ASTAR_OK=true,ASTAR_STATUS='reached';
function los(team,x0,y0,x1,y1,ign){const d=hyp(x1-x0,y1-y0),n=Math.ceil(d/12);
 for(let k=1;k<=n;k++){const i=cellI(x0+(x1-x0)*k/n,y0+(y1-y0)*k/n);if(!passFor(team,i)){if(ign&&bAt[i]===ign)continue;return false;}}return true;}
function nearestPass(team,i){if(passFor(team,i))return i;const x=i%GW,y=(i/GW)|0;
 for(let r=1;r<14;r++){let best=-1,bd=1e9;for(let yy=y-r;yy<=y+r;yy++)for(let xx=x-r;xx<=x+r;xx++){if(Math.max(Math.abs(xx-x),Math.abs(yy-y))!==r||!inb(xx,yy))continue;
   const n=yy*GW+xx;if(passFor(team,n)){const d=(xx-x)**2+(yy-y)**2;if(d<bd){bd=d;best=n;}}}if(best>=0)return best;}return -1;}
function adjFree(team,b,fx,fy){let best=-1,bd=1e9;
 for(let y=b.cy-1;y<=b.cy+b.h;y++)for(let x=b.cx-1;x<=b.cx+b.w;x++){if(x>=b.cx&&x<b.cx+b.w&&y>=b.cy&&y<b.cy+b.h)continue;if(!inb(x,y))continue;
  const n=y*GW+x;if(!passFor(team,n))continue;const d=hyp(cX(n)-fx,cY(n)-fy);if(d<bd){bd=d;best=n;}}return best;}
function adjFreeCell(team,i,fx,fy){const x=i%GW,y=(i/GW)|0;let best=-1,bd=1e9;
 for(let k=0;k<8;k++){const nx=x+DX[k],ny=y+DY[k];if(!inb(nx,ny))continue;const n=ny*GW+nx;if(!passFor(team,n))continue;const d=hyp(cX(n)-fx,cY(n)-fy)+(k>=4?6:0);if(d<bd){bd=d;best=n;}}return best;}
