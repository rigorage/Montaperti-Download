'use strict';
// ===================== potenziamenti =====================
const RANK={C:0,R:1,E:2},RW={C:60,R:27,E:13},RN={C:'Comune',R:'Raro',E:'Epico'};
const RC={C:['#8d8d86','transparent'],R:['#3b82d6','transparent'],E:['#9b5cff','transparent']};
const TAGS=['ECONOMIA','FANTI','BALESTRE','CAVALLI','ASSEDIO','ESERCITO'];
const MAST_TXT={ECONOMIA:'+1 risorsa per consegna o carico di grano al Campo',FANTI:'+1 danno normale della fanteria',BALESTRE:'+1 danno del dardo principale',CAVALLI:'+15 vita della cavalleria',ASSEDIO:'+10 danni agli edifici delle macchine',ESERCITO:'+10 vita di tutte le unità'};
const UPS=[
 // ECONOMIA
 {id:'aratri',n:'Aratri Pesanti',r:'C',tag:'ECONOMIA',max:5,d:"Ogni carico di grano raccolto al Campo aggiunge +1 grano.",a:(m,T,t)=>{m.delivery.g+=1;}},
 {id:'asce',n:'Asce Affilate',r:'C',tag:'ECONOMIA',max:5,d:"Ogni consegna di legname aggiunge +2 legname.",a:(m,T,t)=>{m.delivery.l+=2;}},
 {id:'picconi',n:'Picconi Temprati',r:'C',tag:'ECONOMIA',max:5,d:"Ogni consegna di pietra aggiunge +1 pietra.",a:(m,T,t)=>{m.delivery.p+=1;}},
 {id:'dote',n:'Dote del Comune',r:'C',tag:'ECONOMIA',max:3,d:'Subito +150 grano e +120 legname.',a:(m,T)=>{T.res.g+=150;T.res.l+=120;}},
 {id:'famiglie',n:'Famiglie Numerose',r:'R',tag:'ECONOMIA',max:2,d:"Arrivano +3 contadini; limite contadini +5. Attendono al Palazzo se manca popolazione.",a:(m,T,t)=>{m.wCap+=5;queueReinforcement(t,"worker",3);}},
 {id:'pievi',n:'Nuove Pievi',r:'R',tag:'ECONOMIA',max:2,d:"Limite contadini +8; arrivano +2 contadini. Attendono al Palazzo se manca popolazione.",a:(m,T,t)=>{m.wCap+=8;queueReinforcement(t,"worker",2);}},
 {id:'mulino',n:'Mulino ad Acqua',r:'R',tag:'ECONOMIA',max:1,d:"Ogni Campo ospita +1 contadino; ogni 6 carichi di grano raccolti al Campo ricevi +15 grano.",a:(m,T,t)=>{m.farmCap+=1;}},
 {id:'segheria',n:'Segheria',r:'R',tag:'ECONOMIA',max:2,d:"Ogni albero esaurito dai tuoi contadini consegna +8 legname. Vale anche dopo la ricrescita.",a:(m,T,t)=>{;}},
 {id:'scalpellini',n:'Scalpellini',r:'C',tag:'ECONOMIA',max:3,d:"Ogni consegna di pietra aggiunge +2 pietra. Torri, mura e porte costano 5 risorse in meno per tipo, minimo 1.",a:(m,T,t)=>{m.delivery.p+=2;m.flatDefCost+=5;}},
 {id:'sentieri',n:'Sentieri Battuti',r:'C',tag:'ECONOMIA',max:3,d:"Contadini: +5 velocità, fino al limite di 95.",a:(m,T,t)=>{m.flatSpd.worker+=5;}},
 {id:'gerle',n:'Gerle Capienti',r:'R',tag:'ECONOMIA',max:3,d:'I contadini portano +4 risorse a ogni viaggio.',a:m=>{m.carry+=4}},
 {id:'schiera',n:'Case a Schiera',r:'C',tag:'ECONOMIA',max:5,d:'+15 popolazione massima.',a:m=>{m.pop+=15}},
 {id:'comacini',n:'Maestri Comacini',r:'C',tag:'ECONOMIA',max:1,d:"Ogni 3 edifici pagati completati arriva +1 contadino. Mura e porte escluse; attende se manca spazio.",a:(m,T,t)=>{;}},
 {id:'reclut',n:'Reclutatori',r:'R',tag:'ECONOMIA',max:1,d:"Ogni 6 soldati pagati addestrati arriva +1 dello stesso tipo dell’ultimo. Esclusi contadini, supporti, macchine ed eroi; attende se manca spazio.",a:(m,T,t)=>{;}},
 {id:'calimala',n:'Arte di Calimala',r:'R',tag:'ECONOMIA',max:3,d:"Unità ed edifici costano 3 risorse in meno per tipo, minimo 1 dopo gli altri sconti.",a:(m,T,t)=>{m.flatCost+=3;}},
 {id:'fiera',n:'Fiera di Mercato',r:'R',tag:'ECONOMIA',max:3,d:'Ogni 30 s: +1 di ogni risorsa per ogni contadino che hai.',a:m=>{m.fair+=1}},
 {id:'bardi',n:'Banco dei Bardi',r:'E',tag:'ECONOMIA',max:2,d:"Ogni 30 secondi il Palazzo consegna +20 grano e +15 legname.",a:(m,T,t)=>{;}},
 {id:'contado',n:'Contado Fertile',r:'R',tag:'ECONOMIA',max:3,d:"Ogni 50 secondi arriva +1 contadino al Palazzo per livello. Attende se manca popolazione o spazio tra i contadini.",a:(m,T,t)=>{m.freeW+=1;}},
 // FANTI
 {id:'pavesi',n:'Pavesi Rinforzati',r:'C',tag:'FANTI',max:5,d:"Fanteria: +15 vita.",a:(m,T,t)=>{m.flatHp.inf+=15;}},
 {id:'lance',n:'Lance Lunghe',r:'C',tag:'FANTI',max:5,d:"Fanteria: +1 danno per attacco normale.",a:(m,T,t)=>{m.flatDmg.inf+=1;}},
 {id:'corazzine',n:'Corazzine',r:'C',tag:'FANTI',max:4,d:'Fanteria: +1 armatura in mischia, comprese le unità speciali.',a:m=>{m.aM.inf+=1}},
 {id:'picche',n:'Picche Ferrate',r:'R',tag:'FANTI',max:3,d:"Fanteria: +3 danni per attacco normale contro la cavalleria.",a:(m,T,t)=>{m.flatVsCav+=3;}},
 {id:'testuggine',n:'Testuggine',r:'R',tag:'FANTI',max:3,d:'Fanteria: +2 armatura contro i dardi, comprese le unità speciali.',a:m=>{m.aR.inf+=2}},
 {id:'veterani',n:'Fanti Veterani',r:'E',tag:'FANTI',max:2,d:'La fanteria, comprese le unità speciali, rigenera 1 vita/s dopo 3 s senza subire danni.',a:m=>{m.regen.inf+=1}},
 {id:'muro',n:'Muro di Pavesi',r:'E',tag:'FANTI',max:1,d:"La fanteria ferma assorbe 3 danni aggiuntivi da ogni colpo, dopo l’armatura; minimo 1 danno.",a:(m,T,t)=>{m.flatShield+=3;}},
 {id:'milizia',n:'Milizia del Popolo',r:'E',tag:'FANTI',max:3,d:"Ogni 60 secondi arrivano +2 Pavesari al Palazzo. I rinforzi attendono se manca popolazione.",a:(m,T,t)=>{m.levy+=2;}},
 // BALESTRE
 {id:'corde',n:'Corde di Canapa',r:'C',tag:'BALESTRE',max:5,d:"Balestrieri: +2 danni per dardo principale.",a:(m,T,t)=>{m.flatDmg.xb+=2;}},
 {id:'mire',n:'Mire Graduate',r:'C',tag:'BALESTRE',max:4,d:"Balestrieri: +1 casella di gittata.",a:(m,T,t)=>{m.flatRange.xb+=32;}},
 {id:'pavxb',n:'Scorta dei Tiratori',r:'R',tag:'BALESTRE',max:1,d:'Ogni 5 balestrieri pagati addestrati arriva +1 Pavesaro al Palazzo. Attende se manca popolazione.',a:()=>{}},
 {id:'martinetti',n:'Martinetti a Leva',r:'R',tag:'BALESTRE',max:1,d:"Ogni 5 balestrieri pagati addestrati arriva +1 balestriere dello stesso tipo dell’ultimo. Attende se manca spazio.",a:(m,T,t)=>{;}},
 {id:'falco',n:'Dardo di Riserva',r:'R',tag:'BALESTRE',max:1,d:"Ogni quarto tiro normale aggiunge +1 dardo di danno base contro lo stesso bersaglio. Nessun effetto o conteggio dal dardo extra.",a:(m,T,t)=>{;}},
 {id:'perforanti',n:'Dardi Perforanti',r:'E',tag:'BALESTRE',max:2,d:"Il dardo principale raggiunge +1 nemico vicino al bersaglio, per livello, con 8 danni. Nessuna catena dai dardi extra.",a:(m,T,t)=>{m.pierce+=1;}},
 {id:'incendiari',n:'Dardi Incendiari',r:'E',tag:'BALESTRE',max:2,d:'I dardi principali incendiano: 4 danni al secondo per 3 s per livello. I dardi extra non applicano incendi.',a:m=>{m.fire+=4}},
 {id:'genovesi',n:'Balestrieri Genovesi',r:'E',tag:'BALESTRE',max:1,minT:420,d:"Balestrieri: +3 danni al dardo principale, +1 casella di gittata e costo ridotto di 8 risorse per tipo, minimo 1.",a:(m,T,t)=>{m.flatDmg.xb+=3;m.flatRange.xb+=32;m.flatXbCost+=8;}},
 // CAVALLI
 {id:'ferri',n:'Selle Rinforzate',r:'C',tag:'CAVALLI',max:3,d:'Cavalleria: +1 armatura contro i dardi.',a:m=>{m.aR.cav+=1}},
 {id:'bardature',n:'Bardature',r:'C',tag:'CAVALLI',max:5,d:"Cavalleria: +25 vita.",a:(m,T,t)=>{m.flatHp.cav+=25;}},
 {id:'sproni',n:'Sproni d\'Oro',r:'C',tag:'CAVALLI',max:5,d:"Cavalleria: +2 danni per attacco normale.",a:(m,T,t)=>{m.flatDmg.cav+=2;}},
 {id:'carica',n:'Carica',r:'R',tag:'CAVALLI',max:3,d:"Il primo attacco contro una unità dopo almeno 1,2 secondi di corsa infligge +12 danni. Nessun bonus contro edifici. Richiede una nuova corsa.",a:(m,T,t)=>{m.flatCharge+=12;}},
 {id:'caccia',n:'Caccia ai Balestrieri',r:'R',tag:'CAVALLI',max:2,d:"Cavalleria: +5 danni per attacco normale contro i balestrieri.",a:(m,T,t)=>{m.flatVsXb+=5;}},
 {id:'ventura',n:'Compagnia di Ventura',r:'E',tag:'CAVALLI',max:1,minT:420,d:"Arrivano +12 Feditori al Palazzo. I rinforzi attendono se manca popolazione.",a:(m,T,t)=>{queueReinforcement(t,"cav",12);}},
 // ASSEDIO
 {id:'contrappesi',n:'Contrappesi',r:'C',tag:'ASSEDIO',max:4,d:"Macchine d’assedio: +25 danni contro gli edifici.",a:(m,T,t)=>{m.flatSiege+=25;}},
 {id:'arsenale',n:'Arsenale',r:'R',tag:'ASSEDIO',max:3,d:'+1 al numero massimo di macchine d’assedio, compresi i Mangani.',a:m=>{m.siegeMax+=1}},
 {id:'merlate',n:'Tiro Incrociato delle Torri',r:'R',tag:'ASSEDIO',max:1,d:'Ogni torre tira +1 dardo contro un secondo nemico in gittata. Non aggiunge colpi contro un bersaglio isolato e non modifica il Palazzo.',a:m=>{m.towerCross=1;}},
 {id:'feritoie',n:'Feritoie',r:'R',tag:'ASSEDIO',max:3,d:'Torri e Palazzo tirano un dardo in più a ogni colpo.',a:m=>{m.arrows+=1}},
 {id:'spesse',n:'Guarnigione di Emergenza',r:'R',tag:'ASSEDIO',max:1,d:'Una torre completata che subisce danni richiama 2 Pavesari e 1 Balestriere per 20 secondi. Richiede 3 posti liberi e spazio; ricarica condivisa di 90 s, una guarnigione per giocatore. Nessun premio dalle unità temporanee.',a:()=>{}},
 {id:'ciclopiche',n:'Mura Ciclopiche',r:'E',tag:'ASSEDIO',max:1,minT:420,d:"Mura, porte e torri: +400 vita. Le torri riducono la ricarica di 0,7 secondi, minimo 0,3 secondi.",a:(m,T,t)=>{m.flatWall+=400;m.towerReload+=.7;}},
 // ESERCITO
 {id:'disciplina',n:'Reparti Abbinati',r:'R',tag:'ESERCITO',max:1,d:'Ogni 6 fanti pagati addestrati arriva +1 Balestriere al Palazzo. I rinforzi attendono se manca popolazione.',a:()=>{}},
 {id:'cuoio',n:'Leva Cittadina',r:'C',tag:'ESERCITO',max:3,d:'Arrivano subito +3 Pavesari e +1 Balestriere al Palazzo per scelta. I rinforzi attendono se manca popolazione.',a:(m,T,t)=>{queueReinforcement(t,'inf',3);queueReinforcement(t,'xb',1);}},
 {id:'forzata',n:'Marcia Forzata',r:'R',tag:'ESERCITO',max:3,d:"Unità: +4 velocità, cavalleria esclusa. Nessuna supera 95.",a:(m,T,t)=>{m.flatSpd.all+=4;}},
 {id:'benedette',n:'Addestramento Serrato',r:'R',tag:'ESERCITO',max:3,d:"Fanteria e cavalleria riducono la ricarica di 0,1 secondi per attacco, minimo 0,3 secondi.",a:(m,T,t)=>{m.flatRate.inf+=.1;m.flatRate.cav+=.1;}},
 {id:'cantastorie',n:'Cantastorie',r:'R',tag:'ESERCITO',max:3,d:"Ogni premio di Gloria aumenta di +1 punto.",a:(m,T,t)=>{m.flatGlory+=1;}},
 {id:'medici',n:'Medici da Campo',r:'E',tag:'ESERCITO',max:2,d:'Tutte le unità rigenerano 0,6 vita al secondo fuori dal combattimento.',a:m=>{m.regen.all+=.6}},
 {id:'martinella',n:'Riserve di Battaglia',r:'E',tag:'ESERCITO',max:1,minT:420,d:'Ogni 6 fanti, balestrieri o cavalieri pagati persi in combattimento arrivano +2 Pavesari al Palazzo. Almeno 45 s fra i premi; durante la ricarica si conserva al massimo un premio. Esclusi soldati gratuiti e temporanei.',a:()=>{}},
 {id:'fortuna',n:'Fortuna di Montaperti',r:'E',tag:'ESERCITO',max:1,minT:300,d:"Ottieni +3 rimescolamenti e +1 punto per ogni premio di Gloria. Le offerte restano di tre carte.",a:(m,T,t)=>{T.rerolls+=3;m.flatGlory+=1;}},
 {id:'carpentieri',n:'Scorta dell’Assedio',r:'R',tag:'ASSEDIO',max:1,d:'Ogni macchina d’assedio pagata completata fornisce +2 Pavesari al Palazzo. I rinforzi attendono se manca popolazione; nessun premio da macchine gratuite.',a:()=>{}},
 {id:'riserve',n:'Riserve della Milizia',r:'R',tag:'FANTI',max:1,d:'Ogni 8 soldati nemici eliminati arrivano +2 Pavesari. Contadini e temporanei esclusi; attendono se manca spazio.',a:()=>{}},
// PERSONALI, PREPARATIVI E RISERVE
 {"id":"compagnie_popolo","fac":0,"n":"Compagnie del Popolo","r":null,"tag":"FANTI","max":1,"d":"Ogni 6 fanti pagati addestrati arrivano +1 Pavesaro e +1 Balestriere al Palazzo. I rinforzi attendono se manca spazio.",a:(m,T,t)=>{m.card.compagnie_popolo=1;}},
 {"id":"botteghe_balestrai","fac":0,"n":"Tiro di Compagnia","r":null,"tag":"BALESTRE","max":1,"d":"Ogni terzo tiro normale aggiunge +1 dardo da 6 danni verso un secondo nemico in gittata.",a:(m,T,t)=>{m.card.botteghe_balestrai=1;}},
 {"id":"mezzadria","fac":0,"n":"Lame della Milizia","r":null,"tag":"FANTI","max":1,"d":"Ogni terzo attacco normale di un fante prepara +1 fendente da 6 danni sullo stesso bersaglio, se resta a portata.","behavior":"doubleHit",a:(m,T,t)=>{m.card.mezzadria=1;m.doubleHit|=1;}},
 {"id":"logge_mercanti","fac":0,"n":"Schiera del Popolo","r":null,"tag":"FANTI","max":1,"d":"Un fante entro 2 caselle da un tuo tiratore assorbe 3 danni di ogni dardo destinato al protetto. Riceve quei danni al suo posto; una sola scorta per colpo.","behavior":"bodyguard",a:(m,T,t)=>{m.card.logge_mercanti=1;m.bodyguard=3;}},
 {"id":"gonfalone","fac":0,"n":"Ospedale del Gonfalone","r":null,"tag":"ESERCITO","max":1,"d":"Il Carroccio cura di 2 vita al secondo fino a 4 tuoi soldati entro 3 caselle che non subiscono danni da 3 secondi. Non cura se stesso.","behavior":"medicAura",a:(m,T,t)=>{m.card.gonfalone=1;m.medicAura|=32;}},
 {"id":"fiorino","fac":0,"n":"Staffette del Gonfalone","r":null,"tag":"CAVALLI","max":1,"d":"Ogni 4 cavalieri pagati addestrati arriva +1 Feditore. Consente di affiancare un reparto mobile alla fanteria. I rinforzi attendono se manca spazio.",a:(m,T,t)=>{m.card.fiorino=1;}},
 {"id":"contrade","fac":1,"n":"Seguito di Manfredi","r":null,"tag":"CAVALLI","max":1,"d":"Ogni 3 Cavalieri Tedeschi pagati addestrati arriva +1 Cavaliere Tedesco. I rinforzi attendono se manca spazio.",a:(m,T,t)=>{m.card.contrade=1;}},
 {"id":"manfredi","fac":1,"n":"Carica degli Svevi","r":null,"tag":"CAVALLI","max":1,"d":"Il primo colpo dopo almeno 1,2 secondi di corsa raggiunge anche fino a 2 soldati vicini al bersaglio, per 10 danni ciascuno. Per ripeterlo serve una nuova corsa.","behavior":"cavalryTrample",a:(m,T,t)=>{m.card.manfredi=1;m.cavalryTrample=10;}},
 {"id":"comunita_contado","fac":1,"n":"Veterani delle Contrade","r":null,"tag":"CAVALLI","max":1,"d":"Ogni terzo attacco normale a segno di un cavaliere gli restituisce 4 vita. Non funziona contro gli edifici.",a:(m,T,t)=>{m.card.comunita_contado=1;}},
 {"id":"guardia_balzana","fac":1,"n":"Picche della Balzana","r":null,"tag":"FANTI","max":1,"d":"Dopo 1,2 secondi ferma, la fanteria annulla il bonus del colpo di carica che riceve e risponde con un contrattacco da 10 danni. Al massimo uno ogni 2 secondi; muoversi annulla la preparazione.","behavior":"brace",a:(m,T,t)=>{m.card.guardia_balzana=1;m.brace=10;}},
 {"id":"ingegneri_ghibellini","fac":1,"n":"Dardi Ghibellini","r":null,"tag":"BALESTRE","max":1,"d":"Il dardo principale raggiunge +1 nemico allineato dietro al bersaglio, entro 3 caselle, per 8 danni.","behavior":"pierceLine",a:(m,T,t)=>{m.card.ingegneri_ghibellini=1;m.pierceLine=8;}},
 {"id":"montieri","fac":1,"n":"Armi delle Contrade","r":null,"tag":"FANTI","max":1,"d":"Ogni 6 fanti pagati addestrati arrivano +1 Pavesaro e +1 Balestriere: una strada alternativa alla cavalleria pesante. I rinforzi attendono se manca spazio.",a:(m,T,t)=>{m.card.montieri=1;}},
 {"id":"granai_regno","fac":3,"n":"Seguito dei Baroni","r":null,"tag":"FANTI","max":1,"d":"Ogni Cavaliere Angioino pagato addestrato è accompagnato da +1 Pavesaro gratuito. I rinforzi attendono se manca spazio.",a:(m,T,t)=>{m.card.granai_regno=1;}},
 {"id":"scuderie_reali","fac":3,"n":"Fendente Angioino","r":null,"tag":"CAVALLI","max":1,"d":"Ogni terzo attacco normale della cavalleria raggiunge fino a 2 nemici aggiuntivi davanti al cavaliere, per 8 danni ciascuno.","behavior":"cleave",a:(m,T,t)=>{m.card.scuderie_reali=1;m.cleave|=4;}},
 {"id":"fedelta_baroni","fac":3,"n":"Cavalieri del Re","r":null,"tag":"CAVALLI","max":1,"d":"Ogni terzo attacco normale della cavalleria prepara +1 affondo da 10 danni sullo stesso bersaglio, se resta a portata.","behavior":"doubleHit",a:(m,T,t)=>{m.card.fedelta_baroni=1;m.doubleHit|=4;}},
 {"id":"fondachi_porto","fac":3,"n":"Balestrieri del Porto","r":null,"tag":"BALESTRE","max":1,"d":"Ogni quarto tiro normale contro la cavalleria aggiunge +1 dardo da 12 danni sullo stesso bersaglio.",a:(m,T,t)=>{m.card.fondachi_porto=1;}},
 {"id":"bottino_guerra","fac":3,"n":"Scorta dei Baroni","r":null,"tag":"CAVALLI","max":1,"d":"Ogni 4 fanti pagati addestrati arriva +1 Feditore: anche un esercito di fanteria ottiene una scorta a cavallo. I rinforzi attendono se manca spazio.",a:(m,T,t)=>{m.card.bottino_guerra=1;}},
 {"id":"genieri_angioini","fac":3,"n":"Bottino di Campagna","r":null,"tag":"FANTI","max":1,"d":"Ogni soldato nemico eliminato dalla tua cavalleria consegna +4 grano e +3 legname. Contadini e unità temporanee esclusi.",a:(m,T,t)=>{m.card.genieri_angioini=1;}},
 {"id":"armaioli_picche","fac":4,"n":"Picche della Lega","r":null,"tag":"FANTI","max":1,"d":"Dopo 1,2 secondi fermi, i Picchieri Lombardi annullano il bonus del colpo di carica che ricevono e rispondono con un colpo da 14 danni. Massimo uno ogni 2 secondi; muoversi annulla la preparazione.","behavior":"brace",a:(m,T,t)=>{m.card.armaioli_picche=1;m.brace=14;}},
 {"id":"carri_lombardi","fac":4,"n":"Lame Lombarde","r":null,"tag":"FANTI","max":1,"d":"Ogni terzo attacco normale della fanteria raggiunge fino a 2 nemici aggiuntivi davanti al soldato, per 6 danni ciascuno.","behavior":"cleave",a:(m,T,t)=>{m.card.carri_lombardi=1;m.cleave|=1;}},
 {"id":"maestri_citta","fac":4,"n":"Seconda fila","r":null,"tag":"FANTI","max":1,"d":"I Picchieri Lombardi ottengono +1 casella di portata in mischia: possono colpire da dietro un compagno. Muri ed edifici bloccano comunque il colpo.",a:(m,T,t)=>{m.card.maestri_citta=1;}},
 {"id":"compagnie_balestriere","fac":4,"n":"Scudi delle Compagnie","r":null,"tag":"FANTI","max":1,"d":"Un fante entro 2 caselle da una tua macchina d’assedio assorbe 4 danni di ogni dardo destinato alla macchina. Riceve quei danni al suo posto; una sola scorta per colpo.","behavior":"bodyguard",a:(m,T,t)=>{m.card.compagnie_balestriere=1;m.bodyguard=4;}},
 {"id":"milizie_lega","fac":4,"n":"Milizie della Lega","r":null,"tag":"FANTI","max":1,"d":"Ogni 5 fanti pagati addestrati arriva +1 Picchiere Lombardo. I rinforzi attendono se manca spazio.",a:(m,T,t)=>{m.card.milizie_lega=1;}},
 {"id":"arsenale_lombardo","fac":4,"n":"Balestrieri della Lega","r":null,"tag":"FANTI","max":1,"d":"Ogni 4 Picchieri Lombardi pagati addestrati arriva +1 Balestriere. La prima linea prepara anche il proprio sostegno a distanza. I rinforzi attendono se manca spazio.",a:(m,T,t)=>{m.card.arsenale_lombardo=1;}},
 {"id":"tiro_torri","fac":5,"n":"Batteria della Torre","r":null,"tag":"BALESTRE","max":1,"d":"Dopo 4 secondi fermi, i balestrieri aggiungono +2 dardi da 6 danni alla prossima salva, poi ricominciano a prepararsi. Muoversi azzera la preparazione.","behavior":"xbDeploy",a:(m,T,t)=>{m.card.tiro_torri=1;m.xbDeploy=6;}},
 {"id":"scorte_assedio","fac":5,"n":"Dardi della Cerchia","r":null,"tag":"BALESTRE","max":1,"d":"Il dardo principale colpisce +1 nemico allineato dietro al bersaglio, entro 3 caselle, per 8 danni.","behavior":"pierceLine",a:(m,T,t)=>{m.card.scorte_assedio=1;m.pierceLine=8;}},
 {"id":"strade_mercanti","fac":5,"n":"Pavesi da Postazione","r":null,"tag":"BALESTRE","max":1,"d":"Dopo 3 secondi fermi, i balestrieri bloccano il primo dardo ricevuto e gli effetti di quel dardo. Ricarica di 8 secondi; muoversi chiude il pavese.","behavior":"pavise",a:(m,T,t)=>{m.card.strade_mercanti=1;m.pavise=1;}},
 {"id":"capitale_seta","fac":5,"n":"Cambio della Guardia","r":null,"tag":"BALESTRE","max":1,"d":"Ogni 4 Balestrieri della Torre pagati addestrati arriva +1 Balestriere della Torre. I rinforzi attendono se manca spazio.",a:(m,T,t)=>{m.card.capitale_seta=1;}},
 {"id":"guarnigione_cittadina","fac":5,"n":"Scorta della Libertà","r":null,"tag":"BALESTRE","max":1,"d":"Ogni 5 balestrieri pagati addestrati arriva +1 Pavesaro. Comprende i Balestrieri della Torre. I rinforzi attendono se manca spazio.",a:(m,T,t)=>{m.card.guarnigione_cittadina=1;}},
 {"id":"custodi_cerchia","fac":5,"n":"Giavellotti di sortita","r":null,"tag":"CAVALLI","max":1,"d":"Dopo 8 secondi fuori dal combattimento, il prossimo ingaggio della cavalleria inizia con +1 giavellotto da 8 danni contro il bersaglio visibile entro 3 caselle, poi procede in mischia. Nessun bonus di velocità.",a:(m,T,t)=>{m.card.custodi_cerchia=1;}},
 {"id":"custodi_laterano","fac":6,"n":"Guardie del Laterano","r":null,"tag":"FANTI","max":1,"d":"Ogni 4 Guardie Pontificie pagate addestrate arriva +1 Guardia Pontificia. I rinforzi attendono se manca spazio.",a:(m,T,t)=>{m.card.custodi_laterano=1;}},
 {"id":"ordini_equestri","fac":6,"n":"Fendenti dei Custodi","r":null,"tag":"FANTI","max":1,"d":"Ogni terzo attacco normale di una Guardia Pontificia colpisce anche +1 nemico vicino al bersaglio, per 10 danni.","behavior":"cleave",a:(m,T,t)=>{m.card.ordini_equestri=1;m.cleave|=1;}},
 {"id":"decime_patrimonio","fac":6,"n":"Compagni di scudo","r":null,"tag":"FANTI","max":1,"d":"Una Guardia Pontificia entro 2 caselle da un’altra tua Guardia blocca il prossimo attacco normale da mischia che riceve. Una parata ogni 8 secondi per Guardia, senza sommare più compagni.",a:(m,T,t)=>{m.card.decime_patrimonio=1;}},
 {"id":"ospizi_pellegrini","fac":6,"n":"Ospizi sul Campo","r":null,"tag":"FANTI","max":1,"d":"Ogni Guardia Pontificia cura di 1 vita al secondo un tuo soldato ferito vicino, dopo 3 secondi senza danni al protetto. Non cura se stessa; un solo curatore e un solo effetto di cura continuativa per bersaglio.","behavior":"medicAura",a:(m,T,t)=>{m.card.ospizi_pellegrini=1;m.medicAura|=1;}},
 {"id":"colonie_pellegrini","fac":6,"n":"Pellegrini in armi","r":null,"tag":"FANTI","max":1,"d":"Ogni 8 soldati pagati addestrati arrivano +2 Pavesari. Contadini, eroi e macchine esclusi. I rinforzi attendono se manca spazio.",a:(m,T,t)=>{m.card.colonie_pellegrini=1;}},
 {"id":"fuoco_milizie","fac":6,"n":"Tiro delle Milizie","r":null,"tag":"BALESTRE","max":1,"d":"Ogni terzo tiro normale di un balestriere affiancato da un tuo fante entro 2 caselle aggiunge +1 dardo da 6 danni sullo stesso bersaglio.",a:(m,T,t)=>{m.card.fuoco_milizie=1;}},
 {"id":"studio_applicato","fac":7,"n":"Apprendisti dello Studio","r":null,"tag":"ASSEDIO","max":1,"d":"Ogni Mangano pagato completato è accompagnato da +1 Pavesaro e +1 Balestriere. I soldati attendono se manca popolazione.",a:(m,T,t)=>{m.card.studio_applicato=1;}},
 {"id":"officine_studio","fac":7,"n":"Frammenti dello Studio","r":null,"tag":"ASSEDIO","max":1,"d":"Ogni impatto di una macchina d’assedio aggiunge +2 schegge verso soldati nemici diversi entro 3 caselle, da 10 danni ciascuna. Non colpiscono edifici e non producono altri effetti.","behavior":"siegeShrapnel",a:(m,T,t)=>{m.card.officine_studio=1;m.siegeShrapnel=10;}},
 {"id":"vedette_torri","fac":7,"n":"Contrappeso di riserva","r":null,"tag":"ASSEDIO","max":1,"d":"Ogni quarto tiro normale del Mangano aggiunge +1 pietra piccola verso lo stesso bersaglio: 18 danni a un edificio oppure 8 a un soldato, senza area d’impatto.",a:(m,T,t)=>{m.card.vedette_torri=1;}},
 {"id":"compagnie_arti","fac":7,"n":"Picche delle Arti","r":null,"tag":"FANTI","max":1,"d":"Dopo 1,2 secondi ferma, la fanteria annulla il bonus del colpo di carica che riceve e contrattacca per 12 danni. Massimo una risposta ogni 2 secondi; muoversi annulla la preparazione.","behavior":"brace",a:(m,T,t)=>{m.card.compagnie_arti=1;m.brace=12;}},
 {"id":"scuola_tiro","fac":7,"n":"Tiro Incrociato","r":null,"tag":"BALESTRE","max":1,"d":"Ogni terzo tiro normale di un balestriere entro 3 caselle da una tua macchina aggiunge +1 dardo da 6 danni verso un secondo nemico in gittata.",a:(m,T,t)=>{m.card.scuola_tiro=1;}},
 {"id":"confraternite_urbane","fac":7,"n":"Compagnia dello Studio","r":null,"tag":"CAVALLI","max":1,"d":"Ogni 4 cavalieri pagati addestrati arriva +1 Balestriere: una strada per affiancare reparti mobili all’assedio. Il bonus iniziale di rimescolamenti di Bologna rimane. I rinforzi attendono se manca spazio.",a:(m,T,t)=>{m.card.confraternite_urbane=1;}},
 {id:'prep_scorte',n:'Cantiere del Comune',r:null,tag:'ECONOMIA',max:1,prep:true,noMastery:true,d:'Arrivano 3 contadini; limite contadini +3 e popolazione +8. Piazza la tua prossima Caserma entro 8 caselle dal Palazzo: gratuita e subito pronta, una sola volta.',a:(m,T,t)=>{m.wCap+=3;m.pop+=8;queueReinforcement(t,'worker',3);}},
 {id:'prep_mani',n:'Bastione del Comune',r:null,tag:'ASSEDIO',max:1,prep:true,noMastery:true,d:'Arrivano 2 Balestrieri e ottieni +6 popolazione. Piazza la tua prossima Torre entro 8 caselle dal Palazzo: gratuita e subito pronta, una sola volta. Le successive si costruiscono normalmente.',a:(m,T,t)=>{m.pop+=6;queueReinforcement(t,'xb',2);}},
 {id:'prep_guardia',n:'Compagnia all’Alba',r:null,tag:'ESERCITO',max:1,prep:true,noMastery:true,d:'Arrivano 3 Pavesari, 2 Balestrieri e 1 Feditore al Palazzo. Ottieni +8 popolazione per schierarli. Se manca spazio i rinforzi attendono: nessun soldato viene perso.',a:(m,T,t)=>{m.pop+=8;queueReinforcement(t,'inf',3);queueReinforcement(t,'xb',2);queueReinforcement(t,'cav',1);}},
 {id:'riserva_f0',fac:0,n:'Rifornimenti del Comune',r:null,tag:'ECONOMIA',max:1e9,reserve:'personal',noMastery:true,d:'Personali completate: +100 grano, +80 legname e +40 pietra. Ripetibile, senza maestria.',a:(m,T)=>{T.res.g+=100;T.res.l+=80;T.res.p+=40;}},
 {id:'riserva_f1',fac:1,n:'Rifornimenti del Comune',r:null,tag:'ECONOMIA',max:1e9,reserve:'personal',noMastery:true,d:'Personali completate: +100 grano, +80 legname e +40 pietra. Ripetibile, senza maestria.',a:(m,T)=>{T.res.g+=100;T.res.l+=80;T.res.p+=40;}},
 {id:'riserva_f3',fac:3,n:'Rifornimenti del Comune',r:null,tag:'ECONOMIA',max:1e9,reserve:'personal',noMastery:true,d:'Personali completate: +100 grano, +80 legname e +40 pietra. Ripetibile, senza maestria.',a:(m,T)=>{T.res.g+=100;T.res.l+=80;T.res.p+=40;}},
 {id:'riserva_f4',fac:4,n:'Rifornimenti del Comune',r:null,tag:'ECONOMIA',max:1e9,reserve:'personal',noMastery:true,d:'Personali completate: +100 grano, +80 legname e +40 pietra. Ripetibile, senza maestria.',a:(m,T)=>{T.res.g+=100;T.res.l+=80;T.res.p+=40;}},
 {id:'riserva_f5',fac:5,n:'Rifornimenti del Comune',r:null,tag:'ECONOMIA',max:1e9,reserve:'personal',noMastery:true,d:'Personali completate: +100 grano, +80 legname e +40 pietra. Ripetibile, senza maestria.',a:(m,T)=>{T.res.g+=100;T.res.l+=80;T.res.p+=40;}},
 {id:'riserva_f6',fac:6,n:'Rifornimenti del Comune',r:null,tag:'ECONOMIA',max:1e9,reserve:'personal',noMastery:true,d:'Personali completate: +100 grano, +80 legname e +40 pietra. Ripetibile, senza maestria.',a:(m,T)=>{T.res.g+=100;T.res.l+=80;T.res.p+=40;}},
 {id:'riserva_f7',fac:7,n:'Rifornimenti del Comune',r:null,tag:'ECONOMIA',max:1e9,reserve:'personal',noMastery:true,d:'Personali completate: +100 grano, +80 legname e +40 pietra. Ripetibile, senza maestria.',a:(m,T)=>{T.res.g+=100;T.res.l+=80;T.res.p+=40;}},
 {id:'riserva_g',n:"Scorta di Grano",r:'R',tag:'ECONOMIA',max:1e9,reserve:'general',noMastery:true,d:'Riserva quando le carte sono esaurite: +150 grano. Ripetibile, senza maestria.',a:(m,T)=>{T.res.g+=150;}},
 {id:'riserva_l',n:"Scorta di Legname",r:'R',tag:'ECONOMIA',max:1e9,reserve:'general',noMastery:true,d:'Riserva quando le carte sono esaurite: +120 legname. Ripetibile, senza maestria.',a:(m,T)=>{T.res.l+=120;}},
 {id:'riserva_p',n:"Scorta di Pietra",r:'R',tag:'ECONOMIA',max:1e9,reserve:'general',noMastery:true,d:'Riserva quando le carte sono esaurite: +100 pietra. Ripetibile, senza maestria.',a:(m,T)=>{T.res.p+=100;}},
];
const UPI={};for(const u of UPS)UPI[u.id]=u;
// Il diritto è personale, monouso e sincronizzato nei normali progressi delle carte.
function preparationBuilding(t,kind){const id=kind==='caserma'?'prep_scorte':kind==='torre'?'prep_mani':null,T=teams[t];return id&&T&&T.ups[id]&&!T.cardProgress[id]?id:null;}

// I premi contano eventi conclusi, mai l'inserimento in coda o uno spawn gratuito.
const cardSoldier=u=>!!u&&!u.d.hero&&!u.temporaryUntil&&['inf','xb','cav'].includes(u.d.cls);
const CARD_PROGRESS_RULES=[
 {id:'pavxb',event:'train',need:5,accept:u=>u.d.cls==='xb',reward:()=>[['inf',1]]},
 {id:'disciplina',event:'train',need:6,accept:u=>u.d.cls==='inf',reward:()=>[['xb',1]]},
 {id:'carpentieri',event:'train',need:1,accept:u=>u.d.cls==='treb',reward:()=>[['inf',2]]},
 {id:'comacini',event:'building',need:3,reward:()=>[['worker',1]]},
 {id:'reclut',event:'train',need:6,accept:cardSoldier,reward:u=>[[u.type,1]]},
 {id:'martinetti',event:'train',need:5,accept:u=>u.d.cls==='xb',reward:u=>[[u.type,1]]},
 {id:'riserve',event:'kill',need:8,reward:()=>[['inf',2]]},
 {id:'compagnie_popolo',event:'train',need:6,accept:u=>u.d.cls==='inf',reward:()=>[['inf',1],['xb',1]]},
 {id:'fiorino',event:'train',need:4,accept:u=>u.d.cls==='cav',reward:()=>[['cav',1]]},
 {id:'contrade',event:'train',need:3,accept:u=>u.type==='ted',reward:()=>[['ted',1]]},
 {id:'montieri',event:'train',need:6,accept:u=>u.d.cls==='inf',reward:()=>[['inf',1],['xb',1]]},
 {id:'granai_regno',event:'train',need:1,accept:u=>u.type==='ang',reward:()=>[['inf',1]]},
 {id:'bottino_guerra',event:'train',need:4,accept:u=>u.d.cls==='inf',reward:()=>[['cav',1]]},
 {id:'milizie_lega',event:'train',need:5,accept:u=>u.d.cls==='inf',reward:()=>[['pike',1]]},
 {id:'arsenale_lombardo',event:'train',need:4,accept:u=>u.type==='pike',reward:()=>[['xb',1]]},
 {id:'capitale_seta',event:'train',need:4,accept:u=>u.type==='xbe',reward:()=>[['xbe',1]]},
 {id:'guarnigione_cittadina',event:'train',need:5,accept:u=>u.d.cls==='xb',reward:()=>[['inf',1]]},
 {id:'custodi_laterano',event:'train',need:4,accept:u=>u.type==='guard',reward:()=>[['guard',1]]},
 {id:'colonie_pellegrini',event:'train',need:8,accept:cardSoldier,reward:()=>[['inf',2]]},
 {id:'studio_applicato',event:'train',need:1,accept:u=>u.type==='mang',reward:()=>[['inf',1],['xb',1]]},
 {id:'confraternite_urbane',event:'train',need:4,accept:u=>u.d.cls==='cav',reward:()=>[['xb',1]]}
];
function queueReinforcement(t,type,count=1){if(!isActivePlayer(t)||!UT[type]||UT[type].hero||!Number.isInteger(count)||count<=0)return false;
 const q=teams[t].reinforcementQueue,entry=q.find(x=>x.type===type);if(entry)entry.count=Math.min(1e6,entry.count+count);else q.push({type,count:Math.min(1e6,count)});return true;}
function flushReinforcements(t){if(!isActivePlayer(t))return;const T=teams[t];let budget=8;
 for(const q of T.reinforcementQueue){while(q.count&&budget>0){const d=UT[q.type];if(T.popUsed+d.pop>T.popMax||q.type==='worker'&&workerCount(t,true)>=T.mods.wCap||d.cls==='treb'&&trebCount(t)>=2+T.mods.siegeMax||q.type==='carr'&&carrCount(t)>=1)break;
   const u=spawnNear(t,q.type,true);if(!u)break;q.count--;budget--;}}
 T.reinforcementQueue=T.reinforcementQueue.filter(q=>q.count>0);}
function cardProgressAdd(t,id,need,amount=1){const T=teams[t],n=(T.cardProgress[id]||0)+amount;T.cardProgress[id]=n%need;return Math.floor(n/need);}
function cardEvent(t,event,subject){if(!isActivePlayer(t))return;const T=teams[t];
 for(const rule of CARD_PROGRESS_RULES)if(rule.event===event&&T.ups[rule.id]&&(!rule.accept||rule.accept(subject))){const n=cardProgressAdd(t,rule.id,rule.need);if(n)for(const [type,count]of rule.reward(subject))queueReinforcement(t,type,count*n*T.ups[rule.id]);}}
function cardOnPaidTrain(u,q){if(!u||u.free||u.temporaryUntil||u.d.hero||!q.paid||!Object.values(q.cost||{}).some(v=>v>0))return;u.paidRecruit=true;cardEvent(u.team,'train',u);}
function cardOnPaidBuilding(b){if(b.def.wall||!Object.values(b.paid||{}).some(v=>v>0))return;cardEvent(b.team,'building',b);}
function cardOnLoss(u,by){const T=teams[u.team];if(!isActivePlayer(u.team)||!T.ups.martinella||!u.paidRecruit||u.free||!cardSoldier(u)||by==null||!areEnemies(by,u.team))return;
 T.cardProgress.martinella=Math.min(6,(T.cardProgress.martinella||0)+1);cardDefenseTick(u.team,0);}
function cardDefenseTick(t,dt){const T=teams[t];for(const k of ['martinella','spesse'])T.cardCooldowns[k]=Math.max(0,T.cardCooldowns[k]-dt);
 if(T.ups.martinella&&T.cardProgress.martinella>=6&&T.cardCooldowns.martinella<=0){T.cardProgress.martinella=0;T.cardCooldowns.martinella=45;queueReinforcement(t,'inf',2);}}
// A full, temporary squad needs three legal, unoccupied cells and three population slots.
// One shared cooldown prevents a chain of towers from producing an unlimited army.
function cardGarrison(b){if(!b.built||b.dead||!isActivePlayer(b.team)||isClient())return false;const T=teams[b.team];
 if(!T.ups.spesse||T.cardCooldowns.spesse>0||T.popUsed+3>T.popMax||units.some(u=>!u.dead&&u.team===b.team&&u.garrisonHome))return false;
 const spots=[];for(let ring=1;ring<=2&&spots.length<3;ring++)for(let y=b.cy-ring;y<b.cy+b.h+ring&&spots.length<3;y++)for(let x=b.cx-ring;x<b.cx+b.w+ring&&spots.length<3;x++){
  if(!inb(x,y)||!passFor(b.team,y*GW+x))continue;const px=cX(y*GW+x),py=cY(y*GW+x);
  if(units.some(u=>!u.dead&&hyp(u.x-px,u.y-py)<u.d.r+10)||spots.some(p=>p.x===px&&p.y===py))continue;spots.push({x:px,y:py});}
 if(spots.length!==3)return false;T.cardCooldowns.spesse=90;
 for(let k=0;k<3;k++){const p=spots[k],u=mkUnit(b.team,k===2?'xb':'inf',p.x,p.y,{free:true,temporaryUntil:G.t+20,garrisonHome:b.id});u.anchor={...p};}
 notify(b.team,'toast','Guarnigione di emergenza: 3 difensori per 20 s','#c8f0b0',1800);return true;}
function cardDelivery(t,r,count=1){if(!isActivePlayer(t)||!RES.includes(r)||count<=0)return;const T=teams[t],bonus=(T.mods.delivery[r]+mastN(T,'ECONOMIA'))*count;T.res[r]+=bonus;T.gath[r]+=bonus;
 if(r==='g'&&T.ups.mulino){const n=cardProgressAdd(t,'mulino',6,count);T.res.g+=n*15*T.ups.mulino;}}
function depositWorker(u){if(!(u.carry>0)||!RES.includes(u.ct))return;const T=teams[u.team];T.res[u.ct]+=u.carry;T.gath[u.ct]+=u.carry;if(!u.temporaryUntil)cardDelivery(u.team,u.ct);u.carry=0;}
function cardProgressInfo(t){const T=teams[t],rows=CARD_PROGRESS_RULES.filter(r=>T.ups[r.id]).map(r=>({id:r.id,name:UPI[r.id].n,current:T.cardProgress[r.id]||0,need:r.need,pending:0}));
 for(const [kind,id]of [['caserma','prep_scorte'],['torre','prep_mani']])if(T.ups[id])rows.push({id,name:BT[kind].n+' gratuita e istantanea '+(T.cardProgress[id]?'utilizzata':'disponibile: piazzala vicino al Palazzo'),current:T.cardProgress[id]||0,need:1,pending:0});
 if(T.ups.martinella)rows.push({id:'martinella',name:UPI.martinella.n,current:T.cardProgress.martinella||0,need:6,pending:0,cooldown:Math.ceil(T.cardCooldowns.martinella)});
 if(T.ups.spesse)rows.push({id:'spesse',name:UPI.spesse.n,current:0,need:0,pending:0,cooldown:Math.ceil(T.cardCooldowns.spesse),ready:T.cardCooldowns.spesse<=0});
 if(T.ups.mulino)rows.push({id:'mulino',name:UPI.mulino.n,current:T.cardProgress.mulino||0,need:6,pending:0});
 for(const q of T.reinforcementQueue)rows.push({id:'pending_'+q.type,name:UT[q.type].n,current:0,need:0,pending:q.count});return rows;}
function unitCardProgressInfo(u){if(!u||u.d.hero||u.type==='worker')return [];const T=teams[u.team],m=T.mods,c=u.cardCounters||{},rows=[],add=(id,key,need)=>{if(T.ups[id])rows.push({name:UPI[id].n,current:(c[key]||0)%need,need});};
 if(u.d.cls==='xb'){add('falco','shots',4);add('botteghe_balestrai','shots',3);add('fondachi_porto','vsCavShots',4);add('fuoco_milizie','shots',3);add('scuola_tiro','shots',3);}
 if(u.d.cls==='inf'){add('mezzadria','attacks',3);add('carri_lombardi','attacks',3);if(u.type==='guard')add('ordini_equestri','attacks',3);}
 if(u.d.cls==='cav'){add('scuderie_reali','attacks',3);add('fedelta_baroni','attacks',3);add('comunita_contado','cavHits',3);}
 if(u.type==='mang')add('vedette_torri','siegeShots',4);return rows;}

// Reward time is stored at award; timed minute-2/4 offers keep Rare-only even in a queue.
// Later guarantees follow display time, except those two offers and the initial preparations.
function queuePick(t,src,minR,at=G.t){const T=teams[t];if(!isActivePlayer(t))return false;const p={src,at};if(minR)p.minR=minR;T.picks.push(p);return true;}
function queuePreparation(t){const T=teams[t];if(!isActivePlayer(t)||T.preparationQueued)return false;T.preparationQueued=true;return queuePick(t,'preparativi',null,0);}
const cardRank=u=>u.r==null?1.5:RANK[u.r];
function rollOffer(t,context){const T=teams[t],p=typeof context==='string'?{...(T.picks[0]||{}),minR:context}:context||T.picks[0]||{};
 if(p.src==='preparativi')return UPS.filter(u=>u.prep);
 T.pity++;
 const at=Number.isFinite(p.at)?p.at:G.t,rareOnly=p.src==='tempo'&&(Math.abs(at-120)<.01||Math.abs(at-240)<.01);
 const late=!rareOnly&&Math.max(at,G.t)>=720;
 const ok=u=>!u.prep&&!u.reserve&&(T.ups[u.id]||0)<u.max&&facOk(u.fac,T.fac)&&(!u.minT||G.t>=u.minT);
 let pool=UPS.filter(ok);if(rareOnly)pool=pool.filter(u=>u.r==='R'&&u.fac==null);
 const out=[],generalReserves=UPS.filter(u=>u.reserve==='general');
 const pick=arr=>{let total=0;for(const u of arr)total+=u.r==null?22:RW[u.r];let n=Math.random()*total;for(const u of arr){n-=u.r==null?22:RW[u.r];if(n<=0)return u;}return arr[arr.length-1];};
 const take=u=>{if(!u||out.includes(u))return;out.push(u);pool=pool.filter(x=>x!==u);};
 const addReserves=()=>{for(const u of generalReserves)if(!out.includes(u)&&!pool.includes(u))pool.push(u);};
 if(late){let personal=pool.filter(u=>u.fac===T.fac);if(!personal.length)personal=UPS.filter(u=>u.reserve==='personal'&&u.fac===T.fac);take(pick(personal));}
 const floor=rareOnly?'R':T.pity>=5?'E':late?'R':p.minR;
 if(floor){let high=pool.filter(u=>u.fac==null&&RANK[u.r]>=RANK[floor]);if(!high.length){addReserves();high=pool.filter(u=>u.r==='R'&&u.fac==null);}take(pick(high));}
 if(pool.length+out.length<3)addReserves();
 while(out.length<3)take(pick(pool));
 if(out.some(u=>u.r==='E'))T.pity=0;
 for(let i=out.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[out[i],out[j]]=[out[j],out[i]];}
 return out;
}
function ensureOffer(t){const T=teams[t];if(!isActivePlayer(t)||!T.picks.length)return null;if(!T.offer){T.offer=rollOffer(t,T.picks[0]).map(u=>u.id);T.offerSeq=(T.offerSeq||0)+1;}return T.offer;}
function rerollOffer(t){const T=teams[t];if(!isActivePlayer(t)||!T.offer||T.rerolls<=0||T.picks[0]?.src==='preparativi')return false;
 T.rerolls--;T.pity=Math.max(0,T.pity-1);T.offer=rollOffer(t,T.picks[0]).map(u=>u.id);T.offerSeq=(T.offerSeq||0)+1;return true;}
function takeOffer(t,id,seq){const T=teams[t],u=UPI[id];if(!isActivePlayer(t)||seq!==T.offerSeq||!T.offer?.includes(id)||!u)return false;
 if(!u.reserve&&(T.ups[id]||0)>=u.max||!facOk(u.fac,T.fac))return false;T.offer=null;T.picks.shift();return applyUp(t,u);}
function applyUp(t,u){const T=teams[t];if(!isActivePlayer(t)||!u||!u.reserve&&(T.ups[u.id]||0)>=u.max||!facOk(u.fac,T.fac))return false;
 T.ups[u.id]=Math.min(u.max,(T.ups[u.id]||0)+1);const before=Math.floor((T.tagN[u.tag]||0)/3);
 if(!u.noMastery){T.tagN[u.tag]=(T.tagN[u.tag]||0)+1;T.upsTaken++;}
 u.a(T.mods,T,t);refreshStats(t);const after=Math.floor((T.tagN[u.tag]||0)/3);
 if(after>before)notify(t,'toast',`Maestria ${u.tag} ${'I'.repeat(Math.min(after,3))}${after>3?'+':''}: ${MAST_TXT[u.tag]}`,'#9fe0ff',2400);return true;}
// La valutazione usa solo l'esercito e i progetti propri: nessuna lettura del nemico nella nebbia.
function aiCardContext(t){const T=teams[t],count={worker:0,inf:0,xb:0,cav:0,treb:0,carr:0},built={},planned={},queued={...count};
 for(const u of units)if(!u.dead&&!u.d.hero&&!u.temporaryUntil&&u.team===t)count[u.d.cls]=(count[u.d.cls]||0)+1;
 for(const b of blds)if(!b.dead&&b.team===t){planned[b.kind]=(planned[b.kind]||0)+1;if(b.built)built[b.kind]=(built[b.kind]||0)+1;
  for(const q of b.queue||[]){if(UT[q.type].hero)continue;const cls=UT[q.type].cls;queued[cls]=(queued[cls]||0)+1;}}
 const total={};for(const cls in count)total[cls]=count[cls]+queued[cls];
 const army=count.inf+count.xb+count.cav+count.treb,rich=T.res.g>=600&&T.res.l>=600;
 return {T,count,total,built,planned,army,rich,workers:total.worker,pref:T.aiPref||{}};}
function aiCardFit(c,cls){const n=c.total[cls]||0;
 // Le macchine sono limitate per regola: due trabucchi non sono irrilevanti fra cento fanti.
 if(cls==='treb'&&n)return .85+.65*Math.min(1,n/Math.max(1,2+c.T.mods.siegeMax));
 if(n)return .85+Math.min(.65,n/Math.max(1,c.army));
 const building={inf:'caserma',xb:'caserma',cav:'scuderia',treb:'officina',carr:'palazzo'}[cls];
 if(!c.planned[building])return .08;
 const tag={inf:'FANTI',xb:'BALESTRE',cav:'CAVALLI',treb:'ASSEDIO',carr:'ESERCITO'}[cls];
 if(cls==='carr')return c.T.fac===0&&G.t>=420?.5:.08;
 return c.built[building]?.45+Math.min(.35,(c.pref[tag]||1)*.15):.35;}
function aiCardValue(u,c){const T=c.T,m=T.mods,fit=cls=>aiCardFit(c,cls),tagClass={FANTI:'inf',BALESTRE:'xb',CAVALLI:'cav'};
 let value=(c.pref[u.tag]||1)*(1+cardRank(u)*.6),use=tagClass[u.tag]?fit(tagClass[u.tag]):1;
 if(u.reserve||u.id==='dote'){
  const resources=u.reserve==='general'?[u.id.slice(-1)]:u.id==='dote'?['g','l']:RES;
  const need=Math.max(...resources.map(r=>Math.max(0,1-T.res[r]/(r==='g'?180:r==='l'?160:120))));
  return .08+2.6*need; // Una consegna una tantum non vale come una tattica personale permanente.
 }
 if(u.tag==='ECONOMIA')use=(.65+Math.min(.55,c.workers/45))*(c.rich?.5:1);
 if(u.tag==='ESERCITO')use=c.army?1:.4;
 if(u.tag==='ASSEDIO')use=fit('treb');
 if(u.behavior==='bodyguard')use=Math.min(fit('inf'),fit(u.id==='compagnie_balestriere'?'treb':'xb'));
 if(u.id==='gonfalone')use=fit('carr')*(c.army?1:.3);
 if(u.id==='ospizi_pellegrini')use=fit('inf')*(c.army>1?1:.4);
 if(['milizia','ventura'].includes(u.id))use=1.15;
 if(u.id==='contado')use=c.workers>=m.wCap?.04:Math.max(.35,1-c.workers/m.wCap);
 if(u.id==='colonie_pellegrini')use=Math.max(fit('inf'),fit('xb'),fit('cav'));
 if(u.id==='famiglie'||u.id==='pievi')use=c.rich?.65:1;
 if(u.id==='schiera')use=T.popMax>=300?.02:T.popMax-T.popUsed<8?1.8:.3;
 if(u.id==='reclut'&&T.popMax-T.popUsed<2)use*=.35;
 if(u.id==='bardi')use=c.rich?.35:1;
 if(u.id==='mulino')use*=c.planned.campo?1:.15;
 if(u.id==='granai_regno'||u.id==='contrade')use=fit('cav');
 if(u.id==='arsenale')use=fit('treb')*(c.total.treb>=2+m.siegeMax?1.45:.25);
 if(u.id==='feritoie')use=c.built.torre?1.15:c.built.palazzo?.65:.1;
 if(['merlate','spesse'].includes(u.id))use=c.built.torre?1.3:c.planned.torre?.6:.1;
 if(u.id==='disciplina')use=fit('inf');
 if(u.id==='martinella')use=c.army>=10?1.2:.35;
 if(u.id==='ciclopiche')use=c.planned.torre||c.planned.mura||c.planned.porta?1.15:.15;
 if(u.id==='benedette')use=Math.max(fit('inf'),fit('cav'));
 if(u.id==='fortuna')use=Math.max(use,T.rerolls<2?1.2:.8);
 if(u.id==='carpentieri')use=fit('treb');
 if(u.id==='scuola_tiro')use=Math.min(fit('xb'),fit('treb'));
 if(u.id==='fuoco_milizie')use=Math.min(fit('xb'),fit('inf'));
 // Solo sinergie già utilizzabili: i bonus non trasformano una carta senza portatori in una priorità.
 if(c.total.inf&&u.behavior==='bodyguard'&&c.total[u.id==='compagnie_balestriere'?'treb':'xb'])use*=1.1;
 // L'assedio operativo deve poter competere con la classe militare preferita nel finale.
 // Officine vuote e sole macchine in coda non rendono urgente un potenziamento.
 if(G.t>=720&&c.built.officina&&c.count.treb>0&&(u.id==='contrappesi'||u.id==='arsenale'||u.behavior==='siegeShrapnel'))
  value=Math.max(value,Math.max(c.pref.FANTI||1,c.pref.BALESTRE||1,c.pref.CAVALLI||1)*(1+cardRank(u)*.6));
 return value*use;}
function aiCardCanImprove(t,c,best){const T=teams[t],p=T.picks[0],at=p.at,rareOnly=p.src==='tempo'&&(Math.abs(at-120)<.01||Math.abs(at-240)<.01);
 return UPS.some(u=>!u.prep&&!u.reserve&&!T.offer.includes(u.id)&&(T.ups[u.id]||0)<u.max&&facOk(u.fac,T.fac)&&(!u.minT||G.t>=u.minT)&&
  (!rareOnly||u.r==='R'&&u.fac==null)&&aiCardValue(u,c)>Math.max(1.2,best*1.35));}
function aiPick(t){const T=teams[t];if(!ensureOffer(t))return;
 // I preparativi conservano la selezione iniziale e non consumano rimescolamenti.
 if(T.picks[0].src==='preparativi'){let best=UPI[T.offer[0]],bs=-1;for(const id of T.offer){const u=UPI[id],s=((T.aiPref||{})[u.tag]||1)*(1+cardRank(u)*.6)*MR(.6,1.4);if(s>bs){bs=s;best=u;}}return takeOffer(t,best.id,T.offerSeq);}
 const c=aiCardContext(t),bestValue=Math.max(...T.offer.map(id=>aiCardValue(UPI[id],c)));
 // Al massimo un tentativo per ricompensa; niente sprechi se il catalogo utile è esaurito.
 if(T.rerolls>0&&bestValue<1.05&&aiCardCanImprove(t,c,bestValue))rerollOffer(t);
 let best=UPI[T.offer[0]],bs=-1;for(const id of T.offer){const u=UPI[id],s=aiCardValue(u,c)*MR(.6,1.4);if(s>bs){bs=s;best=u;}}
 return takeOffer(t,best.id,T.offerSeq);}
function addGlory(t,v){const T=teams[t];if(!isActivePlayer(t)||!(v>0))return;T.glory+=v*(1+T.mods.glory)+T.mods.flatGlory;
 while(T.glory>=T.gloryNeed){T.glory-=T.gloryNeed;T.gloryNeed=Math.round(T.gloryNeed*1.3);queuePick(t,'gloria');notify(t,'sfx','glory');notify(t,'toast','✦ Gloria! Un potenziamento in più ✦','#ffd76a',1800);}}

// ===================== carte (interfaccia) =====================
const ICONS={
 ECONOMIA:`<svg viewBox="0 0 100 100"><path d="M50 92V30" stroke="#8a6a2a" stroke-width="4"/><g fill="#e8c35a" stroke="#9a7420" stroke-width="2"><ellipse cx="50" cy="20" rx="7" ry="11"/><ellipse cx="40" cy="38" rx="7" ry="11" transform="rotate(-30 40 38)"/><ellipse cx="60" cy="38" rx="7" ry="11" transform="rotate(30 60 38)"/><ellipse cx="40" cy="58" rx="7" ry="11" transform="rotate(-30 40 58)"/><ellipse cx="60" cy="58" rx="7" ry="11" transform="rotate(30 60 58)"/></g></svg>`,
 FANTI:`<svg viewBox="0 0 100 100"><path d="M74 8v84" stroke="#6b4a28" stroke-width="4"/><path d="M68 10l6-8 6 8z" fill="#cfd4da"/><path d="M18 14h52v44c0 18-13 29-26 34C31 87 18 76 18 58z" fill="#f4efe2" stroke="#5a4020" stroke-width="4"/><path d="M44 22v62M22 46h44" stroke="#c8221e" stroke-width="9"/></svg>`,
 BALESTRE:`<svg viewBox="0 0 100 100"><path d="M20 78L74 24" stroke="#6b4a28" stroke-width="7" stroke-linecap="round"/><path d="M50 12q30 8 38 38" stroke="#5d6268" stroke-width="6" fill="none"/><path d="M50 12L56 46 88 50" stroke="#eee" stroke-width="2" fill="none"/><path d="M84 14l-16 2 12 12z" fill="#3b82d6"/><path d="M14 86l20-20" stroke="#c9a46a" stroke-width="3"/></svg>`,
 CAVALLI:`<svg viewBox="0 0 100 100"><path d="M18 84l8-26c-6-8-4-20 6-26l14-12 10 4 18 18-6 8-12-6-4 12 8 28H50l-8-22-14 4-2 18z" fill="#7a5434" stroke="#3a2412" stroke-width="3"/><path d="M58 52L96 28" stroke="#c9a46a" stroke-width="4"/><path d="M96 28l-8 1 4 6z" fill="#ddd"/></svg>`,
 ASSEDIO:`<svg viewBox="0 0 100 100"><path d="M10 90h80M24 90L50 40 76 90" stroke="#5c3e22" stroke-width="6" fill="none" stroke-linecap="round"/><path d="M26 52L92 18" stroke="#7a5430" stroke-width="5" stroke-linecap="round"/><rect x="14" y="48" width="16" height="18" fill="#4e4a44"/><circle cx="90" cy="14" r="7" fill="#8a8378" stroke="#4a4640" stroke-width="2"/></svg>`,
 ESERCITO:`<svg viewBox="0 0 100 100"><path d="M20 20l58 58M80 20L22 78" stroke="#cfd4da" stroke-width="7" stroke-linecap="round"/><path d="M14 72l14 14M86 72L72 86" stroke="#6b4a28" stroke-width="8" stroke-linecap="round"/><circle cx="50" cy="50" r="9" fill="#e0a530" stroke="#6a4208" stroke-width="3"/></svg>`,
 martinella:`<svg viewBox="0 0 100 100"><defs><linearGradient id="gb" x1="0" x2="1"><stop offset="0" stop-color="#ffe9a0"/><stop offset=".5" stop-color="#e0a530"/><stop offset="1" stop-color="#8a5a10"/></linearGradient></defs><path d="M50 12c-4 0-6 3-6 6-14 4-20 16-20 34 0 12-4 18-10 22h72c-6-4-10-10-10-22 0-18-6-30-20-34 0-3-2-6-6-6z" fill="url(#gb)" stroke="#6a4208" stroke-width="3"/><circle cx="50" cy="82" r="7" fill="#c98a1e" stroke="#6a4208" stroke-width="3"/><path d="M8 40q-6 12 0 24M92 40q6 12 0 24" stroke="#ffd76a" stroke-width="3" fill="none"/></svg>`,
};
// l'offerta di carte sta in teams[ME].offer (id delle carte); da soli la partita si ferma, online no
let cardsOpen=false,curOffer=null,curOfferSeq=0,offerKey='',choosing=false,pendingReroll=null;
const rerollPending=()=>!!pendingReroll&&pendingReroll.game===G&&pendingReroll.seq===teams[ME].offerSeq;
function cardsTick(){const T=teams[ME];if(!T)return;const key=T.offer?T.offerSeq+':'+T.offer.join(','):'';
 if(pendingReroll&&!rerollPending())pendingReroll=null;
 if(cardsOpen)document.getElementById('ovMore').textContent=T.picks.length>1?`Altri ${T.picks.length-1} in attesa`:'';
 if(!key){if(cardsOpen&&!choosing)closeCards();offerKey='';}
 else if(key!==offerKey&&!choosing){offerKey=key;openCards();}
 const b=document.getElementById('pickBtn');if(b){const n=T.offer?Math.max(1,T.picks.length):0;b.classList.toggle('hidden',!(n&&!cardsOpen));b.textContent=`✦ Scegli potenziamento${n>1?' ('+n+')':''}`;}}
function openCards(){const T=teams[ME];if(!T.offer||choosing)return;cardsOpen=true;const ov=document.getElementById('ov');ov.classList.toggle('live',!!G.mp);
 const p=T.picks[0]||{};document.getElementById('ovTitle').textContent=p.src==='preparativi'?'PREPARATIVI: SCEGLI COME PARTIRE':p.src==='reliquia'?'ACCAMPAMENTO CONQUISTATO!':p.src==='gloria'?'GLORIA! SCEGLI UN POTENZIAMENTO':'SCEGLI UN POTENZIAMENTO';
 document.getElementById('later').classList.toggle('hidden',!G.mp);ov.style.display='flex';curOffer=T.offer.map(id=>UPI[id]).filter(Boolean);curOfferSeq=T.offerSeq;deal();}
function closeCards(){document.getElementById('ov').style.display='none';cardsOpen=false;curOffer=null;}
function deal(){const T=teams[ME],dealtSeq=curOfferSeq;const el=document.getElementById('cards');el.innerHTML='';
 document.getElementById('reroll').textContent=`↻ Rimescola (${T.rerolls})`;document.getElementById('reroll').disabled=T.rerolls<=0||T.picks[0]?.src==='preparativi'||rerollPending();
 document.getElementById('ovMore').textContent=T.picks.length>1?`Altri ${T.picks.length-1} in attesa`:'';
 curOffer.forEach((u,k)=>{const [col,glow]=RC[u.r]||[u.fac!=null?FAC[u.fac].mini:'#d4bc84','transparent'];const lvl=T.ups[u.id]||0;const tn=(T.tagN[u.tag]||0)%3;const slot=document.createElement('div');slot.className='slot';
  const pips=u.max>1&&!u.reserve?`<div class="lv">${'◆'.repeat(lvl)}<b>◆</b>${'◇'.repeat(Math.max(0,u.max-lvl-1))}</div>`:'';
  slot.innerHTML=`<div class="card" style="--c:${col};--g:${glow}">
   <div class="back"><svg width="70" height="70" viewBox="-12 -12 24 24"><path d="M0-11Q4.5-4 1.6 2H-1.6Q-4.5-4 0-11ZM1.6 1.5Q9-1 8-8Q11.5-1 4.5 4.5ZM-1.6 1.5Q-9-1-8-8Q-11.5-1-4.5 4.5ZM-5.5 2.4h11v2.6h-11zM-1.6 5h3.2l1.4 6h-6z" fill="#c9a95a"/></svg></div>
   <div class="face"><div class="rar">${u.prep?'PREPARATIVI':u.fac!=null?FAC[u.fac].name.toUpperCase():RN[u.r].toUpperCase()}</div>${ICONS[u.id]||ICONS[u.tag]}<div class="nm">${u.n}</div>${pips}<div class="tx">${u.d}</div>
   <div class="tag">${u.tag}<div class="setp" style="${u.noMastery?'display:none':''}">${[0,1,2].map(j=>`<i class="${j<tn?'on':j===tn?'nx':''}"></i>`).join('')}</div><div class="mt">${u.noMastery?'Effetto immediato':tn===2?'→ MAESTRIA!':'maestria ogni 3'}</div></div></div></div>`;
  el.appendChild(slot);const card=slot.querySelector('.card');
  setTimeout(()=>{card.classList.add('up');sfx('flip');setTimeout(()=>sfx('r'+(u.r||'R')),230);},(G.mp?120:250)+k*(G.mp?180:380));
  card.onclick=()=>chooseCard(slot,u,dealtSeq);});}
function chooseCard(slot,u,selectedSeq=curOfferSeq){if(!cardsOpen||!curOffer||choosing||rerollPending()||selectedSeq!==curOfferSeq||teams[ME].offerSeq!==selectedSeq)return;const selectedGame=G;
 if(G.mp&&!cmd({type:'pick',id:u.id,offerSeq:selectedSeq})){toast('Scelta non inviata: controlla il collegamento.','#ff9a8a',2200);return;}
 curOffer=null;choosing=true;const el=document.getElementById('cards');
 [...el.children].forEach(s=>{const c=s.querySelector('.card');if(s===slot)c.classList.add('chosen');else c.classList.add('gone');});sfx('pick');
 setTimeout(()=>{if(G!==selectedGame)return;if(!G.mp)cmd({type:'pick',id:u.id,offerSeq:selectedSeq});toast('✦ '+u.n+' ✦','#ffe3a0');closeCards();choosing=false;if(!G.mp)offerKey='';},G.mp?350:650);}
function rerollCards(){const T=teams[ME];if(T.rerolls<=0||!curOffer||choosing||rerollPending()||T.picks[0]?.src==='preparativi'||T.offerSeq!==curOfferSeq)return;
 const seq=curOfferSeq;if(cmd({type:'reroll',offerSeq:seq})){pendingReroll={game:G,seq};curOffer=null;document.getElementById('reroll').disabled=true;}}
function flash(){}
