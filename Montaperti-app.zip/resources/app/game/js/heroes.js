'use strict';
// Eroi: una copia per città. Tutti gli effetti appartengono al proprietario, non all'alleanza.
const HEROES=[
 {fac:0,type:'hero_fi',name:'Gonfaloniere del Popolo',heroArt:'inf',base:'inf',hp:360,dmg:18,cd:60,target:null,range:96,activeName:'Compagnia scelta',passive:'Ogni 4 attacchi normali a segno prepara un colpo aggiuntivo di un tuo fante entro 3 caselle.',active:'Chiama 3 Pavesari temporanei per 18 secondi. Richiede popolazione e spazio per tutti e tre; nessun premio di reclutamento o uccisione.'},
 {fac:1,type:'hero_si',name:'Capitano delle Contrade',heroArt:'ted',base:'cav',hp:420,dmg:19,cd:50,target:null,range:64,activeName:'Falciata a cavallo',passive:'Dopo almeno 1,2 secondi di corsa il primo attacco raggiunge anche un secondo nemico immediatamente dietro al bersaglio.',active:'Dopo 0,6 secondi colpisce fino a 4 soldati nemici entro 2 caselle per 30 danni. Chi si allontana evita il colpo; edifici esclusi.'},
 {fac:3,type:'hero_na',name:'Campione Angioino',heroArt:'ang',base:'cav',hp:420,dmg:19,cd:45,target:null,range:48,activeName:'Contrattacco reale',passive:'Il terzo attacco normale a segno sullo stesso nemico prepara un affondo aggiuntivo. Cambiare bersaglio azzera il conteggio.',active:'Per 4 secondi para i prossimi 2 attacchi normali da mischia e contrattacca per 16 danni se l’attaccante resta a portata.'},
 {fac:4,type:'hero_mi',name:'Capitano della Lega',heroArt:'pike',base:'inf',hp:380,dmg:18,cd:50,target:'enemy',range:96,activeName:'Affondo della Lega',passive:'Ogni 6 secondi intercetta un dardo destinato a un tuo tiratore entro 3 caselle, subendolo al suo posto.',active:'Un affondo lungo 3 caselle raggiunge i primi 2 soldati nemici per 35 danni e interrompe il loro attacco per 1 secondo. Muri ed edifici lo bloccano.'},
 {fac:5,type:'hero_lu',name:'Custode della Cerchia',heroArt:'xbe',base:'xb',hp:260,dmg:16,cd:50,target:'enemy',range:260,activeName:'Tiro inchiodante',passive:'Ogni terzo dardo principale trapassa il bersaglio e raggiunge un nemico allineato dietro di esso.',active:'Dopo 1 secondo di mira spara un dardo da 30 danni. Immobilizza per 2 secondi, senza impedire gli attacchi. Muoversi interrompe la mira; dopo l’effetto il bersaglio è immune per 5 secondi.'},
 {fac:6,type:'hero_ro',name:'Prefetto della Guardia',heroArt:'guard',base:'inf',hp:400,dmg:18,cd:50,target:null,range:96,activeName:'Provocazione della Guardia',passive:'Ogni nemico abbattuto personalmente cura di 6 vita fino a 3 tuoi soldati entro 3 caselle.',active:'Fino a 3 fanti o cavalieri nemici attaccano il Prefetto per 3 secondi. Ordini espliciti interrompono l’effetto; poi 5 secondi di immunità. Esclusi eroi, contadini, tiratori e macchine.'},
 {fac:7,type:'hero_bo',name:'Maestro Artigliere',heroArt:'xb',base:'xb',hp:280,dmg:16,cd:50,target:'siege',range:128,activeName:'Munizione a grappolo',passive:'Ogni 4 colpi normali a segno recupera 1 secondo della ricarica della tua macchina d’assedio più vicina entro 4 caselle.',active:'La prossima pietra normale di una tua macchina vicina aggiunge 3 pietre da 12 danni verso soldati diversi entro 2 caselle dall’impatto. Da usare entro 10 secondi; edifici esclusi.'}
];
for(const h of HEROES){Object.assign(UT,{[h.type]:{...UT[h.base],n:h.name,hp:h.hp,dmg:h.dmg,rng:h.fac===5?260:UT[h.base].rng,hero:true,heroArt:h.heroArt,fac:[h.fac],pop:3,cost:{g:180,l:120,p:40},t:35,glory:12,desc:h.passive+' '+h.active}});BT.palazzo.train.push(h.type);}
const heroMeta=u=>u&&HEROES.find(h=>h.type===(typeof u==='string'?u:u.type));
function heroOnSpawn(u){if(u.d.hero){u.heroReadyAt=G.t;u.heroCount=0;u.heroInterceptAt=0;}}
function heroTrainBlock(t,b,type){if(!UT[type]?.hero)return null;if(b.kind!=='palazzo')return 'Recluta l’eroe al Palazzo';
 if((teams[t].heroReviveAt||0)>G.t)return 'Eroe disponibile fra '+Math.ceil(teams[t].heroReviveAt-G.t)+' s';
 if(units.some(u=>!u.dead&&u.team===t&&u.d.hero)||blds.some(x=>!x.dead&&x.team===t&&x.queue.some(q=>UT[q.type]?.hero)))return 'Un solo eroe per città';return null;}
function heroSoldier(u){return !!u&&!u.dead&&!u.isB&&u.hp>0&&!['worker','carr','treb'].includes(u.d.cls);}
function heroVisible(t,u){if(!u||u.dead||u.sheltered)return false;for(const s of units)if(!s.dead&&!s.sheltered&&areAllies(t,s.team)&&isActivePlayer(s.team)&&hyp(s.x-u.x,s.y-u.y)<=teams[s.team].S[s.type].sight)return true;
 return blds.some(b=>!b.dead&&areAllies(t,b.team)&&isActivePlayer(b.team)&&hyp(b.x-u.x,b.y-u.y)<=(b.def.sight||150)*(1+teams[b.team].mods.sight)*(b.built?1:.6));}
function heroClear(u,t){return los(u.team,u.x,u.y,t.x,t.y,t.isB?t:null);}
function heroEnemies(u,r){return units.filter(e=>heroSoldier(e)&&areEnemies(u.team,e.team)&&hyp(e.x-u.x,e.y-u.y)<=r&&heroVisible(u.team,e)&&heroClear(u,e)).sort((a,b)=>hyp(a.x-u.x,a.y-u.y)-hyp(b.x-u.x,b.y-u.y)||a.id-b.id);}
function heroSpawnSpots(u){const out=[];for(let ring=1;ring<=3&&out.length<3;ring++)for(let k=0;k<8&&out.length<3;k++){
 const a=k*Math.PI/4,x=u.x+Math.cos(a)*ring*24,y=u.y+Math.sin(a)*ring*24,i=cellI(x,y),r=UT.inf.r;
 if(x<r||y<r||x>WW-r||y>WH-r||!passFor(u.team,i)||[-r,r].some(dx=>[-r,r].some(dy=>!passFor(u.team,cellI(x+dx,y+dy))))||!heroClear(u,{x,y})||units.some(e=>!e.dead&&hyp(e.x-x,e.y-y)<e.d.r+r+2)||out.some(p=>hyp(p.x-x,p.y-y)<r*2+2))continue;out.push({x,y});}return out;}
function heroAbilityBlock(t,u,target=null){if(!G||G.over||!isActivePlayer(t)||!u||u.dead||u.team!==t||!u.d.hero||![u.x,u.y].every(Number.isFinite))return 'Eroe non disponibile';const h=heroMeta(u);
 if(u.heroCast)return 'Abilità in preparazione';if((u.heroStunUntil||0)>G.t)return 'Eroe interrotto';if((u.heroReadyAt||0)>G.t)return 'Abilità in ricarica';
 if(h.target){if(!target||target.dead||target.isB||target.hp<=0||![target.x,target.y].every(Number.isFinite))return 'Scegli un bersaglio valido';
  if(h.target==='enemy'&&(!heroSoldier(target)||!areEnemies(t,target.team)||!heroVisible(t,target)))return 'Scegli un soldato nemico visibile';
  if(h.target==='siege'&&(target.team!==t||target.d.cls!=='treb'||target.d.hero))return 'Scegli una tua macchina d’assedio';
  if(hyp(target.x-u.x,target.y-u.y)>h.range||!heroClear(u,target))return 'Bersaglio fuori portata o coperto';
  if(h.fac===5&&(target.heroRootImmuneUntil||0)>G.t)return 'Bersaglio temporaneamente immune';
  if(h.fac===7&&(target.heroClusterUntil||0)>G.t)return 'Munizione già preparata';}
 if(h.fac===0){if(teams[t].popUsed+3>teams[t].popMax)return 'Servono 3 posti popolazione';if(heroSpawnSpots(u).length<3)return 'Spazio insufficiente per i rinforzi';}
 if(h.fac===6&&!heroEnemies(u,h.range).some(e=>!e.d.hero&&['inf','cav'].includes(e.d.cls)&&!(e.heroTauntImmuneUntil>G.t)))return 'Nessun nemico provocabile vicino';return null;}
function useHeroAbility(t,id,targetId=null){if(isClient()||!Number.isInteger(id)||id<1||targetId!=null&&(!Number.isInteger(targetId)||targetId<1))return false;const u=units.find(e=>e.id===id),target=targetId==null?null:units.find(e=>e.id===targetId);if(heroAbilityBlock(t,u,target))return false;const h=heroMeta(u);u.heroReadyAt=G.t+h.cd;markStrike(u);
 switch(h.fac){case 0:for(const p of heroSpawnSpots(u)){const v=mkUnit(t,'inf',p.x,p.y,{temporaryUntil:G.t+18});v.wave=u.wave;v.aiExpedition=u.aiExpedition;if(u.tgt&&!u.tgt.dead)orderAttack([v],u.tgt);}break;
 case 1:u.heroCast={kind:'sweep',at:G.t+.6,x:u.x,y:u.y};u.mv=false;break;
 case 3:u.heroParryUntil=G.t+4;u.heroParryN=2;break;
 case 4:{const dx=target.x-u.x,dy=target.y-u.y,L=hyp(dx,dy)||1;const hit=heroEnemies(u,h.range).map(e=>({e,along:((e.x-u.x)*dx+(e.y-u.y)*dy)/L,across:Math.abs((e.x-u.x)*dy-(e.y-u.y)*dx)/L})).filter(v=>v.along>0&&v.across<=16+v.e.d.r).sort((a,b)=>a.along-b.along||a.e.id-b.e.id).slice(0,2);
  for(const {e} of hit){damage(t,e,35,'m',false,u);if(!e.dead&&!(e.heroStunImmuneUntil>G.t)){e.heroStunUntil=G.t+1;e.heroStunImmuneUntil=G.t+6;e.cd=Math.max(e.cd,1);}}break;}
 case 5:clearCombatResponse(u);u.heroCast={kind:'pin',at:G.t+1,x:u.x,y:u.y,target};u.order=null;u.tgt=null;u.palaceAttack=null;u.focus=false;u.mv=false;break;
 case 6:for(const e of heroEnemies(u,h.range).filter(e=>!e.d.hero&&['inf','cav'].includes(e.d.cls)&&!(e.heroTauntImmuneUntil>G.t)).slice(0,3)){
  e.heroTaunt={source:u,until:G.t+3,order:e.order,tgt:e.tgt,focus:e.focus,anchor:e.anchor,palaceAttack:e.palaceAttack,hold:e.hold,reaction:e.reaction};e.heroTauntUntil=G.t+3;e.heroTauntImmuneUntil=G.t+8;orderAttack([e],u);}break;
 case 7:target.heroClusterUntil=G.t+10;break;}
 return true;}
function heroCancelControl(u){if(u.heroTaunt){u.heroTaunt=null;u.heroTauntUntil=0;u.heroTauntImmuneUntil=G.t+5;}if(u.heroCast?.kind==='pin')u.heroCast=null;}
function heroCanMove(u){return !(u.heroRootUntil>G.t)&&!(u.heroStunUntil>G.t);}
function heroRestoreOrder(u){const a=u.heroTaunt;if(!a)return;u.heroTaunt=null;u.heroTauntUntil=0;u.heroTauntImmuneUntil=Math.max(u.heroTauntImmuneUntil||0,G.t+5);u.order=a.order;u.tgt=a.tgt&&!a.tgt.dead&&areEnemies(u.team,a.tgt.team)?a.tgt:null;u.palaceAttack=a.palaceAttack||null;u.focus=!!(u.tgt&&a.focus);u.anchor=a.anchor;u.hold=!!a.hold;u.reaction=a.reaction||null;u.path=null;
 if(u.palaceAttack?.guard&&!u.palaceAttack.guard.palaceIntercept)u.palaceAttack.guard.palaceIntercept=u;
 if(u.reaction?.helper){const t=u.reaction.target;if(!t.responseHelpers)t.responseHelpers=new Set();const n=[...t.responseHelpers].filter(e=>!e.dead&&e.reaction?.target===t&&areAllies(e.team,u.team)).length;if(n>=RESPONSE_HELPERS)finishResponse(u);else t.responseHelpers.add(u);}}
function heroEcho(u,target){u.heroEcho={target,at:G.t+.28,dmg:targetAttackDamage(attackPower(u,teams[u.team].S[u.type]),target)};}
function heroTick(u,dt){if(isClient())return false;if(u.temporaryUntil&&G.t>=u.temporaryUntil){killUnit(u,null);return true;}
 if(u.heroTaunt){const a=u.heroTaunt;if(G.t>=a.until||a.source.dead||!areEnemies(u.team,a.source.team))heroRestoreOrder(u);else{u.tgt=a.source;u.focus=true;u.order=null;}}
 if(u.heroStunUntil>G.t){u.mv=false;u.movedT=0;return true;}
 const e=u.heroEcho;if(e&&G.t>=e.at){u.heroEcho=null;const t=e.target;if(!u.dead&&!t.dead&&areEnemies(u.team,t.team)&&distTo(u,t)<=teams[u.team].S[u.type].rng+(t.isB?3:t.d.r)+u.d.r*.5+12&&heroClear(u,t)){markStrike(u);damage(u.team,t,e.dmg,'m',false,u);}}
 const cast=u.heroCast;if(!cast)return false;
 if(cast.kind==='pin'&&(u.order||hyp(u.x-cast.x,u.y-cast.y)>.5)){u.heroCast=null;return false;}
 if(G.t<cast.at){u.mv=false;u.movedT=0;return true;}u.heroCast=null;markStrike(u);
 if(cast.kind==='sweep'){for(const t of heroEnemies(u,64).slice(0,4))damage(u.team,t,30,'m',false,u);}
 else{const t=cast.target;if(heroSoldier(t)&&areEnemies(u.team,t.team)&&heroVisible(u.team,t)&&hyp(t.x-u.x,t.y-u.y)<=260&&heroClear(u,t))heroBolt(u,t,30,{heroPin:true});}return false;}
function heroBolt(u,t,dmg,extra={}){addProj({k:'b',x0:u.x,y0:u.y-12,x1:t.x,y1:t.y-9,t:0,dur:Math.max(.15,hyp(t.x-u.x,t.y-u.y)/440),tgt:t,dmg,crit:false,team:u.team,att:u,pierce:0,fire:0,normal:false,...extra});}
function heroLineBehind(u,t,r=64){const dx=t.x-u.x,dy=t.y-u.y,L=hyp(dx,dy)||1;return units.filter(e=>heroSoldier(e)&&e!==t&&areEnemies(u.team,e.team)&&heroVisible(u.team,e)&&los(u.team,t.x,t.y,e.x,e.y)).map(e=>({e,along:((e.x-t.x)*dx+(e.y-t.y)*dy)/L,across:Math.abs((e.x-t.x)*dy-(e.y-t.y)*dx)/L})).filter(x=>x.along>0&&x.along<=r&&x.across<=16).sort((a,b)=>a.along-b.along||a.e.id-b.e.id)[0]?.e;}
function heroOnNormalAttack(u,t,S){if(u.heroExtraReady){u.heroExtraReady=false;heroEcho(u,t);}const h=heroMeta(u);if(!h)return;
 if(h.fac===1)u.heroCharged=u.movedT>=1.2;
 if(h.fac===5){u.heroCount=((u.heroCount||0)+1)%3;u.heroPiercePending=!u.heroCount;}
 if(h.fac===3&&u.heroLastTarget!==t.id){u.heroLastTarget=t.id;u.heroCount=0;}}
function heroBeforeDamage(attTeam,tgt,raw,kind,att,opts={}){if(!tgt.isB&&tgt.type==='hero_na'&&kind==='m'&&opts.normal&&att&&!att.isB&&tgt.heroParryUntil>G.t&&tgt.heroParryN>0){
  tgt.heroParryN--;tgt.blockedShotSeq=(tgt.blockedShotSeq||0)+1;if(!att.dead&&distTo(tgt,att)<=teams[tgt.team].S[tgt.type].rng+att.d.r+tgt.d.r*.5+12&&heroClear(tgt,att)){markStrike(tgt);damage(tgt.team,att,16,'m',false,tgt);}return null;}
 if(!tgt.isB&&kind==='r'&&tgt.d.cls==='xb'&&!opts.heroRedirect){const guard=units.filter(e=>!e.dead&&e.team===tgt.team&&e.type==='hero_mi'&&!(e.heroInterceptAt>G.t)&&hyp(e.x-tgt.x,e.y-tgt.y)<=96&&heroClear(e,tgt)).sort((a,b)=>hyp(a.x-tgt.x,a.y-tgt.y)-hyp(b.x-tgt.x,b.y-tgt.y)||a.id-b.id)[0];
  if(guard){guard.heroInterceptAt=G.t+6;tgt.blockedShotSeq=(tgt.blockedShotSeq||0)+1;damage(attTeam,guard,raw,kind,false,att,{...opts,heroRedirect:true});return null;}}
 return raw;}
function heroAfterDamage(attTeam,tgt,applied,kind,att,opts={}){if(!att||att.dead||!opts.normal||!(applied>0)||att.temporaryUntil)return;const h=heroMeta(att);if(!h)return;
 switch(h.fac){case 0:att.heroCount=((att.heroCount||0)+1)%4;if(!att.heroCount){const soldier=units.filter(u=>!u.dead&&u.team===att.team&&!u.d.hero&&u.d.cls==='inf'&&!u.heroExtraReady&&hyp(u.x-att.x,u.y-att.y)<=96).sort((a,b)=>hyp(a.x-att.x,a.y-att.y)-hyp(b.x-att.x,b.y-att.y)||a.id-b.id)[0];if(soldier)soldier.heroExtraReady=true;}break;
 case 1:if(att.heroCharged&&!tgt.isB){att.heroCharged=false;const e=heroLineBehind(att,tgt,32);if(e)damage(attTeam,e,targetAttackDamage(attackPower(att,teams[att.team].S[att.type]),e),'m',false,att);}break;
 case 3:if(att.heroLastTarget!==tgt.id){att.heroLastTarget=tgt.id;att.heroCount=0;}att.heroCount=((att.heroCount||0)+1)%3;if(!att.heroCount&&!tgt.dead)heroEcho(att,tgt);break;
 case 7:att.heroCount=((att.heroCount||0)+1)%4;if(!att.heroCount){const siege=units.filter(u=>!u.dead&&u.team===att.team&&u.d.cls==='treb'&&hyp(u.x-att.x,u.y-att.y)<=128).sort((a,b)=>hyp(a.x-att.x,a.y-att.y)-hyp(b.x-att.x,b.y-att.y)||a.id-b.id)[0];if(siege)siege.cd=Math.max(0,siege.cd-1);}break;}}
function heroOnDeath(u,by,att){if(u.d.hero&&isPlayerTeam(u.team))teams[u.team].heroReviveAt=G.t+60;
 if(u.temporaryUntil||!att||att.dead||att.temporaryUntil||att.type!=='hero_ro'||!areEnemies(att.team,u.team))return;
 const allies=units.filter(e=>heroSoldier(e)&&e!==att&&e.team===att.team&&e.hp<e.max&&hyp(e.x-att.x,e.y-att.y)<=96).sort((a,b)=>a.hp/a.max-b.hp/b.max||a.id-b.id);for(const e of allies.slice(0,3))e.hp=Math.min(e.max,e.hp+6);}
function heroOnProjectileLaunch(p){if(!p.normal||!p.att||p.att.dead)return;if(p.k==='s'&&p.att.heroClusterUntil>G.t){p.heroCluster=true;p.att.heroClusterUntil=0;}
 if(p.k==='b'&&p.att.heroPiercePending){p.heroPierce=true;p.att.heroPiercePending=false;}}
function heroOnProjectileImpact(p,t){if(p.heroPierce&&t&&!t.isB&&p.att){const e=heroLineBehind({team:p.team,x:p.x0,y:p.y0+9},t,96);if(e)heroBolt(p.att,e,teams[p.team].S[p.att.type].dmg);}
 if(p.heroPin&&t&&!t.dead&&!(t.heroRootImmuneUntil>G.t)){t.heroRootUntil=G.t+2;t.heroRootImmuneUntil=G.t+7;}
 if(p.heroCluster&&p.att){const struck=bAt[cellI(p.x1,p.y1)],targets=units.filter(e=>heroSoldier(e)&&areEnemies(p.team,e.team)&&hyp(e.x-p.x1,e.y-p.y1)<=64&&heroVisible(p.team,e)&&los(p.team,p.x1,p.y1,e.x,e.y,struck)).sort((a,b)=>hyp(a.x-p.x1,a.y-p.y1)-hyp(b.x-p.x1,b.y-p.y1)||a.id-b.id);
  for(const e of targets.slice(0,3))addProj({k:'s',single:true,x0:p.x1,y0:p.y1-9,x1:e.x,y1:e.y-9,t:0,dur:.25,tgt:e,dmg:12,bdmg:0,crit:false,team:p.team,att:p.att,pierce:0,fire:0,normal:false});}}
// Solo stato pubblico numerico. Gli oggetti bersaglio e gli ordini precedenti restano all'host.
const HERO_NET_LIMITS=[600,2,10,20,40,2,30,200,3,1,100,60,10,70,80,60];
function heroNetState(u){const left=(at,max)=>Math.min(max,Math.max(0,Math.ceil(((at||0)-G.t)*10-1e-7)));const row=[left(u.heroReadyAt,600),u.heroCast?(u.heroCast.kind==='sweep'?1:2):0,u.heroCast?Math.max(1,left(u.heroCast.at,10)):0,left(u.heroRootUntil,20),left(u.heroParryUntil,40),u.heroParryUntil>G.t?u.heroParryN||0:0,left(u.heroTauntUntil,30),left(u.temporaryUntil,200),u.heroCount||0,u.heroExtraReady?1:0,left(u.heroClusterUntil,100),left(u.heroInterceptAt,60),left(u.heroStunUntil,10),left(u.heroRootImmuneUntil,70),left(u.heroTauntImmuneUntil,80),left(u.heroStunImmuneUntil,60)];return u.d.hero||row.some(Boolean)?row:null;}
function heroValidNetState(row){return Array.isArray(row)&&row.length===HERO_NET_LIMITS.length&&row.every((v,i)=>Number.isInteger(v)&&v>=0&&v<=HERO_NET_LIMITS[i])&&(row[1]===0)===(row[2]===0);}
function heroApplyNetState(u,row){row=row||HERO_NET_LIMITS.map(()=>0);const until=i=>row[i]?G.t+row[i]/10:0;u.heroReadyAt=until(0);u.heroCast=row[1]?{kind:row[1]===1?'sweep':'pin',at:until(2)}:null;u.heroRootUntil=until(3);u.heroParryUntil=until(4);u.heroParryN=row[5];u.heroTauntUntil=until(6);u.temporaryUntil=until(7);u.heroCount=row[8];u.heroExtraReady=!!row[9];u.heroClusterUntil=until(10);u.heroInterceptAt=until(11);u.heroStunUntil=until(12);u.heroRootImmuneUntil=until(13);u.heroTauntImmuneUntil=until(14);u.heroStunImmuneUntil=until(15);}
