'use strict';
// ===================== costanti e utilità =====================
const CELL=32,GW=150,WW=GW*CELL,TAU=Math.PI*2;
let GH=100,WH=GH*CELL;
const UP_INT=120; // secondi tra un potenziamento garantito e l'altro
let SEED=1;
function srand(s){SEED=(Math.abs(Math.floor(s))%2147483646)+1;}
function rnd(){SEED=(SEED*16807)%2147483647;return (SEED-1)/2147483646;}
const R=(a,b)=>a+rnd()*(b-a), RI=(a,b)=>Math.floor(a+rnd()*(b-a+1));
const MR=(a,b)=>a+Math.random()*(b-a);
const clamp=(v,a,b)=>v<a?a:v>b?b:v;
const hyp=Math.hypot;
function hash2(x,y){let h=(Math.imul(x|0,374761393)+Math.imul(y|0,668265263))|0;h=Math.imul(h^(h>>>13),1274126177);h^=h>>>16;return (h>>>0)/4294967296;}
function rr(g,x,y,w,h,r){r=Math.max(0,Math.min(r,w/2,h/2));g.beginPath();g.moveTo(x+r,y);g.arcTo(x+w,y,x+w,y+h,r);g.arcTo(x+w,y+h,x,y+h,r);g.arcTo(x,y+h,x,y,r);g.arcTo(x,y,x+w,y,r);g.closePath();}
function ell(g,x,y,rx,ry,rot){g.beginPath();g.ellipse(x,y,Math.max(.01,rx),Math.max(.01,ry),rot||0,0,TAU);}
function shade(hex,f){let n=parseInt(hex.slice(1),16),r=n>>16,g=n>>8&255,b=n&255;const t=f<0?0:255,p=Math.abs(f);
  r=Math.round((t-r)*p+r);g=Math.round((t-g)*p+g);b=Math.round((t-b)*p+b);return `rgb(${r},${g},${b})`;}
function fmt(n){n=Math.floor(n);return n>=100000?Math.round(n/1000)+'k':n>=10000?(n/1000).toFixed(1)+'k':String(n);}
function fmtT(s){s=Math.max(0,Math.floor(s));return Math.floor(s/60)+':'+String(s%60).padStart(2,'0');}
const cellI=(x,y)=>clamp(Math.floor(y/CELL),0,GH-1)*GW+clamp(Math.floor(x/CELL),0,GW-1);
const cX=i=>(i%GW+.5)*CELL, cY=i=>(Math.floor(i/GW)+.5)*CELL;
const inb=(x,y)=>x>=0&&y>=0&&x<GW&&y<GH;
function rectDist(x,y,b){const dx=Math.max(b.x0-x,0,x-(b.x0+b.w*CELL)),dy=Math.max(b.y0-y,0,y-(b.y0+b.h*CELL));return Math.hypot(dx,dy);}
function distTo(u,t){return t.isB?rectDist(u.x,u.y,t):hyp(t.x-u.x,t.y-u.y);}
function mkCanvas(w,h){const c=document.createElement('canvas');c.width=Math.ceil(w);c.height=Math.ceil(h);return c;}

// ===================== dati di gioco =====================
const RES=['g','l','p'],RESN={g:'Grano',l:'Legname',p:'Pietra'};
const GATHER={g:.72,l:.85,p:.55}; // unità al secondo per contadino
const CARRY=12;

const UT={
 worker:{n:'Contadino',hp:40,dmg:3,rng:10,cd:1.5,spd:56,aM:0,aR:0,sight:170,acq:0,r:6,pop:1,cost:{g:50},t:7,cls:'worker',bld:.3,glory:2,
   desc:'Raccoglie e costruisce da solo: tu decidi solo quanti su ogni risorsa.'},
 inf:{n:'Pavesaro',hp:110,dmg:8,rng:12,cd:1.2,spd:48,aM:2,aR:3,sight:200,acq:150,r:7,pop:1,cost:{g:45,l:20},t:10,cls:'inf',vs:{cav:1.75},bld:.5,glory:3,
   desc:'Fante col grande scudo. Robusto, forte contro la cavalleria.'},
 xb:{n:'Balestriere',hp:45,dmg:11,rng:230,cd:2.2,spd:48,aM:0,aR:1,sight:270,acq:250,r:6,pop:1,cost:{g:40,l:35},t:12,cls:'xb',ranged:true,vs:{inf:1.25},bld:.15,glory:3,
   desc:'Tira da lontano. Fragile se lo raggiungono.'},
 cav:{n:'Feditore',hp:150,dmg:12,rng:14,cd:1.3,spd:95,aM:2,aR:1,sight:260,acq:180,r:10,pop:1,cost:{g:80,l:40},t:13,cls:'cav',vs:{xb:1.8,worker:1.5,treb:2},bld:.4,glory:5,
   desc:'Cavaliere veloce: ottimo esploratore, distrugge i balestrieri.'},
 treb:{n:'Trabucco',hp:160,dmg:24,bdmg:170,rng:420,cd:6,spd:26,aM:1,aR:8,sight:300,acq:420,r:15,pop:3,cost:{l:150,p:120},t:28,cls:'treb',ranged:true,splash:48,bld:1,glory:10,
   desc:'Abbatte mura ed edifici da lontanissimo. Conta nel limite delle macchine d\'assedio.'},
 // unità speciali di fazione
 carr:{n:'Carroccio',hp:700,dmg:0,rng:0,cd:99,spd:30,aM:3,aR:6,sight:260,acq:0,r:17,pop:3,cost:{g:250,l:150},t:30,cls:'carr',glory:20,fac:[0],aura:230,
   desc:'Carro sacro: le truppe vicine fanno +15% danni e hanno +1 armatura. Uno solo.'},
 ted:{n:'Cavaliere Tedesco',hp:260,dmg:18,rng:14,cd:1.5,spd:82,aM:4,aR:3,sight:260,acq:180,r:11,pop:2,cost:{g:110,l:80,p:30},t:18,cls:'cav',vs:{xb:1.6,worker:1.5,treb:2},bld:.5,glory:8,fac:[1],art:'heavy',
   desc:'Cavalleria pesante di re Manfredi.'},
 ang:{n:'Cavaliere Angioino',hp:230,dmg:22,rng:14,cd:1.4,spd:88,aM:3,aR:3,sight:260,acq:190,r:11,pop:2,cost:{g:120,l:70,p:20},t:17,cls:'cav',vs:{xb:1.6,worker:1.5,treb:2,inf:1.2},bld:.5,glory:8,fac:[3],art:'heavy',
   desc:'Cavalleria francese di Carlo d\'Angiò: la carica più devastante d\'Italia.'},
 pike:{n:'Picchiere Lombardo',hp:150,dmg:9,rng:20,cd:1.3,spd:42,aM:3,aR:3,sight:200,acq:160,r:7,pop:1,cost:{g:55,l:25,p:5},t:11,cls:'inf',vs:{cav:2.6},bld:.5,glory:4,fac:[4],art:'pike',
   desc:'Muro di picche della Lega Lombarda: la cavalleria ci si infrange.'},
 xbe:{n:'Balestriere della Torre',hp:70,dmg:14,rng:275,cd:2.1,spd:46,aM:1,aR:3,sight:300,acq:295,r:6,pop:1,cost:{g:50,l:50,p:10},t:14,cls:'xb',ranged:true,vs:{inf:1.25},bld:.2,glory:4,fac:[5],art:'xbe',
   desc:'Tiratori scelti delle mura di Lucca: più gittata e più resistenti.'},
 guard:{n:'Guardia Pontificia',hp:170,dmg:12,rng:12,cd:1.2,spd:46,aM:4,aR:4,sight:220,acq:160,r:7,pop:1,cost:{g:70,l:30,p:15},t:13,cls:'inf',vs:{cav:1.5},bld:.6,glory:5,fac:[6],art:'guard',regen:1.5,
   desc:'Fanteria scelta del Papa: corazzata e instancabile (si cura da sola).'},
 mang:{n:'Mangano',hp:110,dmg:16,bdmg:110,rng:360,cd:3.4,spd:34,aM:1,aR:6,sight:280,acq:360,r:13,pop:2,cost:{l:110,p:70},t:18,cls:'treb',ranged:true,splash:44,bld:1,glory:7,fac:[7],art:'mang',
   desc:'Macchina d\'assedio degli ingegneri dello Studio: più leggera, tira quasi il doppio più spesso.'},
};
const BT={
 palazzo:{n:'Palazzo',w:4,h:3,hp:2400,sight:340,pop:10,atk:{rng:270,dmg:9,cd:1.6},train:['worker','carr'],drop:true,glory:0,desc:'Il cuore della città. Se cade, la partita è persa.'},
 casa:{n:'Casa',w:2,h:2,hp:420,cost:{l:30},t:18,pop:8,sight:150,key:'Z',glory:3,desc:'+8 popolazione massima.'},
 campo:{n:'Campo',w:3,h:3,hp:220,cost:{l:50},t:14,flat:true,sight:110,key:'X',glory:2,desc:'Ci coltivano il grano fino a 3 contadini.'},
 magaz:{n:'Magazzino',w:2,h:2,hp:600,cost:{l:100},t:22,drop:true,sight:180,key:'C',glory:4,desc:'Deposito per legname e pietra: mettilo vicino a boschi e cave.'},
 caserma:{n:'Caserma',w:3,h:3,hp:1200,cost:{l:150},t:38,train:['inf','xb','pike','xbe','guard'],sight:200,key:'V',glory:8,desc:'Addestra la fanteria e i balestrieri.'},
 scuderia:{n:'Scuderia',w:3,h:3,hp:1200,cost:{l:170,p:40},t:42,train:['cav','ted','ang'],sight:200,key:'B',glory:8,desc:'Addestra la cavalleria.'},
 officina:{n:'Officina',w:3,h:3,hp:1200,cost:{l:200,p:100},t:48,train:['treb','mang'],sight:200,key:'N',glory:8,desc:'Costruisce le macchine d\'assedio.'},
 torre:{n:'Torre',w:2,h:2,hp:950,cost:{l:50,p:120},t:42,atk:{rng:290,dmg:12,cd:1.7},sight:340,key:'M',glory:8,desc:'Tira dardi sui nemici che si avvicinano.'},
 mura:{n:'Mura',w:1,h:1,hp:520,cost:{p:5},t:5,wall:true,sight:100,key:'K',glory:1,desc:'Tieni premuto e trascina per tracciare una linea di mura.'},
 porta:{n:'Porta',w:1,h:1,hp:850,cost:{p:25},t:14,wall:true,gate:true,sight:120,key:'L',glory:2,desc:'Le tue truppe passano, i nemici no. Si può mettere sopra un tratto di mura.'},
};
const BUILD_LIST=['casa','campo','magaz','caserma','scuderia','officina','torre','mura','porta'];
// fazioni: pat = disegno della tunica (v striscia, h metà, x croce); arms = stemma; tower = torre del Palazzo
const FAC=[
 {name:'Firenze',sub:'Guelfi · città di mercanti',tunic:'#c8302c',tunic2:'#f1e7d0',cap:'#b02a24',helm:'#b8bec4',horse:'#7a5434',stone:'#d6cba9',roof:'#c2643c',house:'#e6dcc2',merlo:'g',mini:'#ff3b30',pat:'v',arms:'giglio',pen:'#c8302c',tower:{w:26,h:150,dx:30},
  perks:[['🌾','Arte della Lana','+10% grano e legname'],['💰','Fiorino d\'Oro','unità ed edifici costano il 10% in meno'],['🛡️','Popolo in Armi','Pavesari +15% vita'],['⭐','Carroccio','unità speciale: rafforza le truppe vicine']],
  apply:m=>{m.gather.g+=.1;m.gather.l+=.1;m.cost+=.1;m.hp.inf+=.15;}},
 {name:'Siena',sub:'Ghibellini · città fortezza',tunic:'#efe8d8',tunic2:'#1e1c1c',cap:'#262222',helm:'#7c838a',horse:'#3e2e22',stone:'#c98a5c',roof:'#a8532f',house:'#d9a77a',merlo:'s',mini:'#f6f2e8',pat:'h',arms:'balzana',pen:'#1e1c1c',tower:{w:18,h:225,dx:40},
  perks:[['⛰️','Argento di Montieri','+30% pietra · torri e mura costano il 25% in meno'],['👥','Contrade','+15% grano e +10% legname · contadini addestrati il 50% più in fretta · si parte con 3 contadini in più · fino a 60 contadini'],['🐎','Cavalleria di Manfredi','cavalleria +25% vita e +15% danno'],['⭐','Cavalieri Tedeschi','unità speciale: cavalleria pesante']],
  apply:m=>{m.gather.p+=.3;m.defCost+=.25;m.gather.g+=.15;m.gather.l+=.1;m.prodW+=.5;m.startW+=3;m.wCap+=10;m.hp.cav+=.25;m.dmg.cav+=.15;}},
 {name:'Briganti',sub:'',tunic:'#6b5a3a',tunic2:'#3e4a2a',cap:'#4a3a24',helm:'#6a6a60',horse:'#5a4030',stone:'#9a968a',roof:'#7a6a50',house:'#b0a080',merlo:'g',mini:'#d9a520',pat:'v',arms:'brig',pen:'#c9a227',tower:{w:22,h:120,dx:30}},
 {name:'Napoli',sub:'Regno di Carlo d\'Angiò · Guelfi',tunic:'#2a4a9a',tunic2:'#e8c34a',cap:'#1e3a7a',helm:'#c0c4c8',horse:'#6a4a30',stone:'#d9c48a',roof:'#35578a',house:'#ead9a6',merlo:'g',mini:'#3b7bff',pat:'v',arms:'angio',pen:'#2a4a9a',tower:{w:30,h:120,dx:44},
  perks:[['🌾','Campania Felix','+20% grano · fino a 55 contadini'],['👑','Baroni del Regno','ogni Casa dà 10 di popolazione invece di 8'],['⚔️','Cavalleria Francese','cavalleria +20% danno · il primo colpo dopo una corsa fa +25%'],['⭐','Cavalieri Angioini','unità speciale: carica devastante']],
  apply:m=>{m.gather.g+=.2;m.wCap+=5;m.housePop+=2;m.dmg.cav+=.2;m.charge+=.25;}},
 {name:'Milano',sub:'Lega Lombarda · Guelfi',tunic:'#f0ece0',tunic2:'#c02020',cap:'#c02020',helm:'#dfe3e8',horse:'#5a3a24',stone:'#b3b2a9',roof:'#a64f33',house:'#d8d4c5',merlo:'g',mini:'#ff9f1a',pat:'x',arms:'croce',pen:'#c02020',tower:{w:24,h:170,dx:-30},
  perks:[['🛡️','Armaioli Milanesi','tutte le unità +1 armatura (mischia e dardi)'],['⚔️','Comuni della Lega','fanteria -15% costo e addestrata il 25% più in fretta'],['🌾','Pianura Padana','+10% grano e legname'],['⭐','Picchieri Lombardi','unità speciale: muro di picche anti-cavalleria']],
  apply:m=>{m.aM.all+=1;m.aR.all+=1;m.infCost+=.15;m.prodInf+=.25;m.gather.g+=.1;m.gather.l+=.1;}},
 {name:'Lucca',sub:'Repubblica della seta · Guelfi',tunic:'#f0ece0',tunic2:'#c8302c',cap:'#a82424',helm:'#b8bec4',horse:'#6a4a2a',stone:'#aebeb5',roof:'#516d67',house:'#dce4d7',merlo:'g',mini:'#ff6ad5',pat:'h',arms:'lucca',pen:'#c8302c',tower:{w:24,h:140,dx:-34},
  perks:[['🏰','Mura Lucchesi','mura e porte gratis entro 8 celle dai propri edifici completati · torri +40% vita'],['🗽','Libertas','vicino ai tuoi edifici le tue unità fanno +15% danni e hanno +2 armatura'],['🧵','Mercanti della Seta','il Palazzo e ogni Magazzino producono +1 di ogni risorsa ogni 2 s'],['⭐','Balestrieri della Torre','unità speciale: tiratori scelti']],
  apply:m=>{m.freeWalls=1;m.wallHp+=.4;m.libertas=1;m.silk=1;}},
 {name:'Roma',sub:'Stato della Chiesa · Guelfi',tunic:'#8a1a2a',tunic2:'#e0b030',cap:'#e0b030',helm:'#d0c080',horse:'#5a3a2a',stone:'#e2dccb',roof:'#986b35',house:'#eadcbc',merlo:'g',mini:'#b05cff',pat:'v',arms:'roma',pen:'#e0b030',tower:{w:28,h:130,dx:36},
  perks:[['✝️','Crociata','ogni 6 minuti arrivano crociati gratis al Palazzo (un po\' di più ogni volta, fino a 8)'],['📿','Custodi delle Reliquie','vedi gli accampamenti sulla minimappa · ogni reliquia vale 2 potenziamenti'],['🏛️','Città Eterna','Palazzo +40% vita e 1 dardo in più'],['⭐','Guardia Pontificia','unità speciale: fanteria corazzata che si cura']],
  apply:m=>{m.crusade=1;m.relics=1;m.palace=1;}},
 {name:'Bologna',sub:'La Dotta · città delle cento torri',tunic:'#2f5ea8',tunic2:'#f0ece0',cap:'#c8302c',helm:'#b8bec4',horse:'#6a4a30',stone:'#a35345',roof:'#643e38',house:'#c78065',merlo:'g',mini:'#2ee6d6',pat:'x',arms:'bologna',pen:'#c8302c',tower:{w:20,h:240,dx:-42},
  perks:[['📚','Studio di Bologna','tre potenziamenti offerti · +2 rimescolamenti'],['🗼','Cento Torri','torri e mura -30% costo · torri +20% danno'],['🧱','Mattoni Rossi','+20% pietra e legname'],['⭐','Mangano','unità speciale: assedio leggero e rapido']],
  apply:(m,T)=>{T.rerolls+=2;m.defCost+=.3;m.tower+=.2;m.gather.p+=.2;m.gather.l+=.2;}},

];
const PLAY_FACS=[0,1,3,4,5,6,7];
const facOk=(f,fac)=>f==null||(Array.isArray(f)?f.includes(fac):f===fac);
const DIFF=[
 {n:'Facile',gather:.75,first:560,int:260,maxW:30,minArmy:8,startW:0},
 {n:'Normale',gather:1,first:400,int:210,maxW:42,minArmy:12,startW:0},
 {n:'Difficile',gather:1.3,first:290,int:170,maxW:54,minArmy:14,startW:3},
];

// ===================== stato =====================
// ME = la squadra di chi gioca su questo PC; NET = connessione online (null in partita da solo)
let ME=0,NET=null;
const isHost=()=>!!(NET&&NET.role==='host'),isClient=()=>!!(NET&&NET.role==='client');
const isHuman=t=>!!G&&isActivePlayer(t)&&(G.mp?!isAIControlled(t):(t===0&&!G.auto));
function emit(ev){if(NET&&NET.role==='host'&&NET.open&&NET.ev.length<2048)NET.ev.push(ev);}
function notify(t,k,...a){if(!isPlayerTeam(t))return;if(t===ME){if(!(G&&G.auto))applyNote(k,a);}else if(isHost())emit(['n',t,k,a]);}
function applyNote(k,a){if(k==='toast')toast(a[0],a[1],a[2]);else if(k==='sfx')sfx(a[0]);else if(k==='ping')pings.push({x:a[0],y:a[1],t:0});else if(k==='flash')flash();}
let G=null,teams=[],units=[],blds=[],projs=[],parts=[],floats=[],decals=[],camps=[],pings=[],AIS=[],nextId=1;
// Gli indici dei giocatori sono distinti dall'indice della fazione Briganti (sempre 2).
function playerCount(){const n=G&&G.playerCount;return n===3||n===4||n===6||n===8||n===10?n:2;}
function playerIds(){return Array.from({length:playerCount()},(_,t)=>t);}
function neutralTeam(){return playerCount();}
function isPlayerTeam(t){return Number.isInteger(t)&&t>=0&&t<playerCount();}
function isActivePlayer(t){return isPlayerTeam(t)&&!!teams[t]&&!teams[t].eliminated;}
function isAIControlled(t){return !!G&&(!!G.aiTeams?.[t]||t===1&&!!G.aiTakeover);}
// L'alleanza non trasferisce proprietà e resta valida quando un alleato è eliminato.
function isTeamMatch(){return !!G&&(G.mode==='coop'||G.mode==='teams');}
function sideOf(t){if(!Number.isInteger(t)||t<0||t>neutralTeam())return null;if(t===neutralTeam())return -1;
 return isTeamMatch()?(G.sides?.[t]??Math.floor(t/(playerCount()/2))):t;}
function areAllies(a,b){const side=sideOf(a);return side!==null&&side===sideOf(b);}
function areEnemies(a,b){const sa=sideOf(a),sb=sideOf(b);return sa!==null&&sb!==null&&sa!==sb;}

const PERSONAL_CARD_IDS=["compagnie_popolo","botteghe_balestrai","mezzadria","logge_mercanti","gonfalone","fiorino","contrade","manfredi","comunita_contado","guardia_balzana","ingegneri_ghibellini","montieri","granai_regno","scuderie_reali","fedelta_baroni","fondachi_porto","bottino_guerra","genieri_angioini","armaioli_picche","carri_lombardi","maestri_citta","compagnie_balestriere","milizie_lega","arsenale_lombardo","tiro_torri","scorte_assedio","strade_mercanti","capitale_seta","guarnigione_cittadina","custodi_cerchia","custodi_laterano","ordini_equestri","decime_patrimonio","ospizi_pellegrini","colonie_pellegrini","fuoco_milizie","studio_applicato","officine_studio","vedette_torri","compagnie_arti","scuola_tiro","confraternite_urbane"];
function baseMods(){const z=()=>({worker:0,inf:0,xb:0,cav:0,treb:0,carr:0,all:0});
 return {flatHp:z(),flatDmg:z(),flatSpd:z(),flatRange:z(),flatRate:z(),delivery:{g:0,l:0,p:0},card:Object.fromEntries(PERSONAL_CARD_IDS.map(id=>[id,0])),flatSiege:0,flatTower:0,flatWall:0,flatCost:0,flatDefCost:0,flatXbCost:0,flatVsCav:0,flatVsXb:0,flatShield:0,flatCharge:0,flatGlory:0,towerReload:0,towerCross:0,hp:z(),dmg:z(),spd:z(),rng:z(),rate:z(),aM:z(),aR:z(),regen:z(),extraBolt:0,doubleHit:0,splitBolt:0,pierceLine:0,brace:0,cleave:0,bodyguard:0,xbDeploy:0,cavalryTrample:0,medicAura:0,siegeShrapnel:0,pavise:0,gather:{g:0,l:0,p:0},
  carry:0,pop:0,build:0,prod:0,cost:0,xbCost:0,fair:0,interest:0,freeW:0,loot:0,bLoot:0,vsCav:0,vsXb:0,shieldWall:0,levy:0,
  pierce:0,fire:0,charge:0,lifesteal:0,tower:0,arrows:0,wallHp:0,wallRegen:0,sight:0,siegeMax:0,glory:0,cards:3,mart:0,fury:0,
  carrAura:0,tedBonus:0,contrade:0,cyclop:0,prodW:0,farmCap:0,farmBonus:0,defCost:0,startW:0,infCost:0,prodInf:0,bldCost:0,housePop:0,freeWalls:0,libertas:0,silk:0,crusade:0,relics:0,palace:0,wCap:50};}
function mkTeam(i,fac){return{i,fac,eliminated:false,cardCooldowns:{martinella:0,spesse:0},cardProgress:{},reinforcementQueue:[],res:{g:220,l:220,p:120},popUsed:0,popMax:10,mods:baseMods(),ups:{},tagN:{},S:{},picks:[],
  glory:0,gloryNeed:70,upT:UP_INT,jobs:{g:4,l:2,p:0},newJob:'g',noFarm:false,alertT:-99,kills:0,lost:0,made:0,gath:{g:0,l:0,p:0},
  tm:{fair:30,int:20,freeW:50,levy:60,contrade:80,crusade:360,crusadeN:0},martT:0,martCd:0,furyK:[],rerolls:2,pity:0,aiMul:1,home:null,carr:null,upsTaken:0,offer:null,offerSeq:0};}

function costOf(t,key,isB){const base=(isB?BT[key]:UT[key]).cost||{};const m=teams[t].mods;let k=1-m.cost;
 if(isB&&preparationBuilding(t,key))return {};
 if(isB&&m.freeWalls&&(key==='mura'||key==='porta'))return {};
 if(isB){k-=m.bldCost;if(key==='torre'||key==='mura'||key==='porta')k-=m.defCost;}
 else{if(UT[key].cls==='xb')k-=m.xbCost;if(UT[key].cls==='inf')k-=m.infCost;}
 const flat=m.flatCost+(isB&&["torre","mura","porta"].includes(key)?m.flatDefCost:!isB&&UT[key].cls==='xb'?m.flatXbCost:0);const o={};for(const r in base)o[r]=Math.max(1,Math.ceil(base[r]*Math.max(.4,k))-flat);return o;}
function canAfford(t,c){const r=teams[t].res;for(const k in c)if(r[k]<c[k])return false;return true;}
function pay(t,c){const r=teams[t].res;for(const k in c)r[k]-=c[k];}
function refund(t,c){const r=teams[t].res;for(const k in c)r[k]+=c[k];}
