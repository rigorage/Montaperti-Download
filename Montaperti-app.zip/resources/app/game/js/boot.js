'use strict';
// Diagnostica visibile anche quando il resto del gioco non riesce a inizializzarsi.
window.MontapertiBoot=(()=>{
 let ready=false,failed=false;
 function fail(message,error){if(failed)return;failed=true;const box=document.getElementById('bootError'),msg=document.getElementById('bootErrorMsg');
  if(msg)msg.textContent=message+(error&&error.message?' Dettaglio: '+error.message:'');
  if(box)box.classList.remove('hidden');if(error)console.error('Montaperti',error);
 }
 window.addEventListener('error',e=>{if(e.target&&e.target.tagName==='SCRIPT')return; // Il caricamento online ha una propria diagnostica e può essere ritentato.
  if(e.error)fail(ready?'Il gioco ha incontrato un errore. Ricarica per iniziare una nuova partita.':'Il gioco non è riuscito ad avviarsi. Estrai lo ZIP e apri index.html in un browser aggiornato.',e.error);},true);
 window.addEventListener('unhandledrejection',e=>fail('Un’operazione non è riuscita. Ricarica e riprova.',e.reason));
 window.addEventListener('DOMContentLoaded',()=>{const b=document.getElementById('bootReload');if(b)b.onclick=()=>location.reload();if(!ready&&!failed)fail('Avvio incompleto. Estrai tutto lo ZIP e apri index.html in un browser aggiornato.');});
 return {fail,ready(){ready=true;}};
})();
