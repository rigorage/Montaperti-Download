'use strict';
// ===================== statistiche =====================
const CLS_TAG={inf:'FANTI',xb:'BALESTRE',cav:'CAVALLI',treb:'ASSEDIO'};
const TACTIC_CLASS={inf:1,xb:2,cav:4,treb:8,worker:16,carr:32};
const hasTactic=(u,key)=>!!(teams[u.team].mods[key]&TACTIC_CLASS[u.d.cls]);
function mastN(T,tag){return Math.floor((T.tagN[tag]||0)/3);}
function refreshStats(t){const T=teams[t],m=T.mods;const ea=mastN(T,'ESERCITO')*10;
 for(const k in UT){const d=UT[k],c=d.cls,ms=CLS_TAG[c]?mastN(T,CLS_TAG[c]):0,ex=k==='ted'?m.tedBonus:0;const rng=d.rng*(1+m.rng[c])+m.flatRange[c]+(k==='pike'&&m.card.maestri_citta?CELL:0);
  T.S[k]={hp:d.hp*(1+m.hp[c]+m.hp.all+ex)+m.flatHp[c]+m.flatHp.all+ea+(c==='cav'?ms*15:0),dmg:d.dmg>0?d.dmg*(1+m.dmg[c]+m.dmg.all+ex)+m.flatDmg[c]+m.flatDmg.all+(['inf','xb'].includes(c)?ms:0):0,bdmg:(d.bdmg||0)*(1+m.dmg[c]+m.dmg.all+ex)+(c==='treb'?m.flatSiege+m.flatDmg[c]+m.flatDmg.all+ms*10:0),rng,
   cd:Math.max(.3,d.cd/(1+m.rate[c]+m.rate.all)-m.flatRate[c]),spd:Math.min(UT.cav.spd,d.spd*(c==='cav'?1:1+m.spd[c]+m.spd.all)+(c==='cav'?0:m.flatSpd[c]+m.flatSpd.all)),aM:d.aM+m.aM[c]+m.aM.all,aR:d.aR+m.aR[c]+m.aR.all,sight:d.sight*(1+m.sight),
   acq:d.ranged?Math.max(d.acq,rng+25):d.acq,regen:(d.regen||0)+m.regen[c]+m.regen.all};}
 for(const u of units)if(u.team===t&&!u.dead){const nm=T.S[u.type].hp;if(Math.abs(nm-u.max)>.01){u.hp=u.hp*nm/u.max;u.max=nm;}}
 for(const b of blds)if(b.team===t&&!b.dead){const nm=bMaxHp(b);if(Math.abs(nm-b.max)>.01){b.hp=b.hp*nm/b.max;b.max=nm;}}
 recountPop(t);}
function bMaxHp(b){const m=teams[b.team].mods;let k=1;if(b.def.wall||b.kind==='torre')k+=m.wallHp+(m.cyclop?1:0);if(b.kind==='palazzo'&&m.palace)k+=.4;return b.def.hp*k+(b.def.wall||b.kind==='torre'?m.flatWall:0);}
function gatherRate(T,r){return GATHER[r]*(1+T.mods.gather[r])*T.aiMul;}
function recountPop(t){const T=teams[t];if(T.eliminated){T.popUsed=0;T.popMax=0;return;}let pu=0;for(const u of units)if(u.team===t&&!u.dead)pu+=u.d.pop;T.popUsed=pu;
 let pm=T.mods.pop;for(const b of blds)if(b.team===t&&!b.dead&&b.built&&b.def.pop)pm+=b.def.pop+(b.kind==='casa'?T.mods.housePop:0);T.popMax=Math.min(300,pm);}
// zona "di casa" (Libertas di Lucca): celle vicine ai propri edifici
const homeZ=[];
function homeZone(t){return homeZ[t]||(homeZ[t]=new Uint8Array(NCELL));}
function updHomeZ(t){const z=homeZone(t);z.fill(0);if(!teams[t].mods.libertas)return;const R=8;
 for(const b of blds){if(b.dead||b.team!==t||b.def.wall||!b.built)continue;for(let y=b.cy-R;y<b.cy+b.h+R;y++)for(let x=b.cx-R;x<b.cx+b.w+R;x++)if(inb(x,y))z[y*GW+x]=1;}}
const atHome=u=>isActivePlayer(u.team)&&teams[u.team].mods.libertas&&homeZone(u.team)[cellI(u.x,u.y)]===1;

// ===================== griglia spaziale =====================
const HC=64,HW=Math.ceil(WW/HC);let HH=Math.ceil(WH/HC),hb=Array.from({length:HW*HH},()=>[]);
function resizeSimGrid(){HH=Math.ceil(WH/HC);hb=Array.from({length:HW*HH},()=>[]);resClaim=new Uint8Array(NCELL);
 vis=new Uint8Array(NCELL);exp=new Uint8Array(NCELL);fogA=new Float32Array(NCELL).fill(1);fogC=fogX=fogI=null;homeZ.length=0;workerAccessCache.length=0;}
function rebuildHash(){for(const b of hb)b.length=0;for(const u of units){if(u.dead)continue;hb[clamp((u.y/HC)|0,0,HH-1)*HW+clamp((u.x/HC)|0,0,HW-1)].push(u);}}
function forNear(x,y,r,fn){const x0=clamp(((x-r)/HC)|0,0,HW-1),x1=clamp(((x+r)/HC)|0,0,HW-1),y0=clamp(((y-r)/HC)|0,0,HH-1),y1=clamp(((y+r)/HC)|0,0,HH-1);
 for(let cy=y0;cy<=y1;cy++)for(let cx=x0;cx<=x1;cx++){const a=hb[cy*HW+cx];for(let i=0;i<a.length;i++)fn(a[i]);}}

// ===================== creazione =====================
function mkUnit(t,type,x,y,opts={}){if(isPlayerTeam(t)&&!isActivePlayer(t))return null;const S=teams[t].S[type];const u={id:nextId++,team:t,type,d:UT[type],x,y,hp:S.hp,max:S.hp,f:t===1?-1:1,cd:Math.random(),scan:Math.random()*.4,
 an:Math.random()*4,atk:0,mv:false,hold:false,order:null,tgt:null,focus:false,anchor:null,path:null,pi:0,pathT:0,pathGoal:-1,losT:0,losOk:false,stuck:0,
 job:null,ws:'seek',rc:-1,carry:0,grainLoad:0,ct:null,build:null,campo:null,burn:0,burnD:0,burnBy:-1,movedT:0,lastHit:-99,lastAttack:-99,working:false,camp:null,wave:false,cardCounters:{attacks:0,shots:0,cavHits:0,vsCavShots:0,siegeShots:0},...opts};
 units.push(u);teams[t].popUsed+=u.d.pop;if(isPlayerTeam(t)&&!u.temporaryUntil)teams[t].made++;if(type==='carr')teams[t].carr=u;if(typeof heroOnSpawn==='function')heroOnSpawn(u);return u;}
function mkBld(t,kind,cx,cy,built){if(isPlayerTeam(t)&&!isActivePlayer(t))return null;const def=BT[kind];const b={id:nextId++,isB:true,team:t,kind,def,cx,cy,w:def.w,h:def.h,x0:cx*CELL,y0:cy*CELL,
 x:(cx+def.w/2)*CELL,y:(cy+def.h/2)*CELL,built:!!built,prog:built?1:0,hp:1,max:1,queue:[],rally:null,cd:1,builders:0,slots:[],seen:t===ME,smokeT:0,blocked:false};
 b.max=bMaxHp(b);b.hp=built?b.max:Math.max(1,b.max*.05);
 for(let y=cy;y<cy+def.h;y++)for(let x=cx;x<cx+def.w;x++){const i=y*GW+x;bAt[i]=b;decor[i]=0;stump[i]=0;}
 blds.push(b);gridVer++;if(kind==='palazzo')teams[t].home=b;if(built)recountPop(t);return b;}
// Le fortificazioni gratuite di Lucca difendono insediamenti già completati.
// Si legge lo stato attuale: un cantiere, una catena di mura o un alleato non estendono l'area.
function wallTerritory(t,cx,cy){return blds.some(b=>!b.dead&&b.team===t&&b.built&&!b.def.wall&&cx>=b.cx-8&&cx<b.cx+b.w+8&&cy>=b.cy-8&&cy<b.cy+b.h+8);}
function canPlace(t,kind,cx,cy){if(!isActivePlayer(t))return false;const d=BT[kind];
 if(preparationBuilding(t,kind)){const h=teams[t].home;if(!h||h.dead||!h.built||rectDist((cx+d.w/2)*CELL,(cy+d.h/2)*CELL,h)>8*CELL)return false;
  if(units.some(u=>!u.dead&&u.x+u.d.r>cx*CELL&&u.x-u.d.r<(cx+d.w)*CELL&&u.y+u.d.r>cy*CELL&&u.y-u.d.r<(cy+d.h)*CELL))return false;}
 if(d.wall&&teams[t].mods.freeWalls&&!wallTerritory(t,cx,cy))return false;
 for(let y=cy;y<cy+d.h;y++)for(let x=cx;x<cx+d.w;x++){if(!inb(x,y))return false;const i=y*GW+x;
  if(water[i]||tree[i]>0||stone[i]>0)return false;const o=bAt[i];if(o){if(kind==='porta'&&o.kind==='mura'&&o.team===t)continue;return false;}
  if(t===ME&&!exp[i]&&!G.setup&&!G.auto)return false;}
 // Anche mura e porte devono lasciare libera la futura guarnigione dei briganti.
 for(const c of camps)if(!c.conquered&&cx<c.cx+4&&cx+d.w>c.cx-3&&cy<c.cy+4&&cy+d.h>c.cy-3)return false;
 return true;}
function placeBld(t,kind,cx,cy,free){if(!isActivePlayer(t))return null;const prep=!free&&preparationBuilding(t,kind);
 if(prep&&!canPlace(t,kind,cx,cy))return null;const c=costOf(t,kind,true);if(!free){if(!canAfford(t,c))return null;pay(t,c);}
 if(kind==='porta'){const o=bAt[cy*GW+cx];if(o&&o.kind==='mura'){o.dead=true;bAt[cy*GW+cx]=null;}}
 const b=mkBld(t,kind,cx,cy,!!prep);b.paid=free?{}:c;if(prep){teams[t].cardProgress[prep]=1;notify(t,'toast',BT[kind].n+' gratuita pronta!','#ffe3a0',2500);}return b;}
// annulla un cantiere: rimborso completo
function cancelBld(b){if(!b||b.dead||b.built||!isActivePlayer(b.team))return false;refund(b.team,b.paid||{});b.dead=true;b.hp=0;
 for(let y=b.cy;y<b.cy+b.h;y++)for(let x=b.cx;x<b.cx+b.w;x++){const i=y*GW+x;if(bAt[i]===b)bAt[i]=null;}gridVer++;
 for(const u of units)if(u.build===b)u.build=null;return true;}
function onBuilt(b){if(b.built)return;b.built=true;b.prog=1;gridVer++;recountPop(b.team);
 cardOnPaidBuilding(b);
 if(!b.def.wall)notify(b.team,'sfx','built');if(!b.def.wall&&!b.def.flat)notify(b.team,'toast',BT[b.kind].n+' completat'+(b.kind==='torre'||b.kind==='casa'||b.kind==='caserma'||b.kind==='scuderia'||b.kind==='officina'?'a':'o'),'#c8f0b0',1200);}
function trebCount(t){let n=0;for(const u of units)if(!u.dead&&u.team===t&&u.d.cls==='treb')n++;for(const b of blds)if(b.team===t&&!b.dead)for(const q of b.queue)if(UT[q.type].cls==='treb')n++;return n;}
function carrCount(t){let n=0;for(const u of units)if(!u.dead&&u.team===t&&u.type==='carr')n++;for(const b of blds)if(b.team===t&&!b.dead)for(const q of b.queue)if(q.type==='carr')n++;return n;}
function trainBlock(t,b,type){if(!isActivePlayer(t))return 'Squadra eliminata';const T=teams[t],d=UT[type];if(!b||b.dead||b.team!==t||!d)return 'X';if(!b.built)return 'In costruzione';if(!b.def.train?.includes(type))return 'X';
 if(!facOk(d.fac,T.fac))return 'X';if(b.queue.length>=10)return 'Coda piena';
 if(typeof heroTrainBlock==='function'){const why=heroTrainBlock(t,b,type);if(why)return why;}
 if(type==='worker'&&workerCount(t,true)>=T.mods.wCap)return 'Massimo contadini ('+T.mods.wCap+')';
 if(d.cls==='treb'&&trebCount(t)>=2+T.mods.siegeMax)return 'Massimo macchine d\x27assedio';if(type==='carr'&&carrCount(t)>=1)return 'Già presente';
 if(!canAfford(t,costOf(t,type)))return 'Risorse insufficienti';return null;}
function train(t,b,type){if(trainBlock(t,b,type))return false;const c=costOf(t,type);pay(t,c);b.queue.push({type,t:0,total:UT[type].t,cost:c,paid:true});return true;}
function cancelTrain(b,k){if(!b||b.dead||!isActivePlayer(b.team))return;const q=b.queue[k];if(!q)return;refund(b.team,q.cost);b.queue.splice(k,1);}
function spawnFrom(b,type,free,opts={}){if(!b||b.dead||!isActivePlayer(b.team))return null;const T=teams[b.team];const rx=b.rally?b.rally.x:b.x+(b.team===1?-1:1)*60,ry=b.rally?b.rally.y:b.y+80;
 const gi=adjFree(b.team,b,rx,ry);if(gi<0)return null;const u=mkUnit(b.team,type,cX(gi)+MR(-5,5),cY(gi)+MR(-5,5),{...opts,free:!!free});
 if(b.rally&&type!=='worker')orderGroup([u],b.rally.x,b.rally.y,false);return u;}
function workerCount(t,q){let n=0;for(const u of units)if(!u.dead&&u.team===t&&u.type==='worker')n++;if(q)for(const b of blds)if(b.team===t&&!b.dead)for(const x of b.queue)if(x.type==='worker')n++;return n;}
function spawnNear(t,type,free,opts={}){if(!isActivePlayer(t))return null;const h=teams[t].home;if(!h||h.dead)return null;if(type==='worker'&&workerCount(t,true)>=teams[t].mods.wCap)return null;return spawnFrom(h,type,free,opts);}

// ===================== ordini =====================
const RANKF={inf:0,pike:0,guard:0,cav:1,ted:1,ang:1,worker:2,carr:3,xb:4,xbe:4,treb:5,mang:5};
function orderGroup(list,x,y,forced){list=list.filter(u=>!u.dead&&(!isPlayerTeam(u.team)||isActivePlayer(u.team)));if(!list.length)return;const team=list[0].team;let gi=nearestPass(team,cellI(clamp(x,1,WW-1),clamp(y,1,WH-1)));if(gi<0)return;
 const tx=cX(gi),ty=cY(gi);let cx=0,cy=0;for(const u of list){cx+=u.x;cy+=u.y;}cx/=list.length;cy/=list.length;
 let dx=tx-cx,dy=ty-cy;const L=hyp(dx,dy);if(L<1){dx=1;dy=0;}else{dx/=L;dy/=L;}const rx=-dy,ry=dx;
 const arr=list.slice().sort((a,b)=>RANKF[a.type]-RANKF[b.type]);const n=arr.length,cols=Math.max(1,Math.ceil(Math.sqrt(n*2.2)));const sp=22;
 arr.forEach((u,k)=>{const row=Math.floor(k/cols),col=k%cols,rowN=Math.min(cols,n-row*cols);const off=(col-(rowN-1)/2)*sp*(u.d.r>9?1.3:1);
  let ox=x+rx*off-dx*row*sp,oy=y+ry*off-dy*row*sp;if(n===1){ox=x;oy=y;}if(!passFor(team,cellI(ox,oy))){ox=tx;oy=ty;}
  clearCombatResponse(u);u.hold=false;u.order={x:ox,y:oy,gi,forced:!!forced,field:null};u.tgt=null;u.focus=false;u.anchor=null;u.path=null;u.stuck=0;u.losT=0;u.meleeApproach=null;});}
function orderAttack(list,target){if(!target||target.dead)return;for(const u of list){if(u.dead||!areEnemies(u.team,target.team)||isPlayerTeam(u.team)&&!isActivePlayer(u.team))continue;if(teams[u.team].S[u.type].dmg<=0){orderGroup([u],target.x,target.y,false);continue;}
 const same=u.palaceAttack?.target===target;clearCombatResponse(u,same);if(same)u.palaceAttack.focus=true;u.hold=false;u.tgt=same?u.palaceAttack.guard:target;u.focus=true;u.order=null;u.anchor=null;u.path=null;u.pathT=0;u.stuck=0;u.blockedTarget=null;u.meleeApproach=null;resolvePalaceAttack(u);}}
function orderStop(list){for(const u of list){if(u.dead||isPlayerTeam(u.team)&&!isActivePlayer(u.team))continue;clearCombatResponse(u);u.hold=false;u.order=null;u.tgt=null;u.focus=false;u.anchor=null;u.path=null;u.stuck=0;u.mv=false;u.movedT=0;}}
function orderHold(list){orderStop(list);for(const u of list)if(!u.dead&&(!isPlayerTeam(u.team)||isActivePlayer(u.team))){u.hold=true;u.anchor={x:u.x,y:u.y};}}

// ===================== movimento =====================
function tryMove(u,nx,ny){if(u.hold||typeof heroCanMove==='function'&&!heroCanMove(u))return false;nx=clamp(nx,4,WW-4);ny=clamp(ny,4,WH-4);
 const mx=Math.abs(nx-u.x)>1e-6,my=Math.abs(ny-u.y)>1e-6;if(!mx&&!my)return false;
 if(passFor(u.team,cellI(nx,ny))){u.x=nx;u.y=ny;return true;}
 if(mx&&passFor(u.team,cellI(nx,u.y))){u.x=nx;return true;}if(my&&passFor(u.team,cellI(u.x,ny))){u.y=ny;return true;}return false;}
function steer(u,tx,ty,spd,dt){const dx=tx-u.x,dy=ty-u.y,d=hyp(dx,dy);if(d<.5){u.mv=false;u.movedT=0;return;}
 let sp=Math.min(UT.cav.spd,spd);if(water[cellI(u.x,u.y)]===2)sp*=.6;const st=Math.min(d,sp*dt);
 const ox=u.x,oy=u.y;u.mv=tryMove(u,u.x+dx/d*st,u.y+dy/d*st);
 if(u.mv){u.stuck=Math.max(0,u.stuck-dt*2);u.movedT+=dt;u.an+=hyp(u.x-ox,u.y-oy)*.09;}else{u.stuck+=dt;u.movedT=0;}
 u.f=dx>=0?1:-1;}
function navTo(u,tx,ty,goal,spd,dt,waitIfBlocked=false){u.pathT-=dt;
 if(u.path===null||u.pathVer!==gridVer||u.pathGoal!==goal||u.pathT<=0||(u.stuck>.6&&G.t>=(u.pathRetryAt||0))){u.pathVer=gridVer;u.pathT=3+Math.random()*2;u.pathGoal=goal;u.pathRetryAt=G.t+.7;u.pi=0;
  u.navFail=false;if(los(u.team,u.x,u.y,tx,ty))u.path=[];else{u.path=astar(u.team,cellI(u.x,u.y),goal,5000)||[];u.navFail=!ASTAR_OK;}}
 if(u.pi<u.path.length){const c=u.path[u.pi],px=cX(c),py=cY(c);
  u.skipT=(u.skipT||0)-dt;if(u.skipT<=0&&u.pi+1<u.path.length){u.skipT=.25;const c2=u.path[u.pi+1];if(los(u.team,u.x,u.y,cX(c2),cY(c2)))u.pi++;}
  if(hyp(px-u.x,py-u.y)<9)u.pi++;steer(u,px,py,spd,dt);}
 else if(waitIfBlocked&&u.navFail){u.mv=false;u.movedT=0;}
 else steer(u,tx,ty,spd,dt);}
function unstick(u,dt){if(typeof heroCanMove==='function'&&!heroCanMove(u))return false;const i=cellI(u.x,u.y);if(passFor(u.team,i))return false;const n=nearestPass(u.team,i);if(n<0)return false;
 const dx=cX(n)-u.x,dy=cY(n)-u.y,d=hyp(dx,dy)||1;u.x+=dx/d*Math.min(d,90*dt);u.y+=dy/d*Math.min(d,90*dt);return true;}

// ===================== combattimento =====================
const PALACE_ARMOR=2,RESPONSE_RADIUS=240,RESPONSE_LEASH=240,RESPONSE_SECONDS=8,RESPONSE_HELPERS=4;
const combatSoldier=u=>!!u&&!u.isB&&!u.dead&&u.hp>0&&!['worker','carr'].includes(u.d.cls)&&teams[u.team].S[u.type].dmg>0;
function releasePalaceIntercept(u,restore=true){const a=u.palaceAttack;if(!a)return;if(a.guard?.palaceIntercept===u)a.guard.palaceIntercept=null;u.palaceAttack=null;
 if(restore){u.tgt=a.target&&!a.target.dead?a.target:null;u.focus=!!(u.tgt&&a.focus);u.path=null;u.stuck=0;}}
function clearCombatResponse(u,keepPalace=false){if(u.reaction?.target?.responseHelpers)u.reaction.target.responseHelpers.delete(u);u.reaction=null;u.responseCooldown=0;
 if(!keepPalace)releasePalaceIntercept(u,false);if(u.palaceIntercept){releasePalaceIntercept(u.palaceIntercept);u.palaceIntercept=null;}}
function palaceContact(u,g,b,extra=0){return combatSoldier(g)&&g.d.cls!=='treb'&&areAllies(g.team,b.team)&&areEnemies(u.team,g.team)&&!g.order?.forced&&!g.heroTaunt&&
 (!g.reaction||g.reaction.target===u)&&hyp(g.x-u.x,g.y-u.y)<=u.d.r+g.d.r+10+extra&&meleeLineClear(u,g)&&los(u.team,u.x,u.y,g.x,g.y)&&!targetBlocked(u,g);}
function bindPalaceIntercept(u,guard,b){u.palaceAttack={target:b,focus:u.focus,guard};guard.palaceIntercept=u;guard.tgt=u;guard.path=null;u.tgt=guard;u.focus=true;u.path=null;u.stuck=0;u.meleeApproach=null;}
// A real defender's melee hit can also stop an assailant on its approach.
// It cannot pull units at range, steal another duel or cancel a retreat.
function palaceHitIntercept(u,g){const b=u.tgt;if(u.palaceAttack||u.d.ranged||!combatSoldier(u)||u.order?.forced||!b||b.kind!=='palazzo'||b.dead||!areEnemies(u.team,b.team)||!g||g.d.ranged)return;
 if(g.palaceIntercept&&(!g.palaceIntercept.palaceAttack||g.palaceIntercept.dead))g.palaceIntercept=null;
 if(g.palaceIntercept||!palaceContact(u,g,b)||g.tgt&&g.tgt!==u&&!g.tgt.dead)return;bindPalaceIntercept(u,g,b);}
function resolvePalaceAttack(u){let a=u.palaceAttack,b=a?.target||u.tgt;
 if(!b||b.dead||b.kind!=='palazzo'||!areEnemies(u.team,b.team)||u.d.ranged||!combatSoldier(u)||u.order?.forced){releasePalaceIntercept(u);return;}
 if(a){if(a.guard?.palaceIntercept===u&&palaceContact(u,a.guard,b,12)){u.tgt=a.guard;u.focus=true;return;}releasePalaceIntercept(u);a=null;}
 const S=teams[u.team].S[u.type];if(distTo(u,b)>S.rng+3+u.d.r*.5)return;
 let guard=null,bd=Infinity;forNear(u.x,u.y,u.d.r+40,g=>{if(g.palaceIntercept&&(!g.palaceIntercept.palaceAttack||g.palaceIntercept.dead))g.palaceIntercept=null;
  if(g.palaceIntercept||!palaceContact(u,g,b)||g.tgt&&g.tgt!==u&&!g.tgt.dead||g.focus&&g.tgt!==u)return;const d=hyp(g.x-u.x,g.y-u.y);if(d<bd||d===bd&&g.id<guard.id){guard=g;bd=d;}});
 if(guard)bindPalaceIntercept(u,guard,b);}
// Vision is shared by an alliance, never by the local player's fog array.
let combatVisionCache=null;
function combatVisible(t,target,observer=null){if(!target||target.dead)return false;if(observer&&!observer.dead&&hyp(observer.x-target.x,observer.y-target.y)<=teams[observer.team].S[observer.type].sight)return true;
 let c=combatVisionCache;if(!c||c.game!==G||c.time!==G.t||c.size!==units.length||c.bs!==blds.length||c.ver!==gridVer)c=combatVisionCache={game:G,time:G.t,size:units.length,bs:blds.length,ver:gridVer,seen:new Map()};
 const key=sideOf(t)+':'+target.id;if(c.seen.has(key))return c.seen.get(key);const seen=typeof heroVisible==='function'?heroVisible(t,target):false;c.seen.set(key,seen);return seen;}
function responseFree(u){return combatSoldier(u)&&!u.reaction&&!u.palaceAttack&&!u.palaceIntercept&&!u.heroTaunt&&!u.focus&&!u.order?.forced&&G.t>=(u.responseCooldown||0)&&(!u.tgt||u.tgt.dead);}
function startResponse(u,victim,att,helper=false){if(!responseFree(u)||targetBlocked(u,att))return false;const S=teams[u.team].S[u.type],visible=combatVisible(u.team,att,u),stationary=u.hold||u.d.cls==='treb';
 if(stationary&&(!visible||distTo(u,att)>S.rng+(att.isB?3:att.d.r)+u.d.r*.5||!u.d.ranged&&!meleeLineClear(u,att)))return false;
 const order=u.order?{...u.order,field:null}:null;u.reaction={origin:{x:u.x,y:u.y},order,target:att,victim,known:visible?{x:att.x,y:att.y}:{x:victim.x,y:victim.y},until:G.t+RESPONSE_SECONDS,stationary,helper};
 if(helper){if(!att.responseHelpers)att.responseHelpers=new Set();att.responseHelpers.add(u);}u.order=null;u.tgt=visible?att:null;u.focus=false;u.anchor={x:u.x,y:u.y};u.path=null;u.stuck=0;return true;}
function soldierUnderAttack(victim,att){if(!att||att.dead||victim.isB||!areEnemies(victim.team,att.team))return;const wasHelping=!!victim.reaction?.helper;
 startResponse(victim,victim,att);if(wasHelping||G.t<(victim.helpCallAt||0))return;victim.helpCallAt=G.t+.75;
 if(att.responseHelpers)for(const u of att.responseHelpers)if(u.dead||!u.reaction||u.reaction.target!==att)att.responseHelpers.delete(u);
 let n=0;if(att.responseHelpers)for(const u of att.responseHelpers)if(areAllies(u.team,victim.team))n++;if(n>=RESPONSE_HELPERS)return;const candidates=[];
 forNear(victim.x,victim.y,RESPONSE_RADIUS,u=>{if(u===victim||!areAllies(u.team,victim.team)||!responseFree(u))return;const d=hyp(u.x-victim.x,u.y-victim.y);if(d<=Math.min(RESPONSE_RADIUS,teams[u.team].S[u.type].sight))candidates.push({u,d});});
 candidates.sort((a,b)=>a.d-b.d||a.u.id-b.u.id);for(const {u} of candidates)if(startResponse(u,victim,att,true)&&++n>=RESPONSE_HELPERS)break;}
function finishResponse(u){const a=u.reaction;if(!a)return;if(u.palaceIntercept)releasePalaceIntercept(u.palaceIntercept);if(a.target?.responseHelpers)a.target.responseHelpers.delete(u);u.reaction=null;u.tgt=null;u.focus=false;u.path=null;u.stuck=0;u.mv=false;u.movedT=0;u.responseCooldown=G.t+2;
 if(u.hold||a.stationary)return;u.order=a.order||{x:a.origin.x,y:a.origin.y,gi:nearestPass(u.team,cellI(a.origin.x,a.origin.y)),forced:true,field:null,responseReturn:true};}
function updResponse(u,S,dt){const a=u.reaction;if(!a)return false;const t=a.target;
 if(!t||t.dead||!areEnemies(u.team,t.team)||G.t>=a.until||hyp(u.x-a.origin.x,u.y-a.origin.y)>RESPONSE_LEASH||targetBlocked(u,t)){finishResponse(u);return false;}
 const visible=combatVisible(u.team,t,u);if(visible){a.known={x:t.x,y:t.y};if(hyp(t.x-a.origin.x,t.y-a.origin.y)>RESPONSE_LEASH+S.rng){finishResponse(u);return false;}u.tgt=t;
  if(a.stationary&&distTo(u,t)>S.rng+(t.isB?3:t.d.r)+u.d.r*.5){finishResponse(u);return false;}fight(u,S,dt);return true;}
 u.tgt=null;if(a.stationary||hyp(u.x-a.known.x,u.y-a.known.y)<12){finishResponse(u);return false;}
 const goal=nearestPass(u.team,cellI(a.known.x,a.known.y));if(goal<0){finishResponse(u);return false;}navTo(u,a.known.x,a.known.y,goal,S.spd,dt,true);if(u.navFail||u.stuck>2.5){blockTarget(u,t);finishResponse(u);}return true;}
function targetBlocked(u,t){const b=u.blockedTarget;return !!(b&&b.id===t.id&&b.ver===gridVer&&G.t<b.until&&hyp(t.x-b.x,t.y-b.y)<CELL);}
function blockTarget(u,t){u.blockedTarget={id:t.id,x:t.x,y:t.y,ver:gridVer,until:G.t+5};u.tgt=null;u.focus=false;u.anchor=null;u.path=null;u.stuck=0;u.mv=false;u.movedT=0;}
function findTarget(u,r,defendersOnly=false){let best=null,bd=Infinity;const tr=u.d.cls==='treb';
 forNear(u.x,u.y,r,e=>{if(e.dead||!areEnemies(u.team,e.team)||targetBlocked(u,e)||defendersOnly&&(e.type==='worker'||e.d.dmg<=0))return;const d=hyp(e.x-u.x,e.y-u.y);if(d>r||tr&&d>teams[u.team].S[u.type].rng+e.d.r+u.d.r*.5)return;let s=d;if(e.type==='worker')s+=40;if(tr)s+=300;if(s<bd){bd=s;best=e;}});
 if(!defendersOnly&&(!best||tr)){for(const b of blds){if(b.dead||!areEnemies(u.team,b.team)||b.def.wall||targetBlocked(u,b))continue;if(Math.abs(b.x-u.x)>r+80||Math.abs(b.y-u.y)>r+80)continue;
  const d=rectDist(u.x,u.y,b);if(d>r)continue;const s=d+(tr?-400:150);if(s<bd){bd=s;best=b;}}}
 return best;}
function dmgBuff(u){const T=teams[u.team];if(!T||!isActivePlayer(u.team))return 1;let k=1;if(T.martT>0)k+=.4;if(atHome(u))k+=.15;
 const c=T.carr;if(c&&!c.dead&&u!==c){const ar=UT.carr.aura*(1+.4*T.mods.carrAura);if(hyp(c.x-u.x,c.y-u.y)<ar)k+=.15+.1*T.mods.carrAura;}return k;}
function nearCarr(u){const T=teams[u.team];const c=T&&T.carr;if(!c||c.dead||u===c)return false;return hyp(c.x-u.x,c.y-u.y)<UT.carr.aura*(1+.4*T.mods.carrAura);}
function braced(u){return !u.isB&&!u.d.hero&&u.d.cls==='inf'&&teams[u.team].mods.brace&&(!teams[u.team].mods.card.armaioli_picche||u.type==='pike')&&!u.mv&&u.stillT>=1.2;}
function markStrike(u){u.atk=.3;u.strikeSeq=((u.strikeSeq||0)+1)&15;}
function attackPower(u,S,charged=false){const T=teams[u.team],m=T.mods;return {base:S.dmg*dmgBuff(u)+(m.fury?Math.min(10,T.furyK.length):0),cls:u.d.cls,vs:u.d.vs||{},vsCav:m.vsCav,vsXb:m.vsXb,flatVsCav:m.flatVsCav,flatVsXb:m.flatVsXb,bld:u.d.bld==null?1:u.d.bld,charge:charged&&u.d.cls==='cav'?m.charge:0,flatCharge:charged&&u.d.cls==='cav'?m.flatCharge:0};}
function targetAttackDamage(power,t){let dmg=power.base;if(t.isB)dmg*=power.bld;else{const vs=power.vs[t.type]||power.vs[t.d.cls];if(vs)dmg*=vs;
 if(power.cls==='inf'&&t.d.cls==='cav')dmg=dmg*(1+power.vsCav)+(power.flatVsCav||0);if(power.cls==='cav'&&t.d.cls==='xb')dmg=dmg*(1+power.vsXb)+(power.flatVsXb||0);}
 if(!t.isB&&!braced(t))dmg=dmg*(1+power.charge)+(power.flatCharge||0);return dmg;}
function actualDamage(attTeam,tgt,dmg,att,opts={}){
 if(!tgt||tgt.dead||tgt.hp<=0||!areEnemies(attTeam,tgt.team)||!(dmg>0))return false;if(tgt.kind==='palazzo')dmg=Math.max(1,dmg-PALACE_ARMOR);const applied=Math.min(tgt.hp,dmg);
 if(!tgt.temporaryUntil&&typeof recordCampDamage==='function')recordCampDamage(tgt,attTeam,applied);
 tgt.hp-=dmg;tgt.lastHit=G.t;if(!tgt.isB){if(opts.normal&&opts.kind==='m')palaceHitIntercept(tgt,att);soldierUnderAttack(tgt,att);}
 if(isHuman(tgt.team))alertAttack(tgt);
 if(dmg>=40||Math.random()<.35)addFloat(tgt.x,tgt.y-(tgt.isB?40:28),Math.round(dmg),false,dmg>=60);
 if(opts.normal&&att&&!att.dead&&!att.d.hero&&!att.temporaryUntil&&!tgt.isB&&att.d.cls==='cav'&&teams[att.team].mods.card.comunita_contado){const c=att.cardCounters;c.cavHits=(c.cavHits+1)%3;if(!c.cavHits)att.hp=Math.min(att.max,att.hp+4);}
 const killed=tgt.hp<=0;if(killed){if(tgt.isB)killBld(tgt,att?.temporaryUntil?null:attTeam);else killUnit(tgt,attTeam,att);}
 if(tgt.isB&&tgt.kind==='torre'&&!killed)cardGarrison(tgt);
 if(typeof heroAfterDamage==='function')heroAfterDamage(attTeam,tgt,applied,opts.kind,att,opts);return killed;}
function nearbyOwn(u,cls,r){let yes=false;forNear(u.x,u.y,r,e=>{if(e!==u&&!e.dead&&!e.d.hero&&e.team===u.team&&e.d.cls===cls&&hyp(e.x-u.x,e.y-u.y)<=r)yes=true;});return yes;}
function damage(attTeam,tgt,raw,kind,crit,att,opts={}){if(!tgt||tgt.dead||tgt.hp<=0||!areEnemies(attTeam,tgt.team))return false;let dmg=raw;
 if(typeof heroBeforeDamage==='function'){dmg=heroBeforeDamage(attTeam,tgt,dmg,kind,att,opts);if(dmg===null)return false;}
 const m=teams[tgt.team].mods;
 if(!tgt.isB&&!tgt.d.hero&&opts.normal&&kind==='m'&&tgt.type==='guard'&&m.card.decime_patrimonio&&G.t>=(tgt.guardParryAt||0)){
  let companion=false;forNear(tgt.x,tgt.y,64,e=>{if(e!==tgt&&!e.dead&&e.team===tgt.team&&e.type==='guard'&&hyp(e.x-tgt.x,e.y-tgt.y)<=64)companion=true;});
  if(companion){tgt.guardParryAt=G.t+8;tgt.blockedShotSeq=(tgt.blockedShotSeq||0)+1;return false;}}
 if(!tgt.isB&&!tgt.d.hero&&kind==='r'&&tgt.d.cls==='xb'&&m.pavise&&!tgt.mv&&tgt.stillT>=3&&!(tgt.paviseCd>0)){
  tgt.paviseCd=8;tgt.blockedShotSeq=(tgt.blockedShotSeq||0)+1;tgt.tacticState=(tgt.tacticState||0)&~16;return false;}
 if(!tgt.isB){const S=teams[tgt.team].S[tgt.type];let a=kind==='m'?S.aM:kind==='r'||opts.fixed?S.aR:0;if(nearCarr(tgt))a+=1;if(atHome(tgt))a+=2;dmg=Math.max(1,dmg-a);
  if(tgt.d.cls==='inf'&&!tgt.mv)dmg=Math.max(1,dmg-m.flatShield);}
 const cover=!tgt.isB&&kind==='r'&&(tgt.d.cls==='xb'&&m.card.logge_mercanti?3:tgt.d.cls==='treb'&&m.card.compagnie_balestriere?4:0);
 if(cover){let guard=null,bd=65;forNear(tgt.x,tgt.y,64,e=>{if(e.dead||e.d.hero||e.team!==tgt.team||e.d.cls!=='inf')return;const d=hyp(e.x-tgt.x,e.y-tgt.y);if(d<=64&&(d<bd||d===bd&&e.id<guard.id)){guard=e;bd=d;}});
  if(guard){const intercepted=Math.min(guard.hp,dmg,cover);dmg-=intercepted;guard.guardUntil=G.t+.7;guard.tacticState=(guard.tacticState||0)|4;actualDamage(attTeam,guard,intercepted,att,{kind,normal:false});}}
 const killed=actualDamage(attTeam,tgt,dmg,att,{...opts,kind});
 if(!killed&&opts.normal&&kind==='m'&&att&&!att.dead&&att.d.cls==='cav'&&braced(tgt)&&!(tgt.braceCd>0)){
  tgt.braceCd=2;markStrike(tgt);damage(tgt.team,att,m.brace,'m',false,tgt,{normal:false});}return killed;}
function launchBolt(u,t,power,offset=0,secondary=false){if(u.dead||!t||t.dead||!areEnemies(u.team,t.team))return;const m=teams[u.team].mods,sx=u.x+u.f*9+offset,sy=u.y-12,ex=t.x+MR(-4,4),ey=t.isB?t.y:t.y-9;
 addProj({k:'b',x0:sx,y0:sy,x1:ex,y1:ey,t:0,dur:Math.max(.2,hyp(ex-sx,ey-sy)/440),tgt:t,dmg:targetAttackDamage(power,t),attack:power,crit:false,team:u.team,att:u,normal:!secondary,pierce:secondary?0:m.pierce,fire:secondary?0:m.fire,linePierce:!secondary&&!!m.pierceLine});}
function fixedBolt(u,t,dmg,stone=false){if(!t||t.dead||!areEnemies(u.team,t.team))return;addProj({k:stone?'s':'b',single:stone,x0:u.x,y0:u.y-12,x1:t.x,y1:t.isB?t.y:t.y-9,t:0,dur:stone?.7:Math.max(.2,hyp(t.x-u.x,t.y-u.y)/440),tgt:t,dmg,bdmg:dmg,team:u.team,att:u,normal:false,pierce:0,fire:0});}
function secondBoltTarget(u,t,S){let target=null,bd=Infinity;forNear(u.x,u.y,S.rng+25,e=>{if(e===t||e.dead||!areEnemies(u.team,e.team)||hyp(e.x-u.x,e.y-u.y)>S.rng+e.d.r)return;const d=hyp(e.x-t.x,e.y-t.y);if(d<bd||d===bd&&e.id<target.id){bd=d;target=e;}});return target;}
function fixedSweep(u,t,dmg,max=2){const dx=t.x-u.x,dy=t.y-u.y,L=hyp(dx,dy)||1,targets=[];
 forNear(t.x,t.y,50,e=>{if(e===t||e.dead||!areEnemies(u.team,e.team)||hyp(e.x-t.x,e.y-t.y)>50)return;const ex=e.x-u.x,ey=e.y-u.y;if((ex*dx+ey*dy)/L>=hyp(ex,ey)*.5)targets.push(e);});
 targets.sort((a,b)=>hyp(a.x-t.x,a.y-t.y)-hyp(b.x-t.x,b.y-t.y)||a.id-b.id);for(const e of targets.slice(0,max))damage(u.team,e,dmg,'m',false,u,{normal:false});}
function doAttack(u,t,S){if(u.dead||!t||t.dead||!areEnemies(u.team,t.team))return;if(t.kind==='palazzo'&&!u.d.ranged){resolvePalaceAttack(u);if(u.palaceAttack)return;}const T=teams[u.team],m=T.mods,charged=u.movedT>1.2,power=attackPower(u,S,charged),dmg=targetAttackDamage(power,t);markStrike(u);
 if(typeof heroOnNormalAttack==='function')heroOnNormalAttack(u,t,S);u.movedT=0;u.lastAttack=G.t;if(u.reaction?.target===t)u.reaction.until=G.t+RESPONSE_SECONDS;const ordinary=!u.d.hero&&!u.temporaryUntil,c=u.cardCounters;
 if(u.d.cls==='xb'){launchBolt(u,t,power);if(ordinary){c.shots=(c.shots+1)%12;
  if(T.ups.falco&&c.shots%4===0)fixedBolt(u,t,u.d.dmg);
  if(!t.isB&&t.d.cls==='cav'){c.vsCavShots=(c.vsCavShots+1)%4;if(!c.vsCavShots&&m.card.fondachi_porto)fixedBolt(u,t,12);}
  if(c.shots%3===0){if(m.card.botteghe_balestrai||m.card.scuola_tiro&&nearbyOwn(u,'treb',96))fixedBolt(u,secondBoltTarget(u,t,S),6);if(m.card.fuoco_milizie&&nearbyOwn(u,'inf',64))fixedBolt(u,t,6);}
  if(m.xbDeploy&&u.deployCharge>=4){u.deployCharge=0;u.tacticState=(u.tacticState||0)&~2;fixedBolt(u,t,6);fixedBolt(u,t,6);}}}
 else if(u.d.cls==='treb'){const d=hyp(t.x-u.x,t.y-u.y),fury=m.fury?Math.min(10,T.furyK.length):0;addProj({k:'s',splash:u.d.splash,x0:u.x-u.f*10,y0:u.y-46,x1:t.x+MR(-10,10),y1:t.y,t:0,dur:1.2+d/600,team:u.team,tgt:t,normal:true,dmg:S.dmg*dmgBuff(u)+fury,bdmg:S.bdmg*dmgBuff(u)+fury,att:u,shrapnel:ordinary&&!!m.siegeShrapnel});
  if(ordinary&&u.type==='mang'){c.siegeShots=(c.siegeShots+1)%4;if(!c.siegeShots&&m.card.vedette_torri)fixedBolt(u,t,t.isB?18:8,true);}}
 else{const killed=damage(u.team,t,dmg,'m',false,u,{normal:true,charged});if(killed&&m.lifesteal&&u.d.cls==='cav')u.hp=Math.min(u.max,u.hp+u.max*m.lifesteal);
  if(ordinary){c.attacks=(c.attacks+1)%3;if(u.d.cls==='cav'&&m.cavalryTrample&&charged)fixedSweep(u,t,10);
   if(!c.attacks){if(hasTactic(u,'doubleHit')&&!t.dead&&!u.dead)u.echo={target:t,at:G.t+.28,dmg:u.d.cls==='cav'?10:6};
    if(m.card.scuderie_reali&&u.d.cls==='cav')fixedSweep(u,t,8);if(m.card.carri_lombardi&&u.d.cls==='inf')fixedSweep(u,t,6);if(m.card.ordini_equestri&&u.type==='guard')fixedSweep(u,t,10,1);}}}}
function killUnit(u,by,att){if(u.dead||by!=null&&!areEnemies(by,u.team))return;clearCombatResponse(u);const rewarded=!u.temporaryUntil&&!att?.temporaryUntil;
 if(!u.temporaryUntil&&typeof registerCampKill==='function')registerCampKill(u,by);u.dead=true;u.hp=0;const T=teams[u.team];T.popUsed-=u.d.pop;if(isPlayerTeam(u.team)&&!u.temporaryUntil)T.lost++;
 if(u.type==='worker'){if(u.job&&T.jobs[u.job]>0)T.jobs[u.job]--;setRc(u,-1);}if(u.campo)u.campo.slots=u.campo.slots.filter(x=>x!==u);if(T.carr===u)T.carr=null;
 cardOnLoss(u,by);
 if(typeof heroOnDeath==='function')heroOnDeath(u,by,att);
 decals.push({k:'c',x:u.x,y:u.y,f:u.f,fac:T.fac,big:u.d.r>9,worker:u.type==='worker',t:0,life:6});emit(['d',u.x|0,u.y|0,u.f,T.fac,u.d.r>9?1:0,u.type==='worker'?1:0]);
 if(rewarded&&isActivePlayer(by)&&areEnemies(by,u.team)){const B=teams[by];B.kills++;addGlory(by,u.d.glory);if(B.mods.loot){B.res.g+=4*B.mods.loot;B.res.l+=3*B.mods.loot;}
  if(cardSoldier(u)){cardEvent(by,'kill',u);if(B.mods.fury)B.furyK.push(G.t);if(att&&!att.d.hero&&att.d.cls==='cav'&&B.mods.card.genieri_angioini){B.res.g+=4;B.res.l+=3;}}}}

function killBld(b,by){if(b.dead||by!=null&&!areEnemies(by,b.team))return;b.dead=true;b.hp=0;
 for(let y=b.cy;y<b.cy+b.h;y++)for(let x=b.cx;x<b.cx+b.w;x++){const i=y*GW+x;if(bAt[i]===b)bAt[i]=null;}
 gridVer++;for(const w of b.slots)w.campo=null;emit(['x',b.x|0,b.y|0,b.w,b.h,b.def.wall?1:0]);
 if(isActivePlayer(by)&&areEnemies(by,b.team)){addGlory(by,(b.def.glory||2)+(b.built?0:0));if(teams[by].mods.bLoot&&!b.def.wall){for(const r of RES)teams[by].res[r]+=teams[by].mods.bLoot;}}
 recountPop(b.team);if(!b.def.wall)notify(b.team,'toast','Abbiamo perso: '+BT[b.kind].n,'#ff9a8a',1500);}
function alertAttack(tgt){const T=teams[tgt.team];if(G.t-T.alertT<12)return;const h=T.home;
 if(!(tgt.isB||tgt.type==='worker'||(h&&hyp(tgt.x-h.x,tgt.y-h.y)<900)))return;T.alertT=G.t;notify(tgt.team,'ping',tgt.x|0,tgt.y|0);notify(tgt.team,'sfx','alarm');notify(tgt.team,'toast','Siamo sotto attacco!','#ff7a6a',2000);}
function addFloat(x,y,v,crit,big){emit(['h',x|0,y|0,v,crit?1:0,big?1:0]);if(floats.length>90||!visAt(x,y))return;floats.push({x:x+MR(-5,5),y,t:0,txt:String(v),crit,big});}

// ===================== unità: aggiornamento =====================
function updTactic(u,dt){const m=teams[u.team].mods;u.stillT=u.mv?0:(u.stillT||0)+dt;
 u.braceCd=Math.max(0,(u.braceCd||0)-dt);u.paviseCd=Math.max(0,(u.paviseCd||0)-dt);
 u.deployCharge=u.mv?0:Math.min(4,(u.deployCharge||0)+dt);
 u.tacticState=(braced(u)?1:0)|(u.d.cls==='xb'&&m.xbDeploy&&u.deployCharge>=4?2:0)|(u.guardUntil>G.t?4:0)|(u.healUntil>G.t?8:0)|(u.d.cls==='xb'&&m.pavise&&u.stillT>=3&&!u.paviseCd?16:0);
 const e=u.echo;if(e&&G.t>=e.at&&!(u.heroStunUntil>G.t)){u.echo=null;const t=e.target;if(!u.dead&&!t.dead&&t.hp>0&&areEnemies(u.team,t.team)&&distTo(u,t)<=teams[u.team].S[u.type].rng+(t.isB?3:t.d.r)+u.d.r*.5+12){markStrike(u);const killed=damage(u.team,t,e.dmg,'m',false,u);if(killed&&m.lifesteal&&u.d.cls==='cav')u.hp=Math.min(u.max,u.hp+u.max*m.lifesteal);}}}
function tacticHealing(){if(G.t<(G.tacticHealAt||0))return;G.tacticHealAt=G.t+.5;for(const u of units)u.cardHealRate=0;
 for(const healer of units){if(healer.dead||healer.d.hero||healer.temporaryUntil)continue;const m=teams[healer.team].mods,rate=healer.type==='carr'&&m.card.gonfalone?2:healer.type==='guard'&&m.card.ospizi_pellegrini?1:0;if(!rate)continue;const targets=[];
  forNear(healer.x,healer.y,96,u=>{if(u!==healer&&!u.dead&&u.team===healer.team&&cardSoldier(u)&&u.hp<u.max&&G.t-u.lastHit>3&&hyp(u.x-healer.x,u.y-healer.y)<=96)targets.push(u);});
  targets.sort((a,b)=>(a.hp/a.max)-(b.hp/b.max)||a.id-b.id);for(const u of targets.slice(0,rate===2?4:1))u.cardHealRate=Math.max(u.cardHealRate,rate);
  if(targets.length){healer.healUntil=G.t+.6;healer.tacticState=(healer.tacticState||0)|8;}}}

function updUnit(u,dt){const T=teams[u.team],S=T.S[u.type],heroLocked=typeof heroTick==='function'&&heroTick(u,dt);if(u.dead)return;updTactic(u,dt);if(u.dead)return;
 u.cd-=dt;if(u.atk>0)u.atk-=dt;
 if(u.burn>0){if(!areEnemies(u.burnBy,u.team)){u.burn=0;u.burnD=0;}else{const burnDmg=u.burnD*Math.min(dt,u.burn);u.burn-=dt;if(!u.temporaryUntil&&!u.burnAtt?.temporaryUntil&&typeof recordCampDamage==='function')recordCampDamage(u,u.burnBy,Math.min(u.hp,burnDmg));u.hp-=burnDmg;if(u.hp<=0){killUnit(u,u.burnBy,u.burnAtt);return;}}}
 const regen=Math.max(S.regen,u.cardHealRate||0);if(regen>0&&G.t-u.lastHit>3&&u.hp<u.max)u.hp=Math.min(u.max,u.hp+regen*dt);if(heroLocked)return;
 if(unstick(u,dt))return;
 if(u.type==='worker'){if(u.hold){u.mv=false;u.movedT=0;return;}updWorker(u,T,S,dt);return;}
 if(updResponse(u,S,dt))return;
 resolvePalaceAttack(u);
 if(u.tgt&&(u.tgt.dead||u.tgt.hp<=0||!areEnemies(u.team,u.tgt.team)))u.tgt=null,u.focus=false;
 u.scan-=dt;
 if(u.scan<=0&&S.acq>0){u.scan=.3+Math.random()*.2;
  // L'assedio deve confrontare anche gli edifici più lontani del bersaglio corrente.
  if(!(u.order&&u.order.forced)&&!u.focus&&!u.palaceIntercept){const defenders=!!(u.tgt&&u.tgt.isB&&u.d.cls!=='treb');
   const r=u.hold?Math.min(S.acq,S.rng+24):u.tgt&&!defenders&&u.d.cls!=='treb'?Math.min(S.acq,distTo(u,u.tgt)-6):S.acq;
   if(r>0){const e=findTarget(u,r,defenders);if(e&&e!==u.tgt){u.tgt=e;u.pathT=0;u.path=null;u.stuck=0;if(!u.anchor)u.anchor={x:u.x,y:u.y};}}}}
 if(u.tgt){fight(u,S,dt);return;}
 if(u.order&&!u.hold){followOrder(u,S,dt);return;}
 u.mv=false;u.movedT=0;
 if(u.camp&&hyp(u.x-u.camp.x,u.y-u.camp.y)>130)u.order={x:u.camp.x+MR(-50,50),y:u.camp.y+MR(-50,50),gi:nearestPass(u.team,cellI(u.camp.x,u.camp.y)),forced:true,field:null};}
function meleeLineClear(u,t){const L=hyp(t.x-u.x,t.y-u.y),n=Math.ceil(L/8);for(let k=1;k<n;k++){const i=cellI(u.x+(t.x-u.x)*k/n,u.y+(t.y-u.y)*k/n),b=bAt[i];if(water[i]===1||b&&!b.dead&&!b.def.flat&&b!==t)return false;}return true;}
// Il fronte già impegnato può essere pieno: chi attende non accumula carica
// e riparte appena i compagni davanti si spostano o cadono.
function meleeFrontBlocked(u,b){const tx=clamp(u.x,b.x0,b.x0+b.w*CELL),ty=clamp(u.y,b.y0,b.y0+b.h*CELL),dx=tx-u.x,dy=ty-u.y,L=hyp(dx,dy);let blocked=false;
 if(L<1)return false;forNear(u.x,u.y,64,e=>{if(e===u||e.dead||e.mv||!areAllies(u.team,e.team)||e.tgt!==b||!meleeHolding(e)&&!(e.meleeApproach?.b===b&&e.meleeApproach.waiting))return;
 const ex=e.x-u.x,ey=e.y-u.y,along=(ex*dx+ey*dy)/L,side=Math.abs(ex*dy-ey*dx)/L;
 if(along>1&&along<Math.min(L,36)&&side<(u.d.r+e.d.r)*.9-1)blocked=true;});return blocked;}
function waitForMeleeFront(u,b,reach){const d=distTo(u,b);if(d>reach+96){u.meleeApproach=null;return false;}
 let a=u.meleeApproach;if(!a||a.b!==b||a.ver!==gridVer)a=u.meleeApproach={b,ver:gridVer,best:d,since:G.t,waiting:false};
 if(d<a.best-2){a.best=d;a.since=G.t;a.waiting=false;}
 if(a.waiting||G.t-a.since>=4){if(meleeFrontBlocked(u,b)){a.waiting=true;u.mv=false;u.movedT=0;u.path=null;return true;}a.waiting=false;a.best=d;a.since=G.t;}
 return false;}
function fight(u,S,dt){resolvePalaceAttack(u);const t=u.tgt;if(!t||t.dead||!areEnemies(u.team,t.team)||S.dmg<=0){u.tgt=null;u.focus=false;u.mv=false;u.movedT=0;return;}const d=distTo(u,t);const reach=S.rng+(t.isB?3:t.d.r)+u.d.r*.5;
 if(u.d.cls==='treb'&&!t.isB&&!u.focus&&d>reach){u.tgt=null;u.path=null;u.mv=false;u.movedT=0;return;}
 if(!u.d.hero&&!u.temporaryUntil&&u.d.cls==='cav'&&teams[u.team].mods.card.custodi_cerchia&&d<=96&&G.t-u.lastHit>=8&&G.t-u.lastAttack>=8&&G.t>=(u.javelinAt||0)&&meleeLineClear(u,t)){fixedBolt(u,t,8);u.javelinAt=G.t+8;u.lastAttack=G.t;}
 if(d<=reach&&(u.d.ranged||meleeLineClear(u,t))){u.meleeApproach=null;u.mv=false;u.path=null;u.f=t.x>=u.x?1:-1;if(u.cd<=0){if(S.dmg>0)doAttack(u,t,S);u.cd=S.cd*MR(.92,1.08);u.atk=.3;}return;}
 if(u.hold||u.reaction?.stationary){u.mv=false;u.movedT=0;if(u.hold&&!u.reaction){u.tgt=null;u.focus=false;}return;}
 if(typeof heroCanMove==='function'&&!heroCanMove(u)){u.mv=false;u.movedT=0;return;}
 if(!u.focus){const ax=u.anchor?u.anchor.x:u.x,ay=u.anchor?u.anchor.y:u.y;if(hyp(u.x-ax,u.y-ay)>S.acq*1.8+140||(u.camp&&hyp(u.x-u.camp.x,u.y-u.camp.y)>380)){u.tgt=null;u.anchor=null;return;}}
 if(t.isB&&!u.d.ranged&&u.type!=='worker'&&waitForMeleeFront(u,t,reach))return;
 let goal,tx=t.x,ty=t.y;
 if(t.isB){goal=adjFree(u.team,t,u.x,u.y);if(goal<0){blockTarget(u,t);return;}if(hyp(cX(goal)-u.x,cY(goal)-u.y)<20){tx=clamp(u.x,t.x0,t.x0+t.w*CELL);ty=clamp(u.y,t.y0,t.y0+t.h*CELL);}else{tx=cX(goal);ty=cY(goal);}}
 else{goal=nearestPass(u.team,cellI(t.x,t.y));if(goal<0){blockTarget(u,t);return;}}
 navTo(u,tx,ty,goal,S.spd,dt);
 if(u.stuck>2.5)blockTarget(u,t);}
function followOrder(u,S,dt){if(typeof heroCanMove==='function'&&!heroCanMove(u)){u.mv=false;u.movedT=0;return;}const o=u.order;const dd=hyp(o.x-u.x,o.y-u.y);
 if(dd<8||(dd<60&&u.stuck>.5)){u.order=null;u.anchor={x:u.x,y:u.y};u.mv=false;u.stuck=0;return;}
 // I supporti non possono demolire un ostacolo: aggirano gli edifici o attendono la scorta.
 if(S.dmg<=0){const goal=nearestPass(u.team,cellI(o.x,o.y));if(goal<0){u.mv=false;u.movedT=0;return;}
  const open=passFor(u.team,cellI(o.x,o.y)),tx=open?o.x:cX(goal),ty=open?o.y:cY(goal);
  if(hyp(tx-u.x,ty-u.y)<8){u.order=null;u.mv=false;u.movedT=0;return;}
  navTo(u,tx,ty,goal,S.spd,dt,true);return;}
 u.losT-=dt;if(u.losT<=0){u.losT=.35+Math.random()*.2;u.losOk=dd<CELL*14&&los(u.team,u.x,u.y,o.x,o.y);}
 if(u.losOk){steer(u,o.x,o.y,S.spd,dt);if(u.stuck>1.2)u.losOk=false;return;}
 if(!o.field||o.field.ver!==gridVer)o.field=getField(u.team,o.gi);
 const f=o.field.d,c=o.field.c,ci=cellI(u.x,u.y),x=ci%GW,y=(ci/GW)|0;let best=-1,bv=f[ci];
 if(bv===Infinity){u.order=null;return;}
 for(let k=0;k<8;k++){const nx=x+DX[k],ny=y+DY[k];if(nx<0||ny<0||nx>=GW||ny>=GH)continue;const n=ny*GW+nx;if(k>=4&&(c[y*GW+nx]===Infinity||c[ny*GW+x]===Infinity))continue;if(f[n]<bv){bv=f[n];best=n;}}
 if(best<0){steer(u,o.x,o.y,S.spd,dt);if(u.stuck>1)u.order=null;return;}
 const b=bAt[best];if(b&&!b.def.flat&&areEnemies(u.team,b.team)&&!b.dead){u.tgt=b;u.focus=true;u.anchor=null;return;}
 const ahead=f[best];let px=cX(best),py=cY(best);
 // guarda una cella più avanti per curve morbide
 const bx=best%GW,by=(best/GW)|0;let b2=-1,v2=ahead;for(let k=0;k<8;k++){const nx=bx+DX[k],ny=by+DY[k];if(nx<0||ny<0||nx>=GW||ny>=GH)continue;const n=ny*GW+nx;if(k>=4&&(c[by*GW+nx]===Infinity||c[ny*GW+bx]===Infinity))continue;if(f[n]<v2){v2=f[n];b2=n;}}
 if(b2>=0&&!bAt[b2]){px=(px+cX(b2))/2;py=(py+cY(b2))/2;}
 steer(u,px,py,S.spd,dt);if(u.stuck>3){u.order=null;u.stuck=0;}}

// ===================== contadini =====================
let resClaim=new Uint8Array(NCELL);
function setRc(u,i){if(u.rc>=0&&resClaim[u.rc]>0)resClaim[u.rc]--;u.rc=i;if(i>=0){resClaim[i]++;u.lastRc=i;}}
function farmCap(t){return 3+teams[t].mods.farmCap;}
const FSPOT=[[-26,-12],[0,14],[26,-12],[0,-26]];
// Connectivity is shared by all workers and refreshed only when the map changes.
// Unlike military flow fields, these paths cannot pass through an enemy building.
const workerAccessCache=[];
function workerAccess(t){let a=workerAccessCache[t];if(a&&a.game===G&&a.ver===gridVer)return a;
 const open=new Uint8Array(NCELL),zone=new Int32Array(NCELL).fill(-1),q=new Int32Array(NCELL);
 for(let i=0;i<NCELL;i++)open[i]=passFor(t,i)?1:0;let label=0;
 for(let i=0;i<NCELL;i++){if(!open[i]||zone[i]>=0)continue;let head=0,tail=1;q[0]=i;zone[i]=label;
  while(head<tail){const c=q[head++],x=c%GW,y=(c/GW)|0;for(let k=0;k<8;k++){const nx=x+DX[k],ny=y+DY[k];if(!inb(nx,ny))continue;const n=ny*GW+nx;
   if(!open[n]||zone[n]>=0||k>=4&&(!open[y*GW+nx]||!open[ny*GW+x]))continue;zone[n]=label;q[tail++]=n;}}label++;}
 return workerAccessCache[t]={game:G,ver:gridVer,zone};}
function workerGoal(u,b){const here=cellI(u.x,u.y);if(rectDist(u.x,u.y,b)<=30&&passFor(u.team,here))return here;
 const zone=workerAccess(u.team).zone,start=zone[here];if(start<0)return -1;let goal=-1,dist=Infinity;
 for(let y=b.cy-1;y<=b.cy+b.h;y++)for(let x=b.cx-1;x<=b.cx+b.w;x++){if(!inb(x,y)||x>=b.cx&&x<b.cx+b.w&&y>=b.cy&&y<b.cy+b.h)continue;
  const i=y*GW+x;if(zone[i]!==start)continue;const d=hyp(cX(i)-u.x,cY(i)-u.y);if(d<dist){dist=d;goal=i;}}return goal;}
function workerRoute(u,b){const goal=workerGoal(u,b);if(goal<0)return null;const tx=cX(goal),ty=cY(goal);
 if(rectDist(u.x,u.y,b)<=30)return {goal,distance:0};if(los(u.team,u.x,u.y,tx,ty))return {goal,distance:hyp(tx-u.x,ty-u.y)};
 const path=astar(u.team,cellI(u.x,u.y),goal,NCELL);if(!ASTAR_OK||!path)return null;let x=u.x,y=u.y,distance=0;
 for(const i of path){const nx=cX(i),ny=cY(i);distance+=hyp(nx-x,ny-y)*(water[i]===2?1.6:1);x=nx;y=ny;}return {goal,distance};}
function nearestDrop(u){const cached=u.dropTarget;if(cached&&!cached.dead&&cached.built&&u.dropVer===gridVer&&workerGoal(u,cached)>=0)return cached;
 let best=null,bd=Infinity;for(const b of blds){if(b.dead||b.team!==u.team||!b.built||!b.def.drop||rectDist(u.x,u.y,b)>=bd)continue;const route=workerRoute(u,b);
  if(route&&route.distance<bd){bd=route.distance;best=b;}}u.dropTarget=best;u.dropVer=gridVer;return best;}
function releaseBuilder(w){w.build=null;w.buildDeposit=false;w.path=null;w.dropTarget=null;w.stuck=0;w.ws=w.carry>0?'ret':'seek';
 if(w.returnCampo&&!w.returnCampo.dead)w.prefCampo=w.returnCampo;w.returnCampo=null;}
function findCampo(u,pref){const cap=farmCap(u.team);const ok=b=>{if(b.dead||b.team!==u.team||b.kind!=='campo'||!b.built)return false;b.slots=b.slots.filter(w=>!w.dead&&w.campo===b);return b.slots.length<cap;};
 if(pref&&ok(pref))return pref;let best=null,bd=Infinity;for(const b of blds){if(!ok(b))continue;const d=hyp(b.x-u.x,b.y-u.y);if(d<bd){bd=d;best=b;}}return best;}
// sceglie la risorsa: vicina al punto di partenza, vicina a un deposito e non già affollata
function findRes(u,arr){const near=u.near;u.near=null;let ox,oy;
 if(near){ox=near.x;oy=near.y;}else if(u.lastRc>=0&&hyp(cX(u.lastRc)-u.x,cY(u.lastRc)-u.y)<500){ox=cX(u.lastRc);oy=cY(u.lastRc);}
 else{const dp=nearestDrop(u);if(dp&&hyp(dp.x-u.x,dp.y-u.y)<400){ox=dp.x;oy=dp.y;}else{ox=u.x;oy=u.y;}}
 const x0=(ox/CELL)|0,y0=(oy/CELL)|0;let best=-1,bs=Infinity,stopAt=99;
 for(let r=0;r<45&&r<=stopAt;r++){for(let y=y0-r;y<=y0+r;y++){if(y<0||y>=GH)continue;const step=(r===0||y===y0-r||y===y0+r)?1:2*r;
   for(let x=x0-r;x<=x0+r;x+=step){if(x<0||x>=GW)continue;const i=y*GW+x;if(arr[i]<=0||(u.skip&&u.skip.has(i)))continue;if(adjFreeCell(u.team,i,u.x,u.y)<0)continue;
    let dpd=0;for(const b of blds)if(!b.dead&&b.team===u.team&&b.built&&b.def.drop){const d=rectDist(cX(i),cY(i),b);if(dpd===0||d<dpd)dpd=d;}
    const s=hyp(cX(i)-ox,cY(i)-oy)*.6+dpd*.8+resClaim[i]*110+hash2(i,u.id)*25;if(s<bs){bs=s;best=i;}}}
  if(best>=0&&stopAt===99)stopAt=r+4;}
 return best;}
function idleHome(u,T,dt){const h=T.home;u.working=false;if(h&&hyp(h.x-u.x,h.y-u.y)>200){const g=adjFree(u.team,h,u.x,u.y);if(g>=0)navTo(u,cX(g),cY(g),g,T.S.worker.spd,dt);}else u.mv=false;}
function resetWorker(w){if(w.campo){w.campo.slots=w.campo.slots.filter(x=>x!==w);w.campo=null;}w.ws='seek';w.path=null;w.dropTarget=null;setRc(w,-1);}
function changeJob(w,job){const T=teams[w.team];if(w.job!==job){if(w.job&&T.jobs[w.job]>0)T.jobs[w.job]--;T.jobs[job]++;w.job=job;}resetWorker(w);}
// ordini dati a mano ai contadini (tasto destro)
function workerCommand(list,wx,wy){const t=list[0].team;let i=cellI(wx,wy),res=-1;
 for(const d of [0,1,-1,GW,-GW]){const j=i+d;if(j>=0&&j<NCELL&&(tree[j]>0||stone[j]>0)){res=j;break;}}
 let o=null;for(const b of blds){if(!b.dead&&b.team===t&&wx>=b.x0&&wx<=b.x0+b.w*CELL&&wy>=b.y0-30&&wy<=b.y0+b.h*CELL){o=b;break;}}
 if(res<0&&o&&o.isB&&o.team===t){
  if(!o.built){for(const w of list){resetWorker(w);w.order=null;w.build=o;w.buildDeposit=false;}return 'build';}
  if(o.kind==='campo'){for(const w of list){changeJob(w,'g');w.order=null;w.build=null;w.prefCampo=o;}return 'g';}
  if(o.def.drop){for(const w of list){w.order=null;w.build=null;w.path=null;if(w.carry>0){w.ws='ret';w.dropTarget=workerGoal(w,o)>=0?o:null;w.dropVer=gridVer;}}return 'drop';}}
 if(res>=0){const job=tree[res]>0?'l':'p';for(const w of list){changeJob(w,job);w.order=null;w.build=null;w.near={x:cX(res),y:cY(res)};}
  for(const w of list.slice(0,2))setRc(w,res);return job;}
 for(const w of list){w.build=null;resetWorker(w);}orderGroup(list,wx,wy,true);return 'move';}
function updWorker(u,T,S,dt){u.mv=false;u.working=false;const m=T.mods;
 if(u.order){followOrder(u,S,dt);if(!u.order){u.near={x:u.x,y:u.y};u.ws='seek';u.dropTarget=null;setRc(u,-1);}return;}
 if(u.build){const b=u.build;if(b.dead||b.built){releaseBuilder(u);return;}
  if(u.buildDeposit&&u.carry>0){const dp=nearestDrop(u);if(dp){if(rectDist(u.x,u.y,dp)<=30){depositWorker(u);u.buildDeposit=false;u.dropTarget=null;u.path=null;return;}
    const goal=workerGoal(u,dp);if(goal>=0){navTo(u,cX(goal),cY(goal),goal,S.spd,dt);return;}}u.buildDeposit=false;}
  if(rectDist(u.x,u.y,b)<=30){u.f=b.x>=u.x?1:-1;u.working=true;const k=Math.min(1-b.prog,dt/b.def.t*.8*(1+m.build));b.prog+=k;b.hp=Math.min(b.max,b.hp+b.max*.95*k);if(b.prog>=1)onBuilt(b);return;}
  const g=workerGoal(u,b);if(g<0){releaseBuilder(u);return;}navTo(u,cX(g),cY(g),g,S.spd,dt);return;}
 const job=u.job;if(!job){idleHome(u,T,dt);return;}
 const cap=CARRY+m.carry;
 if(u.carry>0&&(u.ct!==job||job==='g')&&u.ws!=='ret'){u.ws='ret';u.dropTarget=null;}
 if(u.ws==='ret'){const dp=nearestDrop(u);if(!dp){idleHome(u,T,dt);return;}
  if(rectDist(u.x,u.y,dp)<=30){depositWorker(u);u.ws='go';u.dropTarget=null;u.path=null;return;}
  const g=workerGoal(u,dp);if(g<0){idleHome(u,T,dt);return;}navTo(u,cX(g),cY(g),g,S.spd,dt);return;}
 if(job==='g'){if(!u.campo||u.campo.dead||!u.campo.built){u.campo=findCampo(u,u.prefCampo);u.prefCampo=null;if(!u.campo){T.noFarm=true;idleHome(u,T,dt);return;}
   u.campo.slots.push(u);const k=(u.campo.slots.length-1)%FSPOT.length;u.spot={x:u.campo.x+FSPOT[k][0],y:u.campo.y+FSPOT[k][1]};u.path=null;}
  if(hyp(u.spot.x-u.x,u.spot.y-u.y)>10){navTo(u,u.spot.x,u.spot.y,cellI(u.spot.x,u.spot.y),S.spd,dt);return;}
  u.working=true;u.f=Math.sin(G.t*.3+u.id)>0?1:-1;const a=gatherRate(T,'g')*(1+m.farmBonus)*dt;T.res.g+=a;T.gath.g+=a;u.grainLoad=(u.grainLoad||0)+a;const loads=Math.floor(u.grainLoad/cap);if(loads){u.grainLoad-=loads*cap;if(!u.temporaryUntil)cardDelivery(u.team,'g',loads);}return;}
 const arr=job==='l'?tree:stone;if(u.skipVer!==gridVer){if(u.skip)u.skip.clear();u.skipVer=gridVer;}
 if(u.carry>=cap){u.ws='ret';u.dropTarget=null;u.path=null;return;}
 if(u.rc<0||arr[u.rc]<=0){setRc(u,findRes(u,arr));u.path=null;if(u.rc<0){idleHome(u,T,dt);return;}}
 const rx=cX(u.rc),ry=cY(u.rc);
 if(hyp(rx-u.x,ry-u.y)<=47){u.working=true;u.f=rx>=u.x?1:-1;const amt=Math.min(arr[u.rc],gatherRate(T,job)*dt);arr[u.rc]-=amt;u.carry+=amt;u.ct=job;if(NET)NET.dirty.add(u.rc);
  if(arr[u.rc]<=.01){arr[u.rc]=0;gridVer++;if(job==='l'){stump[u.rc]=1;if(!u.temporaryUntil&&T.ups.segheria){T.res.l+=8*T.ups.segheria;T.gath.l+=8*T.ups.segheria;}if(!isClient())treeRegrowAt.set(u.rc,G.t+600);}setRc(u,-1);}return;}
 const g=adjFreeCell(u.team,u.rc,u.x,u.y);if(g<0){setRc(u,-1);return;}navTo(u,cX(g),cY(g),g,S.spd,dt);
 if(u.navFail){(u.skip||(u.skip=new Set())).add(u.rc);if(u.skip.size>40)u.skip.clear();setRc(u,-1);u.path=null;u.navFail=false;}}
function balanceJobs(t){const T=teams[t];const ws=units.filter(u=>!u.dead&&u.team===t&&u.type==='worker');const cnt={g:0,l:0,p:0};for(const w of ws)if(w.job)cnt[w.job]++;
 let sum=T.jobs.g+T.jobs.l+T.jobs.p;while(sum<ws.length){T.jobs[T.newJob]++;sum++;}
 while(sum>ws.length){const k=['p','l','g'].find(k=>T.jobs[k]>0);T.jobs[k]--;sum--;}
 for(const w of ws)if(!w.job){let k='g',bv=-1e9;for(const r of RES){const v=T.jobs[r]-cnt[r];if(v>bv){bv=v;k=r;}}w.job=k;cnt[k]++;resetWorker(w);}
 for(let it=0;it<4;it++){const over=RES.find(k=>cnt[k]>T.jobs[k]),under=RES.find(k=>cnt[k]<T.jobs[k]);if(!over||!under)break;
  const available=ws.filter(w=>w.job===over&&!w.build&&!w.order),w=available.find(w=>w.carry<1)||available[0];if(!w)break;w.job=under;cnt[over]--;cnt[under]++;resetWorker(w);}
 T.noFarm=false;let cap=0;for(const b of blds)if(!b.dead&&b.team===t&&b.kind==='campo'&&b.built)cap+=farmCap(t);if(cnt.g>cap)T.noFarm=true;}
function assignBuilders(t){const fs=blds.filter(b=>b.team===t&&!b.built&&!b.dead);for(const b of fs)b.builders=0;
 const ws=units.filter(u=>!u.dead&&u.team===t&&u.type==='worker');for(const w of ws)if(w.build){if(w.build.dead||w.build.built)releaseBuilder(w);else w.build.builders++;}
 if(!fs.length)return;let need=0;for(const b of fs)need+=b.def.wall?.4:2.5;need=Math.min(Math.ceil(need),Math.max(2,Math.floor(ws.length*.4)),10);
 let cur=ws.filter(w=>w.build).length;
 while(cur<need){let best=null,site=null,bd=Infinity,deposit=false;
  for(const b of fs){if(b.builders>=(b.def.wall?1:3))continue;const spread=b.builders*CELL*8;
   for(const w of ws){if(w.build||w.order||rectDist(w.x,w.y,b)+spread>=bd)continue;const route=workerRoute(w,b);if(!route)continue;
    let score=route.distance+spread,drop=null;if(w.carry>0){drop=nearestDrop(w);if(drop){const dr=workerRoute(w,drop);if(dr)score+=Math.max(0,dr.distance+rectDist(cX(dr.goal),cY(dr.goal),b)-route.distance)+CELL*3;else drop=null;}}
    if(score<bd){bd=score;best=w;site=b;deposit=!!drop;}}}
  if(!best)break;best.returnCampo=best.campo;resetWorker(best);best.build=site;best.buildDeposit=deposit;best.stuck=0;site.builders++;cur++;}}

// ===================== edifici =====================
function updBld(b,dt){if(b.dead||!b.built||isPlayerTeam(b.team)&&!isActivePlayer(b.team))return;const T=teams[b.team],m=T.mods;
 if(m.wallRegen&&(b.def.wall||b.kind==='torre')&&b.hp<b.max&&G.t-(b.lastHit||-9)>2)b.hp=Math.min(b.max,b.hp+m.wallRegen*dt);
 b.blocked=false;
 if(b.queue.length){const q=b.queue[0];q.t+=dt*(1+m.prod+(q.type==='worker'?m.prodW:0)+(UT[q.type].cls==='inf'?m.prodInf:0));if(q.t>=q.total){const pop=UT[q.type].pop;if(T.popUsed+pop<=T.popMax){b.queue.shift();const u=spawnFrom(b,q.type);if(!u){b.queue.unshift(q);}else{cardOnPaidTrain(u,q);if(q.type!=='worker')notify(b.team,'sfx','ready');}}else{q.t=q.total;b.blocked=true;}}}
 const A=b.def.atk;if(A){b.cd-=dt;if(b.cd<=0){let tg=null,bd=A.rng;forNear(b.x,b.y,A.rng+40,e=>{if(e.dead||!areEnemies(b.team,e.team))return;const d=rectDist(e.x,e.y,b);if(d<bd){bd=d;tg=e;}});
  if(tg){b.cd+=Math.max(.3,A.cd-(b.kind==='torre'?m.towerReload:0));const n=1+m.arrows+(b.kind==='palazzo'&&m.palace?1:0);const dmg=A.dmg*(1+m.tower)+m.flatTower;const sx=b.x,sy=b.y0-(b.kind==='torre'?60:40);
   for(let k=0;k<n;k++){let t=tg;if(k>0){const c=[];forNear(b.x,b.y,A.rng,e=>{if(!e.dead&&areEnemies(b.team,e.team)&&rectDist(e.x,e.y,b)<A.rng)c.push(e);});if(c.length)t=c[(Math.random()*c.length)|0];}
    addProj({k:'b',x0:sx+MR(-6,6),y0:sy,x1:t.x,y1:t.y-9,t:0,dur:Math.max(.2,hyp(t.x-sx,t.y-sy)/460),tgt:t,dmg,crit:false,team:b.team,att:null,pierce:0,fire:0});}
   if(b.kind==='torre'&&m.towerCross){let second=null;forNear(b.x,b.y,A.rng+40,e=>{if(e!==tg&&!e.dead&&areEnemies(b.team,e.team)&&rectDist(e.x,e.y,b)<A.rng&&(!second||e.id<second.id))second=e;});
    if(second)addProj({k:'b',x0:sx,y0:sy,x1:second.x,y1:second.y-9,t:0,dur:Math.max(.2,hyp(second.x-sx,second.y-sy)/460),tgt:second,dmg,crit:false,team:b.team,att:null,pierce:0,fire:0});}}
  else b.cd=.4;}}}

// ===================== proiettili ed effetti =====================
function updProj(dt){const processing=projs.slice();for(const p of processing){p.t+=dt/p.dur;if(p.t<1)continue;p.done=true;
 if(p.k==='b'){const t=p.tgt;if(t&&!t.dead&&areEnemies(p.team,t.team)&&(t.isB||hyp(t.x-p.x1,t.y-9-p.y1)<28)){const blocked=t.blockedShotSeq||0;damage(p.team,t,p.dmg,'r',false,p.att,{normal:!!p.normal});if((t.blockedShotSeq||0)!==blocked)continue;
   if(p.fire&&!t.isB&&!t.dead){t.burn=3;t.burnD=p.fire;t.burnBy=p.team;t.burnAtt=p.att;}
   if(p.pierce&&!t.isB){let n=p.pierce;forNear(t.x,t.y,40,e=>{if(n<=0||e===t||e.dead||!areEnemies(p.team,e.team))return;if(hyp(e.x-t.x,e.y-t.y)<40){damage(p.team,e,8,'r',false,p.att,{normal:false});n--;}});}
   if(p.linePierce&&!t.isB){const dx=p.x1-p.x0,dy=p.y1-p.y0,L=hyp(dx,dy)||1,targets=[];
    forNear(t.x,t.y,96,e=>{if(e===t||e.dead||!areEnemies(p.team,e.team))return;const ex=e.x-t.x,ey=e.y-t.y,along=(ex*dx+ey*dy)/L,across=Math.abs(ex*dy-ey*dx)/L;if(along>0&&along<=96&&across<=20)targets.push({e,along});});targets.sort((a,b)=>a.along-b.along||a.e.id-b.e.id);
    for(const {e} of targets.slice(0,1))addProj({k:'b',x0:t.x,y0:t.y-9,x1:e.x,y1:e.y-9,t:0,dur:Math.max(.12,hyp(e.x-t.x,e.y-t.y)/440),tgt:e,dmg:8,team:p.team,att:p.att,normal:false,pierce:0,fire:0});}
   if((p.normal||p.heroPin)&&typeof heroOnProjectileImpact==='function')heroOnProjectileImpact(p,t);}
  else decals.push({k:'b',x:p.x1,y:p.y1+9,a:Math.atan2(p.y1-p.y0,p.x1-p.x0),t:0,life:3});}
 else if(p.single){const t=p.tgt;if(t&&!t.dead&&areEnemies(p.team,t.team)&&(t.isB||hyp(t.x-p.x1,t.y-9-p.y1)<28))damage(p.team,t,t.isB?p.bdmg:p.dmg,'s',false,p.att,{normal:false,fixed:true});}
 else{const R2=p.splash||48;
  for(const b of blds){if(b.dead||!areEnemies(p.team,b.team))continue;if(rectDist(p.x1,p.y1,b)<R2)damage(p.team,b,p.bdmg,'s',false,p.att,{normal:!!p.normal&&p.tgt===b});}
  forNear(p.x1,p.y1,R2,e=>{if(!e.dead&&areEnemies(p.team,e.team)&&hyp(e.x-p.x1,e.y-p.y1)<R2)damage(p.team,e,p.dmg,'s',false,p.att,{normal:!!p.normal&&p.tgt===e});});
  if(p.shrapnel){const targets=[];forNear(p.x1,p.y1,96,e=>{if(!e.dead&&areEnemies(p.team,e.team)&&['inf','xb','cav'].includes(e.d.cls)&&hyp(e.x-p.x1,e.y-p.y1)<=96)targets.push(e);});targets.sort((a,b)=>hyp(a.x-p.x1,a.y-p.y1)-hyp(b.x-p.x1,b.y-p.y1)||a.id-b.id);
   for(const e of targets.slice(0,2))addProj({k:'s',single:true,x0:p.x1,y0:p.y1-9,x1:e.x,y1:e.y-9,t:0,dur:.4,tgt:e,dmg:10,bdmg:10,team:p.team,att:p.att,normal:false,pierce:0,fire:0});}
  if(p.normal&&typeof heroOnProjectileImpact==='function')heroOnProjectileImpact(p,null);sfx('boom',p.x1,p.y1);}}
 projs=projs.filter(p=>!p.done);}

function updFx(dt){parts.length=0;
 for(const f of floats)f.t+=dt;floats=floats.filter(f=>f.t<.9);
 for(const d of decals)d.t+=dt;decals=decals.filter(d=>d.t<d.life);if(decals.length>500)decals.splice(0,decals.length-500);
 for(const p of pings)p.t+=dt;pings=pings.filter(p=>p.t<4);G.shake=0;}

// ===================== separazione tra unità =====================
// Solo le spinte alleate rispettano il fronte: prima l'assestamento, poi il posto
// resta fermo. Un nuovo ordine o un difensore nemico conservano il normale movimento.
function meleeHolding(u){const b=u.tgt;return !u.mv&&!u.dead&&b?.isB&&!b.dead&&!u.d.ranged&&u.type!=='worker'&&areEnemies(u.team,b.team)&&distTo(u,b)<=teams[u.team].S[u.type].rng+3+u.d.r*.5;}
function meleePush(u,dx,dy){if(meleeHolding(u)){const reach=teams[u.team].S[u.type].rng+3+u.d.r*.5;if(rectDist(u.x+dx,u.y+dy,u.tgt)>reach)return;}tryMove(u,u.x+dx,u.y+dy);}
function separate(){for(const a of units){if(a.dead)continue;forNear(a.x,a.y,36,b=>{if(b.id<=a.id||b.dead)return;const dx=b.x-a.x,dy=b.y-a.y,rad=(a.d.r+b.d.r)*.9;
 if(Math.abs(dx)>=rad||Math.abs(dy)>=rad)return;let d=hyp(dx,dy);let nx,ny;if(d<.01){const an=Math.random()*TAU;nx=Math.cos(an);ny=Math.sin(an);d=.01;}else{nx=dx/d;ny=dy/d;}
 if(d>=rad)return;const p=Math.min(rad-d,4),allied=areAllies(a.team,b.team);let wa=a.mv?.65:.35,wb=b.mv?.65:.35;if(allied){if(meleeHolding(a)&&a.stillT>2)wa=0;if(meleeHolding(b)&&b.stillT>2)wb=0;if(!wa&&!wb)return;}
 if(a.working)wa*=.3;if(b.working)wb*=.3;const s=wa+wb;
 if(allied){meleePush(a,-nx*p*wa/s,-ny*p*wa/s);meleePush(b,nx*p*wb/s,ny*p*wb/s);}else{tryMove(a,a.x-nx*p*wa/s,a.y-ny*p*wa/s);tryMove(b,b.x+nx*p*wb/s,b.y+ny*p*wb/s);}});}}

// ===================== visione e nebbia =====================
let vis=new Uint8Array(NCELL),exp=new Uint8Array(NCELL),fogA=new Float32Array(NCELL).fill(1);
const visAt=(x,y)=>vis[cellI(x,y)]===1;
let fogC=null,fogX=null,fogI=null;
function initFog(){fogC=mkCanvas(GW,GH);fogX=fogC.getContext('2d');fogI=fogX.createImageData(GW,GH);vis.fill(0);exp.fill(0);fogA.fill(1);}
function stampVis(x,y,r){const cx=x/CELL,cy=y/CELL,rc=r/CELL,x0=Math.max(0,Math.floor(cx-rc)),x1=Math.min(GW-1,Math.ceil(cx+rc)),y0=Math.max(0,Math.floor(cy-rc)),y1=Math.min(GH-1,Math.ceil(cy+rc)),r2=rc*rc;
 for(let yy=y0;yy<=y1;yy++){const dy=yy+.5-cy;for(let xx=x0;xx<=x1;xx++){const dx=xx+.5-cx;if(dx*dx+dy*dy<=r2){const i=yy*GW+xx;vis[i]=1;exp[i]=1;}}}}
function updVision(){vis.fill(0);if(G.reveal&&!isTeamMatch()){vis.fill(1);exp.fill(1);}
 else{for(const u of units)if(!u.dead&&areAllies(u.team,ME))stampVis(u.x,u.y,teams[u.team].S[u.type].sight);
  for(const b of blds)if(!b.dead&&areAllies(b.team,ME))stampVis(b.x,b.y,(b.def.sight||150)*(1+teams[b.team].mods.sight)*(b.built?1:.6));}
 for(const b of blds)if(!b.dead&&!b.seen&&(vis[b.cy*GW+b.cx]||vis[cellI(b.x,b.y)]))b.seen=true;
 for(const c of camps)if(!c.seen&&vis[c.cy*GW+c.cx])c.seen=true;
 const D=fogI.data;for(let i=0;i<NCELL;i++){const tgt=vis[i]?0:exp[i]?.5:1;fogA[i]+=(tgt-fogA[i])*.35;D[i*4]=14;D[i*4+1]=11;D[i*4+2]=6;D[i*4+3]=fogA[i]*255;}fogX.putImageData(fogI,0,0);}

// ===================== economia e timer =====================
function econTick(t,dt){if(!isActivePlayer(t))return;const T=teams[t],m=T.mods,tm=T.tm;
 if(m.fair){tm.fair-=dt;if(tm.fair<=0){tm.fair=30;const n=units.filter(u=>!u.dead&&u.team===t&&u.type==='worker').length;for(const r of RES)T.res[r]+=n*m.fair;notify(t,'toast',`Fiera: +${n*m.fair} di ogni risorsa`,'#ffe3a0',1400);}}
 if(m.interest){tm.int-=dt;if(tm.int<=0){tm.int=20;for(const r of RES)T.res[r]+=Math.min(40*m.interest/.02,T.res[r]*m.interest);}}
 if(m.freeW){tm.freeW-=dt;if(tm.freeW<=0){tm.freeW=50;queueReinforcement(t,'worker',m.freeW);}}
 if(m.levy){tm.levy-=dt;if(tm.levy<=0){tm.levy=60;queueReinforcement(t,'inf',m.levy);}}
 if(m.contrade){tm.contrade-=dt;if(tm.contrade<=0){tm.contrade=80/m.contrade;spawnNear(t,'cav',true);}}
 if(T.martT>0)T.martT-=dt;if(T.martCd>0)T.martCd-=dt;
 if(T.furyK.length)T.furyK=T.furyK.filter(k=>G.t-k<15);
 cardDefenseTick(t,dt);
 if(m.silk){let n=0;for(const b of blds)if(!b.dead&&b.team===t&&(b.kind==='magaz'||b.kind==='palazzo')&&b.built)n++;for(const r of RES)T.res[r]+=n*dt/2;}
 if(m.crusade){tm.crusade-=dt;if(tm.crusade<=0){tm.crusade=360;const w=++tm.crusadeN;const ni=Math.min(6,1+w),nc=Math.min(2,Math.floor(w/3));
  queueReinforcement(t,'inf',ni);if(nc)queueReinforcement(t,'cav',nc);
  notify(t,'sfx','bell');notify(t,'toast',`✝ Crociata! Arrivano ${ni+nc} crociati al Palazzo`,'#ffe3a0',2200);}}
 if(T.ups.bardi){tm.bardi=(tm.bardi??30)-dt;if(tm.bardi<=0){tm.bardi=30;T.res.g+=20*T.ups.bardi;T.res.l+=15*T.ups.bardi;}}
 updHomeZ(t);flushReinforcements(t);}
function ringMart(t){if(!isActivePlayer(t))return false;const T=teams[t];if(!T.mods.mart||T.martCd>0)return false;T.martT=30;T.martCd=180;notify(t,'sfx','bell');notify(t,'toast','🔔 La Martinella suona! +40% danni per 30 s','#ffd76a',2400);return true;}
function recordCampDamage(u,by,amount){const c=u.camp;if(!c||c.conquered||u.team!==neutralTeam()||!isActivePlayer(by)||!(amount>0))return;
 c.damage[by]=(c.damage[by]||0)+Math.min(u.hp,amount);}
function registerCampKill(u,by){const c=u.camp;if(c&&!c.conquered&&u.team===neutralTeam()&&isActivePlayer(by))c.lastKill=by;}
function campLayout(c){return [{kind:'caserma',cx:c.cx-2,cy:c.cy-2},{kind:'torre',cx:c.cx+1,cy:c.cy+1}];}
function campLayoutFree(c){return campLayout(c).every(s=>{const d=BT[s.kind];for(let y=s.cy;y<s.cy+d.h;y++)for(let x=s.cx;x<s.cx+d.w;x++){
 if(!inb(x,y))return false;const i=y*GW+x;if(water[i]||tree[i]>0||stone[i]>0||bAt[i])return false;}return true;});}
function conquerCamp(c,who){if(!isActivePlayer(who)||c.conquered||!c.relic||!campLayoutFree(c))return false;
 // Il possessore rimane registrato anche quando entrambi gli edifici vengono distrutti.
 c.conquered=true;c.relic=false;c.owner=who;c.seen=true;
 c.buildings=campLayout(c).map(s=>{const b=mkBld(who,s.kind,s.cx,s.cy,true);b.camp=c;b.paid={};return b.id;});
 // Le truppe presenti non impediscono la conquista e non rimangono intrappolate nei nuovi edifici.
 for(const u of units){if(u.dead||!c.buildings.includes(bAt[cellI(u.x,u.y)]?.id))continue;const i=nearestPass(u.team,cellI(u.x,u.y));
  if(i>=0){u.x=cX(i);u.y=cY(i);u.path=null;u.pathT=0;u.losT=0;}}
 queuePick(who,'reliquia','R');if(teams[who].mods.relics)queuePick(who,'reliquia','R');addGlory(who,15);
 notify(who,'sfx','glory');notify(who,'toast','Accampamento conquistato: caserma e torre!','#ffd76a',2400);
 for(const t of playerIds())if(t!==who&&isActivePlayer(t)){const ally=areAllies(t,who);notify(t,'toast',ally?'Un alleato ha conquistato un accampamento':'Il nemico ha conquistato un accampamento',ally?'#c8f0b0':'#ff9a8a',2000);}return true;}
function campCheck(){const alive=new Set(units.filter(u=>!u.dead).map(u=>u.id));for(const c of camps){
 if(c.conquered||!c.relic||!c.guardIds.length||c.guardIds.some(id=>alive.has(id)))continue;
 // Conta il danno effettivo alle guardie assegnate; a parità vince chi elimina l'ultima guardia.
 const eligible=playerIds().filter(t=>isActivePlayer(t)&&(c.damage[t]||0)>0),most=Math.max(0,...eligible.map(t=>c.damage[t]));
 const leaders=eligible.filter(t=>c.damage[t]===most),who=leaders.includes(c.lastKill)?c.lastKill:leaders[0];
 if(who!=null)conquerCamp(c,who);}}


// ===================== ciclo di simulazione =====================
// Controlla solo gli alberi abbattuti, due volte al secondo. Nessuna scansione dell'intera mappa.
function regrowTrees(){if(!G||isClient()||!treeRegrowAt.size)return;let occupied=null,changed=false;
 for(const [i,at]of treeRegrowAt){if(G.t<at)continue;if(tree[i]>0){treeRegrowAt.delete(i);continue;}
  if(water[i]||stone[i]>0||bAt[i])continue;
  if(!occupied){occupied=new Set();for(const u of units){if(u.dead)continue;const r=u.d.r;
   for(let y=Math.max(0,Math.floor((u.y-r)/CELL));y<=Math.min(GH-1,Math.floor((u.y+r)/CELL));y++)
    for(let x=Math.max(0,Math.floor((u.x-r)/CELL));x<=Math.min(GW-1,Math.floor((u.x+r)/CELL));x++){
     const dx=u.x-clamp(u.x,x*CELL,(x+1)*CELL),dy=u.y-clamp(u.y,y*CELL,(y+1)*CELL);
     if(dx*dx+dy*dy<=r*r)occupied.add(y*GW+x);}}}
  if(occupied.has(i))continue;tree[i]=100;stump[i]=0;treeRegrowAt.delete(i);changed=true;if(isHost())NET.dirty.add(i);
 }if(changed)gridVer++;}

let slowT=0,visT=0;
function tick(dt){if(G.over)return;G.t+=dt;
 rebuildHash();
 for(let i=0;i<units.length;i++){const u=units[i];if(!u.dead)updUnit(u,dt);}
 tacticHealing();
 separate();
 for(let i=0;i<blds.length;i++){const b=blds[i];if(!b.dead)updBld(b,dt);}
 updProj(dt);updFx(dt);
 checkEnd();if(G.over)return;
 slowT-=dt;if(slowT<=0){slowT=.5;for(const t of playerIds()){if(!isActivePlayer(t))continue;assignBuilders(t);balanceJobs(t);recountPop(t);econTick(t,.5);}campCheck();regrowTrees();}
 for(const t of playerIds()){if(!isActivePlayer(t))continue;const T=teams[t];T.upT-=dt;if(T.upT<=0){const at=Math.round((G.t+T.upT)*1000)/1000;T.upT+=UP_INT;queuePick(t,'tempo',null,at);}
  if(T.picks.length){if(isHuman(t)){ensureOffer(t);}else aiPick(t);}}
 for(const ai of AIS)aiUpdate(ai,dt);
 visT-=dt;if(visT<=0){visT=.15;updVision();}
 if(units.some(u=>u.dead))units=units.filter(u=>!u.dead);
 if(blds.some(b=>b.dead))blds=blds.filter(b=>!b.dead);
 if(!G.late&&G.t>=1800)lateGame();
 if(isHost())netHostTick(dt);
 checkEnd();}
function eliminatePlayer(t){if(!isActivePlayer(t))return false;const T=teams[t];T.eliminated=true;T.reinforcementQueue.length=0;T.offer=null;T.picks.length=0;T.jobs={g:0,l:0,p:0};T.carr=null;T.popUsed=0;T.popMax=0;
 // La resa elimina le forze senza simulare uccisioni, saccheggi o premi di Gloria.
 for(const u of units)if(u.team===t){clearCombatResponse(u);if(u.type==='worker')setRc(u,-1);if(u.campo)u.campo.slots=u.campo.slots.filter(w=>w!==u);u.dead=true;u.hp=0;u.order=null;u.tgt=null;u.echo=null;}
 for(const b of blds)if(b.team===t){b.dead=true;b.hp=0;b.queue.length=0;for(const w of b.slots)w.campo=null;b.slots.length=0;
  for(let y=b.cy;y<b.cy+b.h;y++)for(let x=b.cx;x<b.cx+b.w;x++){const i=y*GW+x;if(bAt[i]===b)bAt[i]=null;}}
 units=units.filter(u=>u.team!==t);blds=blds.filter(b=>b.team!==t);projs=projs.filter(p=>p.team!==t);AIS=AIS.filter(ai=>ai.t!==t);
 gridVer++;homeZone(t).fill(0);workerAccessCache[t]=null;aiSightCache[t]=null;
 if(typeof playerEliminated==='function')playerEliminated(t);return true;}
function checkEnd(){if(G.over)return;const fallen=playerIds().filter(t=>isActivePlayer(t)&&(!teams[t].home||teams[t].home.dead));
 if(!fallen.length)return;for(const t of fallen)eliminatePlayer(t);
 const alive=playerIds().filter(isActivePlayer),sides=new Set(alive.map(sideOf));if(sides.size>1)return;
 G.over=true;G.winner=alive.length?alive[0]:null;G.winnerSide=isTeamMatch()&&alive.length?sideOf(alive[0]):null;emit(['end',G.winner]);endGame(G.winner);if(isHost())netFinish();}
// dal minuto 30: le difese restano, ma l'assedio diventa più forte e la Gloria raddoppia
function lateGame(){G.late=true;for(const t of playerIds()){if(!isActivePlayer(t))continue;const m=teams[t].mods;m.siegeMax+=2;m.dmg.treb+=.3;m.glory+=1;refreshStats(t);}
 for(const t of playerIds())if(isActivePlayer(t)){notify(t,'sfx','bell');notify(t,'toast','⚔ Guerra totale: +2 macchine d\'assedio, assedio +30% danni, Gloria doppia','#ffb06a',4500);}}
function addProj(p){if(typeof heroOnProjectileLaunch==='function')heroOnProjectileLaunch(p);projs.push(p);emit(['p',p.k,p.x0|0,p.y0|0,p.x1|0,p.y1|0,Math.round(p.dur*100),(p.crit?1:0)|(p.fire?2:0)]);}
